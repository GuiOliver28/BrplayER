package br.com.brplay

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/** TV, Fire TV, Android TV box: navegação por controle remoto (D-pad) em vez de toque. */
fun isTvDevice(ctx: Context): Boolean {
    val pm = ctx.packageManager
    val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
        pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
        pm.hasSystemFeature("amazon.hardware.fire_tv") ||
        !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
}
