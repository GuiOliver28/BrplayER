package br.com.brplay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.brplay.CAT_FAV
import br.com.brplay.CAT_RECENT

private data class CatEntry(val key: String?, val label: String, val icon: ImageVector)

/** Coluna fixa de categorias (lista vertical), com foco de D-pad e destaque na selecionada. */
@Composable
fun CategorySidebar(
    categories: List<String>,
    selected: String?,
    showRecent: Boolean,
    width: Dp,
    compact: Boolean,
    onSelect: (String?) -> Unit,
) {
    val entries = remember(categories, showRecent) {
        buildList {
            add(CatEntry(null, "Todos", Icons.Rounded.GridView))
            add(CatEntry(CAT_FAV, "Favoritos", Icons.Rounded.FavoriteBorder))
            if (showRecent) add(CatEntry(CAT_RECENT, CAT_RECENT, Icons.Rounded.History))
            categories.forEach { add(CatEntry(it, it, genreIcon(it))) }
        }
    }
    LazyColumn(
        Modifier.width(width).fillMaxHeight().background(Color(0xFF0F172A)),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items(entries, key = { it.key ?: "__all" }) { e ->
            val on = e.key == selected
            var focused by remember { mutableStateOf(false) }
            val shape = RoundedCornerShape(8.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (on) Color(0xFF1FA45A).copy(alpha = .35f) else Color.Transparent)
                    .border(if (focused) 3.dp else 0.dp, Color.White, shape)
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onSelect(e.key) }
                    .padding(horizontal = if (compact) 6.dp else 12.dp, vertical = if (compact) 9.dp else 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(e.icon, null, tint = if (on) Color.White else Color(0xFFB8C2D0), modifier = Modifier.size(if (compact) 15.dp else 22.dp))
                Spacer(Modifier.width(if (compact) 5.dp else 10.dp))
                Text(
                    e.label, color = if (on) Color.White else Color(0xFFB8C2D0),
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    fontSize = if (compact) 12.sp else 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    lineHeight = if (compact) 14.sp else 18.sp,
                )
            }
        }
    }
}
