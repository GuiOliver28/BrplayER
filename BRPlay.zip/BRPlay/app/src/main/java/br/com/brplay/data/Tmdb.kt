package br.com.brplay.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

/** Busca de capas no TMDB (opcional: precisa da chave de API v3 nas Configurações). */
object Tmdb {
    private lateinit var store: Store
    private val gate = Semaphore(3)

    fun init(s: Store) { store = s }

    suspend fun poster(item: Item): String? {
        val key = store.str("tmdb").trim()
        if (key.isEmpty()) return null
        val title = Meta.cleanTitle(item.name)
        if (title.length < 2) return null
        val cacheKey = "tm_" + "${item.kind.name}|$title|${item.year}".hashCode()
        store.tmdbGet(cacheKey)?.let { return it.ifEmpty { null } }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                runCatching {
                    val tv = item.kind == Kind.SERIES
                    val yearParam = if (item.year > 0) (if (tv) "&first_air_date_year=" else "&year=") + item.year else ""
                    val url = "https://api.themoviedb.org/3/search/${if (tv) "tv" else "movie"}" +
                        "?api_key=${URLEncoder.encode(key, "UTF-8")}&language=pt-BR" +
                        "&query=${URLEncoder.encode(title, "UTF-8")}$yearParam"
                    val path = JSONObject(Net.text(url)).optJSONArray("results")
                        ?.optJSONObject(0)?.optString("poster_path").orEmpty()
                    val full = if (path.isNotEmpty() && path != "null") "https://image.tmdb.org/t/p/w342$path" else ""
                    store.tmdbPut(cacheKey, full)
                    full.ifEmpty { null }
                }.getOrNull()
            }
        }
    }
}
