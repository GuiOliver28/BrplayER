package br.com.brplay.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.SortMode
import br.com.brplay.Tab
import br.com.brplay.data.Item

/** Tela Início: Continuar assistindo, Adicionados recentemente, Lançamentos, Favoritos e categorias. */
@Composable
fun Dashboard(vm: MainVm, onSeries: (Item) -> Unit) {
    val ctx = LocalContext.current
    val sections by vm.sections.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val seen by vm.seen.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()

    if (sections.isEmpty() && history.isEmpty()) {
        if (loading) SkeletonRows() else EmptyState(Icons.Rounded.VideoLibrary, "Sua lista ainda não tem filmes ou séries.")
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        if (history.isNotEmpty()) item(key = "continue") { ContinueRow(history, vm, favs) }
        sections.forEach { sec ->
            item(key = "sec_" + sec.title) { Carousel(sec, vm, onSeries, favs, seen) }
        }
    }
}

/** Barra de ordenação e filtros (qualidade e década). */
@Composable
fun FilterBar(vm: MainVm, tab: Tab) {
    val sort by vm.sort.collectAsStateWithLifecycle()
    val quality by vm.quality.collectAsStateWithLifecycle()
    val decade by vm.decade.collectAsStateWithLifecycle()

    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            MenuChip("Ordem: ${sort.label}", sort != SortMode.DEFAULT, Icons.Rounded.SwapVert) { close ->
                SortMode.entries.forEach { m ->
                    DropdownMenuItem(text = { Text(m.label) }, onClick = { vm.sort.value = m; close() })
                }
            }
        }
        item {
            MenuChip(quality?.let { "Qualidade: $it" } ?: "Qualidade", quality != null, Icons.Rounded.HighQuality) { close ->
                DropdownMenuItem(text = { Text("Todas") }, onClick = { vm.quality.value = null; close() })
                listOf("4K", "FHD", "HD", "SD").forEach { q ->
                    DropdownMenuItem(text = { Text(q) }, onClick = { vm.quality.value = q; close() })
                }
            }
        }
        if (tab != Tab.LIVE) item {
            val label = when (decade) { null -> "Ano"; 2020 -> "2020+"; 1900 -> "Antes de 2000"; else -> "${decade}s" }
            MenuChip(label, decade != null, Icons.Rounded.CalendarMonth) { close ->
                DropdownMenuItem(text = { Text("Todos") }, onClick = { vm.decade.value = null; close() })
                listOf(2020 to "2020+", 2010 to "2010s", 2000 to "2000s", 1900 to "Antes de 2000").forEach { (d, t) ->
                    DropdownMenuItem(text = { Text(t) }, onClick = { vm.decade.value = d; close() })
                }
            }
        }
    }
}

@Composable
private fun MenuChip(label: String, active: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable (close: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        AssistChip(
            onClick = { open = true }, label = { Text(label, maxLines = 1) },
            leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) },
            shape = MaterialTheme.shapes.large,
            colors = AssistChipDefaults.assistChipColors(
                containerColor = if (active) Verde else MaterialTheme.colorScheme.surface,
                labelColor = androidx.compose.ui.graphics.Color.White,
                leadingIconContentColor = if (active) Amarelo else MaterialTheme.colorScheme.onSurfaceVariant,
            ),
            border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = MaterialTheme.colorScheme.outlineVariant),
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) { content { open = false } }
    }
}

/** Esqueleto de carregamento em fileiras (canais, episódios). */
@Composable
fun SkeletonRows() {
    Column(Modifier.fillMaxSize().padding(top = 8.dp)) {
        repeat(9) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).height(72.dp).clip(MaterialTheme.shapes.medium).shimmer())
        }
    }
}

/** Esqueleto de carregamento em grade de cartazes. */
@Composable
fun SkeletonGrid() {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(112.dp), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        userScrollEnabled = false, modifier = Modifier.fillMaxSize(),
    ) {
        items(12) { Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(MaterialTheme.shapes.medium).shimmer()) }
    }
}
