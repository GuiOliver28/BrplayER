package br.com.brplay.data

import java.text.Normalizer

/** Extração de metadados a partir do nome do item e limpeza para detectar duplicadas. */
object Meta {
    private val yearRx = Regex("""(?<!\d)(19[5-9]\d|20[0-4]\d)(?!\d)""")
    private val q4k = Regex("""\b(4k|uhd|2160p?)\b""")
    private val qfhd = Regex("""\b(fhd|full ?hd|1080p?)\b""")
    private val qhd = Regex("""\b(hd|720p?)\b""")
    private val qsd = Regex("""\b(sd|480p?)\b""")
    private val qualityRx = Regex("""\b(4k|uhd|2160p?|fhd|full ?hd|1080p?|hd|720p?|sd|480p?)\b""", RegexOption.IGNORE_CASE)
    private val bracketRx = Regex("""[\[(].*?[\])]""")
    private val adultRx = Regex("""adult|xxx|\+18|18\+|porn|hentai|er[óo]tic|sexo""", RegexOption.IGNORE_CASE)
    private val diacritics = Regex("""\p{Mn}+""")
    private val nonAlnum = Regex("""[^a-z0-9]+""")

    fun year(name: String): Int = yearRx.findAll(name).lastOrNull()?.value?.toInt() ?: 0

    fun quality(name: String, group: String): String {
        val t = "$name $group".lowercase()
        return when {
            q4k.containsMatchIn(t) -> "4K"
            qfhd.containsMatchIn(t) -> "FHD"
            qhd.containsMatchIn(t) -> "HD"
            qsd.containsMatchIn(t) -> "SD"
            else -> ""
        }
    }

    fun isAdult(name: String, group: String): Boolean = adultRx.containsMatchIn(group) || adultRx.containsMatchIn(name)

    /** Título normalizado: sem acento, ano, qualidade e pontuação. [LEG]/[DUB] são mantidos para não fundir versões. */
    fun norm(name: String): String {
        var s = qualityRx.replace(name, " ")
        s = yearRx.replace(s, " ")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
        s = diacritics.replace(s, "").lowercase()
        return nonAlnum.replace(s, " ").trim()
    }

    /** Título limpo para buscar capa no TMDB. */
    fun cleanTitle(name: String): String = norm(bracketRx.replace(name, " "))

    /** Remove filmes e séries Xtream repetidos (mesmo título normalizado + ano). Canais e episódios não são tocados. */
    fun dedupe(list: List<Item>): List<Item> {
        val seen = HashSet<String>(list.size / 2)
        val out = ArrayList<Item>(list.size)
        for (i in list) {
            val candidate = i.kind == Kind.MOVIE || (i.kind == Kind.SERIES && i.url.isEmpty() && !i.seriesId.startsWith("m3u:"))
            if (!candidate) { out += i; continue }
            val key = "${i.kind.name}|${norm(i.name)}|${i.year}"
            if (seen.add(key)) out += i
        }
        return out
    }
}
