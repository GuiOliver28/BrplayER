package br.com.brplay.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.R

private val Azulado = Color(0xFF2E9BFF)

/** Tela de carregamento: logo, anel girando, barra tricolor e as etapas Filmes / Séries / TV ao vivo. */
@Composable
fun LoadingScreen(vm: MainVm) {
    val stage by vm.stage.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val active by vm.active.collectAsStateWithLifecycle()

    // fração real: cada etapa concluída vale 1/3, a em andamento vale meia etapa
    val fraction = if (stage.xtream) {
        val v = listOf(stage.movies, stage.series, stage.live)
        (v.count { it == 1 } + v.count { it == 0 } * 0.5f) / 3f
    } else null

    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF06222A), Color(0xFF06122B), Color(0xFF0A2A1C)))
        ),
        contentAlignment = Alignment.Center,
    ) {
        // raios decorativos nas cores da bandeira
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            drawLine(Brush.linearGradient(listOf(Color.Transparent, Verde.copy(alpha = .55f), Color.Transparent)),
                Offset(-w * .1f, h * .35f), Offset(w * .45f, -h * .05f), strokeWidth = 14f, cap = StrokeCap.Round)
            drawLine(Brush.linearGradient(listOf(Color.Transparent, Amarelo.copy(alpha = .5f), Color.Transparent)),
                Offset(w * .6f, h * 1.05f), Offset(w * 1.1f, h * .55f), strokeWidth = 12f, cap = StrokeCap.Round)
            drawLine(Brush.linearGradient(listOf(Color.Transparent, Azulado.copy(alpha = .5f), Color.Transparent)),
                Offset(w * .75f, h * .98f), Offset(w * 1.05f, h * .7f), strokeWidth = 8f, cap = StrokeCap.Round)
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(painterResource(R.drawable.logo_bp), "BR Play", Modifier.width(210.dp))
            Spacer(Modifier.height(28.dp))
            SpinnerRing()
            Spacer(Modifier.height(20.dp))
            Text("BR PLAY", style = MaterialTheme.typography.titleLarge, color = Color.White)
            if (active != null) Text(active!!.name, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Spacer(Modifier.height(18.dp))
            TricolorBar(fraction, Modifier.fillMaxWidth().widthIn(max = 420.dp))
            Spacer(Modifier.height(18.dp))

            if (stage.xtream) {
                Pill(Icons.Rounded.Movie, "Carregando Filmes…", "Filmes", stage.movies, stage.movieCount, Verde)
                Spacer(Modifier.height(10.dp))
                Pill(Icons.Rounded.Slideshow, "Carregando Séries…", "Séries", stage.series, stage.seriesCount, Amarelo)
                Spacer(Modifier.height(10.dp))
                Pill(Icons.Rounded.LiveTv, "Carregando TV ao vivo…", "TV ao vivo", stage.live, stage.liveCount, Azulado)
            } else {
                Text(status.ifBlank { "Preparando sua lista…" }, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(28.dp))
            Text("BR Play · by @MonstroGuilher", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SpinnerRing() {
    val t = rememberInfiniteTransition(label = "ring")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "a")
    Canvas(Modifier.size(84.dp).rotate(angle)) {
        val stroke = 9f
        drawArc(Color.White.copy(alpha = .12f), 0f, 360f, false, topLeft = Offset(stroke, stroke),
            size = Size(size.width - 2 * stroke, size.height - 2 * stroke), style = Stroke(stroke))
        drawArc(
            Brush.sweepGradient(listOf(Verde, Amarelo, Azulado, Verde)), -90f, 270f, false,
            topLeft = Offset(stroke, stroke), size = Size(size.width - 2 * stroke, size.height - 2 * stroke),
            style = Stroke(stroke, cap = StrokeCap.Round),
        )
    }
}

@Composable
private fun TricolorBar(fraction: Float?, modifier: Modifier) {
    val shape = RoundedCornerShape(50)
    Box(modifier.height(10.dp).clip(shape).background(Color.White.copy(alpha = .10f)).border(1.dp, Color.White.copy(alpha = .25f), shape)) {
        if (fraction != null) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0.04f, 1f)).clip(shape)
                .background(Brush.horizontalGradient(listOf(Verde, Amarelo, Azulado))))
        } else {
            val t = rememberInfiniteTransition(label = "bar")
            val x by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse), label = "x")
            Box(Modifier.fillMaxHeight().fillMaxWidth(.35f).offset(x = (x * 180).dp).clip(shape)
                .background(Brush.horizontalGradient(listOf(Verde, Amarelo, Azulado))))
        }
    }
}

@Composable
private fun Pill(icon: ImageVector, loadingText: String, doneLabel: String, state: Int, count: Int, color: Color) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().widthIn(max = 420.dp).clip(shape).background(Color.Black.copy(alpha = .25f))
            .border(1.5.dp, color.copy(alpha = if (state == -1) .25f else .9f), shape).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(
            when (state) { 1 -> "$doneLabel carregados"; 0 -> loadingText; else -> "$doneLabel · aguardando" },
            Modifier.weight(1f), color = Color.White, style = MaterialTheme.typography.bodyLarge,
        )
        when (state) {
            1 -> Text("$count", color = color, style = MaterialTheme.typography.bodyLarge)
            0 -> Text("…", color = color, style = MaterialTheme.typography.bodyLarge)
            else -> {}
        }
        if (state == 1) { Spacer(Modifier.width(8.dp)); Icon(Icons.Rounded.CheckCircle, null, tint = color, modifier = Modifier.size(20.dp)) }
    }
}
