package br.com.brplay.data

import java.io.InputStream

object M3uParser {
    // atributos com aspas ou sem aspas (tvg-id=abc)
    private val attr = Regex("""([\w-]+)=(?:"([^"]*)"|([^\s",]+))""")
    private val movieExt = Regex("""\.(mp4|mkv|avi|mov|wmv|flv|webm)(\?.*)?$""", RegexOption.IGNORE_CASE)
    private val movieGroup = Regex("""filme|movie|vod|cine|lancamento|lançamento""", RegexOption.IGNORE_CASE)
    private val seriesGroup = Regex("""s[eé]rie|novela|anime|season|temporada""", RegexOption.IGNORE_CASE)

    fun parse(input: InputStream, onProgress: (Int) -> Unit = {}): List<Item> {
        val out = ArrayList<Item>(4096)
        var name = ""; var logo = ""; var group = ""; var epg = ""
        var pending = false
        val buf = java.io.BufferedInputStream(input, 64 * 1024)
        buf.mark(64 * 1024)
        val head = ByteArray(64 * 1024)
        val n = buf.read(head).coerceAtLeast(0)
        buf.reset()
        buf.bufferedReader(detectCharset(head, n)).useLines { lines ->
            for (raw in lines) {
                val line = raw.trim().removePrefix("﻿")
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTINF", true)) {
                    val comma = line.lastIndexOf(',')
                    val head = if (comma >= 0) line.substring(0, comma) else line
                    name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                    logo = ""; group = ""; epg = ""
                    for (m in attr.findAll(head)) {
                        val v = m.groupValues[2].ifEmpty { m.groupValues[3] }
                        when (m.groupValues[1].lowercase()) {
                            "tvg-logo" -> logo = v
                            "group-title" -> group = v
                            "tvg-id" -> epg = v
                            "tvg-name" -> if (name.isBlank()) name = v
                        }
                    }
                    pending = true
                } else if (line.startsWith("#EXTGRP:", true)) {
                    if (group.isBlank()) group = line.substringAfter(':').trim()
                } else if (!line.startsWith("#")) {
                    if (pending && (line.contains("://") || line.startsWith("/"))) {
                        // formato Kodi: url|User-Agent=...  -> descarta os cabeçalhos
                        val url = if (line.contains('|') && line.substringAfter('|').contains('=')) line.substringBefore('|') else line
                        out += Item(
                            kind = kindOf(url, group, name),
                            name = name.ifBlank { url.substringAfterLast('/') },
                            url = url,
                            logo = logo,
                            group = group.ifBlank { "Sem categoria" },
                            epgId = epg,
                        )
                        if (out.size % 1000 == 0) onProgress(out.size)
                    }
                    pending = false
                }
            }
        }
        return out
    }

    private val seriesTitle = Regex("""\bS\d{1,2}\s?E\d{1,3}\b|\bT\d{1,2}\s?E\d{1,3}\b|\b\d{1,2}x\d{2,3}\b|\b(temporada|season)\s*\d+|\[S\d+\]""", RegexOption.IGNORE_CASE)
    private val seriesUrl = Regex("""/s\d{1,2}e\d{1,3}[/._-]|/(season|temporada)[/_-]?\d""", RegexOption.IGNORE_CASE)
    private val liveGroup = Regex("""ao vivo|\blive\b|canais|\btv\b|esporte|not[ií]cias|\bnews\b|24h|aberto""", RegexOption.IGNORE_CASE)

    /** Classificação: caminho da URL (Xtream) > grupo > título > extensão/URL. Sem pista, vira canal ao vivo. */
    private fun kindOf(url: String, group: String, name: String): Kind = when {
        "/series/" in url -> Kind.SERIES
        "/movie/" in url -> Kind.MOVIE
        "/live/" in url -> Kind.LIVE
        seriesGroup.containsMatchIn(group) -> Kind.SERIES
        liveGroup.containsMatchIn(group) && !movieExt.containsMatchIn(url) -> Kind.LIVE
        movieGroup.containsMatchIn(group) -> if (seriesTitle.containsMatchIn(name)) Kind.SERIES else Kind.MOVIE
        seriesTitle.containsMatchIn(name) || seriesUrl.containsMatchIn(url) -> Kind.SERIES
        movieExt.containsMatchIn(url) -> Kind.MOVIE
        else -> Kind.LIVE
    }

    /** Junta episódios soltos ("Série S01E02") em uma única série com episódios dentro. */
    fun groupSeries(list: List<Item>): List<Item> {
        val out = ArrayList<Item>(list.size)
        val heads = HashSet<String>()
        for (i in list) {
            if (i.kind != Kind.SERIES || i.url.isEmpty() || i.seriesId.isNotEmpty()) { out += i; continue }
            var found: MatchResult? = null
            for (r in epPatterns) { found = r.matchEntire(i.name.trim()); if (found != null) break }
            val m = found
            val title = m?.groupValues?.get(1)?.trim()?.trimEnd('-', '–', '_', '.', ':', '|', ' ').orEmpty()
            if (m == null || title.length < 2) { out += i; continue }
            val sNum = m.groupValues[2].toInt()
            val eNum = m.groupValues[3].toInt()
            val rest = m.groupValues[4].trim().trimStart('-', '–', '_', '.', ':', '|', ' ')
            val sid = "m3u:" + title.lowercase()
            if (heads.add(sid)) out += Item(Kind.SERIES, title, "", i.logo, i.group, seriesId = sid)
            out += i.copy(
                name = "T$sNum · E$eNum" + if (rest.isNotBlank()) "  $rest" else "",
                seriesId = sid, group = "Temporada $sNum",
            )
        }
        return out
    }

    /** UTF-8 se o começo do arquivo for válido; senão Windows-1252 (cobre ISO-8859-1). */
    private fun detectCharset(head: ByteArray, n: Int): java.nio.charset.Charset {
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
        return try {
            dec.decode(java.nio.ByteBuffer.wrap(head, 0, (n - 3).coerceAtLeast(0)))
            Charsets.UTF_8
        } catch (e: java.nio.charset.CharacterCodingException) {
            java.nio.charset.Charset.forName("windows-1252")
        }
    }
}
