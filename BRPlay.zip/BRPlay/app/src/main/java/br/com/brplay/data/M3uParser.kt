package br.com.brplay.data

import java.io.InputStream

object M3uParser {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val movieExt = Regex("""\.(mp4|mkv|avi|mov|wmv|flv|webm)(\?.*)?$""", RegexOption.IGNORE_CASE)
    private val movieGroup = Regex("""filme|movie|vod|cine|lancamento|lançamento""", RegexOption.IGNORE_CASE)
    private val seriesGroup = Regex("""s[eé]rie|novela|anime|season|temporada""", RegexOption.IGNORE_CASE)

    fun parse(input: InputStream, onProgress: (Int) -> Unit = {}): List<Item> {
        val out = ArrayList<Item>(4096)
        var name = ""; var logo = ""; var group = ""; var epg = ""
        var pending = false
        input.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (raw in lines) {
                val line = raw.trim().removePrefix("﻿")
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTINF", true)) {
                    val comma = line.lastIndexOf(',')
                    val head = if (comma >= 0) line.substring(0, comma) else line
                    name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                    logo = ""; group = ""; epg = ""
                    for (m in attr.findAll(head)) {
                        val v = m.groupValues[2]
                        when (m.groupValues[1].lowercase()) {
                            "tvg-logo" -> logo = v
                            "group-title" -> group = v
                            "tvg-id" -> epg = v
                            "tvg-name" -> if (name.isBlank()) name = v
                        }
                    }
                    pending = true
                } else if (line.startsWith("#EXTGRP:", true)) {
                    if (group.isBlank()) group = line.substringAfter(':').trim()
                } else if (!line.startsWith("#")) {
                    if (pending && (line.contains("://") || line.startsWith("/"))) {
                        val url = line
                        out += Item(
                            kind = kindOf(url, group),
                            name = name.ifBlank { url.substringAfterLast('/') },
                            url = url,
                            logo = logo,
                            group = group.ifBlank { "Sem categoria" },
                            epgId = epg,
                        )
                        if (out.size % 1000 == 0) onProgress(out.size)
                    }
                    pending = false
                }
            }
        }
        return out
    }

    private fun kindOf(url: String, group: String): Kind = when {
        "/series/" in url -> Kind.SERIES
        "/movie/" in url -> Kind.MOVIE
        seriesGroup.containsMatchIn(group) -> Kind.SERIES
        movieExt.containsMatchIn(url) || movieGroup.containsMatchIn(group) -> Kind.MOVIE
        else -> Kind.LIVE
    }
}
