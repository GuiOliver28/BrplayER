package br.com.brplay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.SyncStatus
import br.com.brplay.SyncUi
import br.com.brplay.data.Kind

/** "Gerenciar sincronização": cada botão atualiza só uma parte da lista e mostra o resultado ao lado. */
@Composable
fun SyncScreen(vm: MainVm, onBack: () -> Unit) {
    val ks by vm.kindSync.collectAsStateWithLifecycle()
    val busy by vm.syncing.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val locked = busy || loading

    SubScaffold("Gerenciar sincronização", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Cada botão baixa só aquela parte da lista, sem mexer nas outras. Se uma falhar, as demais continuam funcionando e o conteúdo antigo é mantido.",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SyncRow("Atualizar Canais Ao Vivo", Icons.Rounded.LiveTv, ks[Kind.LIVE], !locked) { vm.syncKinds(listOf(Kind.LIVE)) }
            SyncRow("Atualizar Filmes", Icons.Rounded.Movie, ks[Kind.MOVIE], !locked) { vm.syncKinds(listOf(Kind.MOVIE)) }
            SyncRow("Atualizar Séries", Icons.Rounded.Slideshow, ks[Kind.SERIES], !locked) { vm.syncKinds(listOf(Kind.SERIES)) }
            SyncRow("Atualizar TUDO", Icons.Rounded.Autorenew, null, !locked) { vm.syncKinds(listOf(Kind.LIVE, Kind.MOVIE, Kind.SERIES)) }
        }
    }
}

@Composable
private fun SyncRow(title: String, icon: ImageVector, ui: SyncUi?, enabled: Boolean, onClick: () -> Unit) {
    val shape = MaterialTheme.shapes.large
    val color = when (ui?.status) {
        SyncStatus.OK -> Verde
        SyncStatus.ERROR -> MaterialTheme.colorScheme.error
        SyncStatus.LOADING -> Amarelo
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Row(
        Modifier.fillMaxWidth().clip(shape).tvFocus(shape).background(MaterialTheme.colorScheme.surface)
            .clickable(enabled = enabled, onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (enabled) Amarelo else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            val text = ui?.text ?: ""
            if (text.isNotEmpty()) Text(text, style = MaterialTheme.typography.labelMedium, color = color)
        }
        if (ui?.status == SyncStatus.LOADING) CircularProgressIndicator(color = Amarelo, strokeWidth = 3.dp, modifier = Modifier.size(24.dp))
    }
}
