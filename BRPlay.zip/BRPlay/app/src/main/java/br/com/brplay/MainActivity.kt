package br.com.brplay

import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.runtime.*
import br.com.brplay.data.Item
import br.com.brplay.ui.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

sealed interface Screen {
    data object Home : Screen
    data object Playlists : Screen
    data object Add : Screen
    data object About : Screen
    data object Settings : Screen
    data object Sync : Screen
    data class Series(val item: Item) : Screen
}

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    private fun isTv(): Boolean =
        packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            packageManager.hasSystemFeature("amazon.hardware.fire_tv") ||
            (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION

    override fun onResume() {
        super.onResume()
        vm.reloadHistory()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        // registra qualquer falha inesperada em arquivo (brplay.log) antes de o app fechar
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { br.com.brplay.data.Store(applicationContext).logError("CRASH em ${t.name}", e) }
            prev?.uncaughtException(t, e)
        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            BrTheme {
                val orientation by vm.orientation.collectAsStateWithLifecycle()
                LaunchedEffect(orientation) {
                    requestedOrientation = when {
                        orientation == 1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                        orientation == 2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        isTv() -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE   // TV é sempre paisagem
                        else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED          // segue o giro do sistema
                    }
                }
                val toastCtx = androidx.compose.ui.platform.LocalContext.current
                LaunchedEffect(Unit) { vm.toasts.collect { android.widget.Toast.makeText(toastCtx, it, android.widget.Toast.LENGTH_LONG).show() } }
                val booting by vm.booting.collectAsStateWithLifecycle()
                val loadingNow by vm.loading.collectAsStateWithLifecycle()
                val itemsNow by vm.items.collectAsStateWithLifecycle()
                var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                val lists by vm.playlists.collectAsStateWithLifecycle()
                // Gesto de voltar com animação (Android 14+): a tela encolhe enquanto o dedo arrasta
                var backProgress by remember { mutableFloatStateOf(0f) }
                PredictiveBackHandler(screen != Screen.Home) { progress ->
                    try {
                        progress.collect { backProgress = it.progress }
                        screen = when {
                            screen is Screen.Add && lists.isNotEmpty() -> Screen.Playlists
                            screen is Screen.About -> Screen.Settings
                            else -> Screen.Home
                        }
                        backProgress = 0f
                    } catch (e: CancellationException) {
                        backProgress = 0f
                        throw e
                    }
                }
                // tela de carregamento enquanto a primeira lista não fica pronta
                if (screen == Screen.Home && (booting || (loadingNow && itemsNow.isEmpty()))) {
                    LoadingScreen(vm)
                    return@BrTheme
                }
                Box(
                    Modifier.fillMaxSize()
                        .graphicsLayer {
                            val sc = 1f - 0.08f * backProgress
                            scaleX = sc; scaleY = sc
                            alpha = 1f - 0.25f * backProgress
                        }
                        .then(if (backProgress > 0f) Modifier.clip(RoundedCornerShape(28.dp)) else Modifier),
                ) {
                when (val s = screen) {
                    Screen.Home -> HomeScreen(
                        vm,
                        onPlaylists = { screen = Screen.Playlists },
                        onAdd = { screen = Screen.Add },
                        onSeries = { screen = Screen.Series(it) },
                        onSettings = { screen = Screen.Settings },
                        onSync = { screen = Screen.Sync },
                    )
                    Screen.About -> AboutScreen(onBack = { screen = Screen.Settings })
                    Screen.Sync -> SyncScreen(vm, onBack = { screen = Screen.Home })
                    Screen.Settings -> SettingsScreen(vm, onBack = { screen = Screen.Home }, onAbout = { screen = Screen.About }, onSync = { screen = Screen.Sync })
                    Screen.Playlists -> PlaylistsScreen(vm, onBack = { screen = Screen.Home }, onAdd = { screen = Screen.Add })
                    Screen.Add -> AddPlaylistScreen(
                        vm,
                        onBack = { screen = if (lists.isNotEmpty()) Screen.Playlists else Screen.Home },
                        onDone = { screen = Screen.Home },
                    )
                    is Screen.Series -> SeriesScreen(s.item, vm, onBack = { screen = Screen.Home })
                }
                }
            }
        }
    }
}
