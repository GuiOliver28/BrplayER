package br.com.brplay

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import br.com.brplay.data.Item
import br.com.brplay.ui.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

sealed interface Screen {
    data object Home : Screen
    data object Playlists : Screen
    data object Add : Screen
    data object About : Screen
    data object Settings : Screen
    data class Series(val item: Item) : Screen
}

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    override fun onResume() {
        super.onResume()
        vm.reloadHistory()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            BrTheme {
                var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                val lists by vm.playlists.collectAsStateWithLifecycle()
                BackHandler(screen != Screen.Home) {
                    screen = when {
                        screen is Screen.Add && lists.isNotEmpty() -> Screen.Playlists
                        screen is Screen.About -> Screen.Settings
                        else -> Screen.Home
                    }
                }
                when (val s = screen) {
                    Screen.Home -> HomeScreen(
                        vm,
                        onPlaylists = { screen = Screen.Playlists },
                        onAdd = { screen = Screen.Add },
                        onSeries = { screen = Screen.Series(it) },
                        onSettings = { screen = Screen.Settings },
                    )
                    Screen.About -> AboutScreen(onBack = { screen = Screen.Settings })
                    Screen.Settings -> SettingsScreen(vm, onBack = { screen = Screen.Home }, onAbout = { screen = Screen.About })
                    Screen.Playlists -> PlaylistsScreen(vm, onBack = { screen = Screen.Home }, onAdd = { screen = Screen.Add })
                    Screen.Add -> AddPlaylistScreen(
                        vm,
                        onBack = { screen = if (lists.isNotEmpty()) Screen.Playlists else Screen.Home },
                        onDone = { screen = Screen.Home },
                    )
                    is Screen.Series -> SeriesScreen(s.item, vm, onBack = { screen = Screen.Home })
                }
            }
        }
    }
}
