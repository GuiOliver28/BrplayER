package br.com.brplay

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.brplay.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Calendar
import java.util.UUID

enum class Tab { HOME, LIVE, MOVIES, SERIES, FAVORITES }

enum class SortMode(val label: String) {
    DEFAULT("Padrão"), AZ("A–Z"), ZA("Z–A"), RECENT("Mais recentes"), YEAR("Ano"),
}

/** Uma fileira da tela Início. */
data class Section(val title: String, val items: List<Item>)

@OptIn(FlowPreview::class)
class MainVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    init { Tmdb.init(store) }

    // ---------- configurações ----------
    val dedupe = MutableStateFlow(store.bool("dedupe", true))
    val bufferMode = MutableStateFlow(store.int("buffer", 1))
    val tmdbKey = MutableStateFlow(store.str("tmdb"))
    val hasPin = MutableStateFlow(store.str("pin").isNotEmpty())
    val hideAdult = MutableStateFlow(store.bool("hideAdult", false))
    val unlocked = MutableStateFlow(false)
    val adultLocked: StateFlow<Boolean> = combine(hasPin, hideAdult, unlocked) { p, h, u -> p && h && !u }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // ---------- listas e conteúdo ----------
    val playlists = MutableStateFlow(store.playlists())
    val activeId = MutableStateFlow(store.activeId)
    private var raw: List<Item> = emptyList()
    val items = MutableStateFlow<List<Item>>(emptyList())
    val loading = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val errorMsg = MutableStateFlow<String?>(null)

    val tab = MutableStateFlow(Tab.HOME)
    val category = MutableStateFlow<String?>(null)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(SortMode.DEFAULT)
    val quality = MutableStateFlow<String?>(null)
    val decade = MutableStateFlow<Int?>(null)
    val favorites = MutableStateFlow(store.favorites())
    val history = MutableStateFlow(store.history())
    val seen = MutableStateFlow(store.seen())

    val active: StateFlow<Playlist?> = combine(playlists, activeId) { l, id -> l.firstOrNull { it.id == id } ?: l.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private fun Kind.matches(t: Tab) = when (t) {
        Tab.LIVE -> this == Kind.LIVE
        Tab.MOVIES -> this == Kind.MOVIE
        Tab.SERIES -> this == Kind.SERIES
        else -> false
    }

    val categories: StateFlow<List<String>> = combine(items, tab, adultLocked) { all, t, locked ->
        if (t == Tab.HOME || t == Tab.FAVORITES) emptyList()
        else all.asSequence().filter { it.kind.matches(t) && !it.isEpisode && !(locked && it.adult) }
            .map { it.group }.distinct().toList()
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val f1 = combine(tab, category, query.debounce(180)) { t, c, q -> Triple(t, c, q) }

    private data class F2(val sort: SortMode, val quality: String?, val decade: Int?, val locked: Boolean)

    private val f2 = combine(sort, quality, decade, adultLocked) { s, q, d, l -> F2(s, q, d, l) }

    private fun decadeOk(year: Int, d: Int?): Boolean = when {
        d == null -> true
        year == 0 -> false
        d >= 2020 -> year >= 2020
        d == 1900 -> year < 2000
        else -> year in d..(d + 9)
    }

    val visible: StateFlow<List<Item>> = combine(items, f1, f2, favorites) { all, (t, cat, q), f, favs ->
        val nq = norm(q)
        if (t == Tab.HOME && nq.isEmpty()) return@combine emptyList<Item>()
        val src = if (f.sort == SortMode.RECENT) all.asReversed() else all
        val out = src.filter { i ->
            val inTab = if (t == Tab.FAVORITES) i.key in favs
            else if (t == Tab.HOME) !i.isEpisode
            else i.kind.matches(t) && !i.isEpisode && (cat == null || i.group == cat)
            inTab && !(f.locked && i.adult) &&
                (f.quality == null || i.quality == f.quality) && decadeOk(i.year, f.decade) &&
                (nq.isEmpty() || norm(i.name).contains(nq))
        }
        when (f.sort) {
            SortMode.AZ -> out.sortedBy { it.name.lowercase() }
            SortMode.ZA -> out.sortedByDescending { it.name.lowercase() }
            SortMode.YEAR -> out.sortedByDescending { it.year }
            else -> out
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Fileiras da tela Início. */
    val sections: StateFlow<List<Section>> = combine(items, favorites, adultLocked) { all, favs, locked ->
        val base = all.filter { !it.isEpisode && !(locked && it.adult) }
        val vod = base.filter { it.kind != Kind.LIVE }
        val thisYear = Calendar.getInstance().get(Calendar.YEAR)
        val out = ArrayList<Section>()
        vod.takeLast(20).asReversed().takeIf { it.isNotEmpty() }?.let { out += Section("Adicionados recentemente", it) }
        vod.filter { it.year >= thisYear - 1 }.sortedByDescending { it.year }.take(20)
            .takeIf { it.isNotEmpty() }?.let { out += Section("Lançamentos", it) }
        base.filter { it.key in favs }.take(20).takeIf { it.isNotEmpty() }?.let { out += Section("Meus favoritos", it) }
        vod.groupBy { it.group }.entries.sortedByDescending { it.value.size }.take(6)
            .forEach { (g, l) -> out += Section(g, l.take(15)) }
        out as List<Section>
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase().trim()

    init {
        val a = playlists.value.firstOrNull { it.id == activeId.value } ?: playlists.value.firstOrNull()
        if (a != null) openPlaylist(a)
    }

    // ---------- ações ----------
    fun setTab(t: Tab) { tab.value = t; category.value = null }

    fun toggleFavorite(i: Item) {
        val n = favorites.value.toMutableSet().apply { if (!add(i.key)) remove(i.key) }
        favorites.value = n
        store.saveFavorites(n)
    }

    fun reloadHistory() { history.value = store.history(); seen.value = store.seen() }
    fun clearHistory() { store.clearHistory(); reloadHistory() }

    private fun process(list: List<Item>): List<Item> {
        var r = M3uParser.groupSeries(list)
        if (dedupe.value) r = Meta.dedupe(r)
        return r
    }

    private fun setItems(list: List<Item>) { raw = list; items.value = process(list) }

    fun setDedupe(b: Boolean) {
        dedupe.value = b; store.putBool("dedupe", b)
        viewModelScope.launch(Dispatchers.Default) { items.value = process(raw) }
    }

    fun setBufferMode(m: Int) { bufferMode.value = m; store.putInt("buffer", m) }
    fun setTmdbKey(k: String) { tmdbKey.value = k.trim(); store.putStr("tmdb", k.trim()) }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun checkPin(pin: String) = hasPin.value && sha(pin) == store.str("pin")

    fun setPin(pin: String) {
        store.putStr("pin", sha(pin)); hasPin.value = true
        hideAdult.value = true; store.putBool("hideAdult", true); unlocked.value = false
    }

    fun unlock(pin: String): Boolean { val ok = checkPin(pin); if (ok) unlocked.value = true; return ok }
    fun lockAgain() { unlocked.value = false }

    fun removePin(pin: String): Boolean {
        if (!checkPin(pin)) return false
        store.putStr("pin", ""); hasPin.value = false
        hideAdult.value = false; store.putBool("hideAdult", false); unlocked.value = false
        return true
    }

    /** Abre uma lista: usa o cache se existir; senão baixa. */
    fun openPlaylist(p: Playlist) {
        store.activeId = p.id; activeId.value = p.id
        category.value = null; query.value = ""
        val cached = store.loadItems(p.id)
        if (cached != null) viewModelScope.launch(Dispatchers.Default) { setItems(cached) }
        else { setItems(emptyList()); refresh(p) }
    }

    fun refresh(p: Playlist? = active.value) {
        if (p == null || loading.value) return
        loading.value = true; errorMsg.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = fetch(p)
                store.saveItems(p.id, list)
                if (activeId.value == p.id) setItems(list)
            } catch (e: Exception) {
                errorMsg.value = friendly(e)
            } finally {
                loading.value = false; status.value = ""
            }
        }
    }

    private fun fetch(p: Playlist): List<Item> {
        status.value = "Carregando lista…"
        val list = when (p.type) {
            "xtream" -> Xtream(p).loadAll { status.value = it }
            "file" -> File(p.source).inputStream().use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }
            else -> Net.open(p.source, p.ua).use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }
        }
        if (list.isEmpty()) error("Nenhum item encontrado nessa lista")
        return list
    }

    /** Valida e adiciona uma lista. [done] roda na thread principal com true se deu certo. */
    fun add(p: Playlist, done: (Boolean) -> Unit) {
        if (loading.value) return
        loading.value = true; errorMsg.value = null
        viewModelScope.launch(Dispatchers.IO) {
            var ok = false
            try {
                val list = fetch(p)
                store.saveItems(p.id, list)
                val all = playlists.value + p
                store.savePlaylists(all)
                playlists.value = all
                store.activeId = p.id; activeId.value = p.id
                category.value = null; query.value = ""
                setItems(list)
                ok = true
            } catch (e: Exception) {
                errorMsg.value = friendly(e)
                if (p.type == "file") File(p.source).delete()
            } finally {
                loading.value = false; status.value = ""
            }
            withContext(Dispatchers.Main) { done(ok) }
        }
    }

    fun addFile(uri: Uri, name: String, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val f = File(getApplication<Application>().filesDir, "list_$id.m3u")
            val copied = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }.isSuccess
            }
            if (!copied) { errorMsg.value = "Não foi possível ler o arquivo"; done(false); return@launch }
            add(Playlist(id, name.ifBlank { "Meu arquivo" }, "file", f.absolutePath), done)
        }
    }

    fun remove(p: Playlist) {
        val rest = playlists.value.filter { it.id != p.id }
        store.savePlaylists(rest); playlists.value = rest
        store.deletePlaylistData(p)
        if (activeId.value == p.id) {
            val next = rest.firstOrNull()
            if (next != null) openPlaylist(next) else { store.activeId = ""; activeId.value = ""; setItems(emptyList()) }
        }
    }

    fun clearError() { errorMsg.value = null }

    private fun friendly(e: Exception): String = when (e) {
        is java.net.UnknownHostException -> "Servidor não encontrado. Verifique o endereço e a internet."
        is java.net.SocketTimeoutException -> "O servidor demorou demais para responder."
        is java.io.FileNotFoundException -> "Endereço não encontrado (404)."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Falha ao carregar a lista."
    }
}
