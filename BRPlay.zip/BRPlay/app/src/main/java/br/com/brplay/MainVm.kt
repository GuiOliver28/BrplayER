package br.com.brplay

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.brplay.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Calendar
import java.util.UUID

enum class Tab { HOME, MOVIES, SERIES, LIVE, FAVORITES }

enum class SyncStatus { IDLE, LOADING, OK, ERROR }

/** Estado de uma categoria na tela "Gerenciar sincronização". [text] já vem pronto: "Carregando…", "Sucesso (X itens)", "Erro (…)". */
data class SyncUi(val status: SyncStatus = SyncStatus.IDLE, val text: String = "")

/** Chips especiais de categoria (ficam antes das categorias do servidor). */
const val CAT_FAV = "★ Favoritos"
const val CAT_RECENT = "Recentes"

/** Andamento da carga de uma lista: -1 aguardando, 0 carregando, 1 concluída. */
data class Stage(
    val live: Int = -1, val movies: Int = -1, val series: Int = -1,
    val liveCount: Int = 0, val movieCount: Int = 0, val seriesCount: Int = 0,
    val xtream: Boolean = false,
)

enum class SortMode(val label: String) {
    DEFAULT("Padrão"), AZ("A–Z"), ZA("Z–A"), RECENT("Mais recentes"), YEAR("Ano"),
}

/** Uma fileira da tela Início. */
data class Section(val title: String, val items: List<Item>, val live: Boolean = false)

/** Resultado de carregar uma lista: itens + lista com a combinação (UA/endpoint/endereço) que funcionou. */
private val ACCENTS = Regex("\\p{Mn}+")

const val SYNC_EVERY_MS = 6L * 60 * 60 * 1000
const val WATCHDOG_MS = 180_000L

data class Fetched(val items: List<Item>, val playlist: Playlist, val failed: Map<Kind, String> = emptyMap())

@OptIn(FlowPreview::class)
class MainVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    init { Tmdb.init(store); Net.insecure = store.bool("insecureSsl", false) }

    // ---------- configurações ----------
    val dedupe = MutableStateFlow(store.bool("dedupe", true))
    val bufferMode = MutableStateFlow(store.int("buffer", 1))
    val tmdbKey = MutableStateFlow(store.str("tmdb"))
    val hasPin = MutableStateFlow(store.str("pin").isNotEmpty())
    val hideAdult = MutableStateFlow(store.bool("hideAdult", false))
    val unlocked = MutableStateFlow(false)
    val insecureSsl = MutableStateFlow(store.bool("insecureSsl", false))
    /** 0 = automática, 1 = retrato, 2 = paisagem */
    val orientation = MutableStateFlow(store.int("orientation", 0))
    val adultLocked: StateFlow<Boolean> = combine(hasPin, hideAdult, unlocked) { p, h, u -> p && h && !u }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // ---------- listas e conteúdo ----------
    val playlists = MutableStateFlow(store.playlists())
    val activeId = MutableStateFlow(store.activeId)
    private val loadGen = java.util.concurrent.atomic.AtomicInteger(0)
    val items = MutableStateFlow<List<Item>>(emptyList())
    val loading = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val errorMsg = MutableStateFlow<String?>(null)

    val stage = MutableStateFlow(Stage())
    /** true até a primeira lista ficar pronta (mostra a tela de carregamento em vez de telas vazias) */
    val booting = MutableStateFlow(store.playlists().isNotEmpty())
    val searching = MutableStateFlow(false)
    val syncing = MutableStateFlow(false)

    /** Andamento da atualização isolada de cada categoria (canais, filmes, séries). */
    val kindSync = MutableStateFlow<Map<Kind, SyncUi>>(emptyMap())

    /** Quando cada categoria foi atualizada pela última vez (milissegundos; 0/1 = nunca). */
    val lastUpdate = MutableStateFlow<Map<Kind, Long>>(emptyMap())

    fun loadLastUpdate() {
        val id = active.value?.id ?: run { lastUpdate.value = emptyMap(); return }
        val fallback = store.cacheAge(id)
        lastUpdate.value = Kind.values().associateWith { k ->
            (store.str("upd_${id}_${k.name}", "0").toLongOrNull() ?: 0L).let { if (it == 0L) fallback else it }
        }
    }

    private fun markUpdated(pid: String, kinds: Collection<Kind>) {
        val now = System.currentTimeMillis().toString()
        kinds.forEach { store.putStr("upd_${pid}_${it.name}", now) }
    }

    /** Mensagens curtas (Toast) para a tela: ex. falha ao atualizar Filmes. */
    val toasts = kotlinx.coroutines.flow.MutableSharedFlow<String>(extraBufferCapacity = 8)
    val recents = MutableStateFlow(store.recents())
    val searches = MutableStateFlow(store.searches())

    val tab = MutableStateFlow(Tab.HOME)
    val category = MutableStateFlow<String?>(null)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(SortMode.DEFAULT)
    val quality = MutableStateFlow<String?>(null)
    val decade = MutableStateFlow<Int?>(null)
    val favorites = MutableStateFlow(store.favorites())
    val history = MutableStateFlow(store.history())
    val seen = MutableStateFlow(store.seen())

    val active: StateFlow<Playlist?> = combine(playlists, activeId) { l, id -> l.firstOrNull { it.id == id } ?: l.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private fun Kind.matches(t: Tab) = when (t) {
        Tab.LIVE -> this == Kind.LIVE
        Tab.MOVIES -> this == Kind.MOVIE
        Tab.SERIES -> this == Kind.SERIES
        else -> false
    }

    val categories: StateFlow<List<String>> = combine(items, tab, adultLocked) { all, t, locked ->
        if (t == Tab.HOME || t == Tab.FAVORITES) emptyList()
        else all.asSequence().filter { it.kind.matches(t) && !it.isEpisode && !(locked && it.adult) }
            .map { it.group }.distinct().sorted().toList()
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val f1 = combine(tab, category, query.debounce(180)) { t, c, q -> Triple(t, c, q) }

    private data class F2(val sort: SortMode, val quality: String?, val decade: Int?, val locked: Boolean)

    private val f2 = combine(sort, quality, decade, adultLocked) { s, q, d, l -> F2(s, q, d, l) }

    private fun decadeOk(year: Int, d: Int?): Boolean = when {
        d == null -> true
        year == 0 -> false
        d >= 2020 -> year >= 2020
        d == 1900 -> year < 2000
        else -> year in d..(d + 9)
    }

    val visible: StateFlow<List<Item>> = combine(items, f1, f2, favorites, recents) { all, (t, cat, q), f, favs, rec ->
        val recentSet = rec.toHashSet()
        val nq = norm(q)
        if (t == Tab.HOME && nq.isEmpty()) return@combine emptyList<Item>()
        val src = if (f.sort == SortMode.RECENT) all.asReversed() else all
        val out = src.filter { i ->
            val inTab = when {
                t == Tab.FAVORITES -> favs.isNotEmpty() && i.key in favs
                t == Tab.HOME -> !i.isEpisode
                !i.kind.matches(t) || i.isEpisode -> false
                cat == CAT_FAV -> favs.isNotEmpty() && i.key in favs
                cat == CAT_RECENT -> i.url in recentSet
                else -> cat == null || i.group == cat
            }
            inTab && !(f.locked && i.adult) &&
                (f.quality == null || i.quality == f.quality) && (f.decade == null || decadeOk(i.year, f.decade)) &&
                (nq.isEmpty() || matchesQuery(i.name, q, nq))
        }
        if (cat == CAT_RECENT) return@combine out.sortedBy { rec.indexOf(it.url) }
        when (f.sort) {
            SortMode.AZ -> out.sortedBy { it.name.lowercase() }
            SortMode.ZA -> out.sortedByDescending { it.name.lowercase() }
            SortMode.YEAR -> out.sortedByDescending { it.year }
            else -> out
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun thisYear() = Calendar.getInstance().get(Calendar.YEAR)

    private fun rows(vod: List<Item>, favs: Set<String>, label: String): List<Section> {
        val out = ArrayList<Section>()
        val y = thisYear()
        vod.filter { it.year >= y - 1 }.sortedByDescending { it.year }.take(20)
            .takeIf { it.isNotEmpty() }?.let { out += Section("Lançamentos", it) }
        vod.takeLast(20).asReversed().takeIf { it.isNotEmpty() }?.let { out += Section("$label adicionados recentemente", it) }
        if (favs.isNotEmpty()) vod.filter { it.key in favs }.take(20).takeIf { it.isNotEmpty() }?.let { out += Section("Meus favoritos", it) }
        vod.groupBy { it.group }.entries.sortedByDescending { it.value.size }.take(6)
            .forEach { (g, l) -> out += Section(g, l.take(15)) }
        return out
    }

    /** Fileiras da tela Início: seções rotuladas, cada uma com um só tipo de conteúdo. */
    val sections: StateFlow<List<Section>> = combine(items, favorites, adultLocked, tab) { all, favs, locked, t ->
        if (t != Tab.HOME) return@combine emptyList<Section>()
        val base = all.filter { !it.isEpisode && !(locked && it.adult) }
        val movies = base.filter { it.kind == Kind.MOVIE }
        val series = base.filter { it.kind == Kind.SERIES }
        val live = base.filter { it.kind == Kind.LIVE }
        val y = thisYear()
        val out = ArrayList<Section>()
        movies.filter { it.year >= y - 1 }.sortedByDescending { it.year }.take(20)
            .takeIf { it.isNotEmpty() }?.let { out += Section("Filmes em alta", it) }
        series.takeLast(20).asReversed().takeIf { it.isNotEmpty() }?.let { out += Section("Séries recentes", it) }
        live.take(20).takeIf { it.isNotEmpty() }?.let { out += Section("Canais ao vivo", it, live = true) }
        movies.takeLast(20).asReversed().takeIf { it.isNotEmpty() }?.let { out += Section("Filmes adicionados recentemente", it) }
        if (favs.isNotEmpty()) base.filter { it.key in favs }.take(20).takeIf { it.isNotEmpty() }?.let { out += Section("Meus favoritos", it) }
        (movies + series).groupBy { it.group }.entries.sortedByDescending { it.value.size }.take(5)
            .forEach { (g, l) -> out += Section(g, l.take(12)) }
        out as List<Section>
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Carrosséis no topo das abas Filmes e Séries (só aparecem sem filtro/busca). */
    val movieRows: StateFlow<List<Section>> = combine(items, favorites, adultLocked, tab) { all, favs, locked, t ->
        if (t != Tab.MOVIES) return@combine emptyList<Section>()
        rows(all.filter { it.kind == Kind.MOVIE && !it.isEpisode && !(locked && it.adult) }, favs, "Filmes")
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val seriesRows: StateFlow<List<Section>> = combine(items, favorites, adultLocked, tab) { all, favs, locked, t ->
        if (t != Tab.SERIES) return@combine emptyList<Section>()
        rows(all.filter { it.kind == Kind.SERIES && !it.isEpisode && !(locked && it.adult) }, favs, "Séries")
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Resultados da busca global (todos os tipos). A tela filtra por aba [Todos][Filmes][Séries][Ao vivo]. */
    val searchResults: StateFlow<List<Item>> = combine(items, query.debounce(250), searching, adultLocked) { all, q, on, locked ->
        val nq = norm(q)
        if (!on || nq.length < 2) emptyList()
        else all.filter { !it.isEpisode && !(locked && it.adult) && matchesQuery(it.name, q, nq) }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(ACCENTS, "").lowercase().trim()

    /** Busca rápida: primeiro compara direto (barato); só normaliza acentos se o nome tiver caracteres não-ASCII. */
    private fun matchesQuery(name: String, rawQuery: String, nq: String): Boolean {
        if (name.contains(rawQuery.trim(), ignoreCase = true)) return true
        var ascii = true
        for (ch in name) if (ch.code > 127) { ascii = false; break }
        return if (ascii) name.contains(nq, ignoreCase = true) else norm(name).contains(nq)
    }

    init {
        val a = playlists.value.firstOrNull { it.id == activeId.value } ?: playlists.value.firstOrNull()
        if (a != null) openPlaylist(a) else booting.value = false
    }

    // ---------- ações ----------
    fun setTab(t: Tab) { tab.value = t; category.value = null }

    fun toggleFavorite(i: Item) {
        val n = favorites.value.toMutableSet().apply { if (!add(i.key)) remove(i.key) }
        favorites.value = n
        store.saveFavorites(n)
    }

    fun reloadHistory() { history.value = store.history(); seen.value = store.seen(); recents.value = store.recents() }

    fun saveSearch() { store.addSearch(query.value); searches.value = store.searches() }
    fun clearSearches() { store.clearSearches(); searches.value = emptyList() }
    fun setSearching(on: Boolean) { searching.value = on; if (!on) query.value = "" }
    fun clearHistory() { store.clearHistory(); reloadHistory() }

    /** Agrupa episódios, tira duplicadas e capas genéricas. Tudo em segundo plano (nunca na thread principal). */
    private fun process(list: List<Item>): List<Item> =
        Meta.cleanup(M3uParser.groupSeries(list), dedupe.value)

    private fun setItems(processed: List<Item>) { items.value = processed; booting.value = false }

    /** Mudar "remover duplicadas" exige reconstruir a lista: baixa e processa de novo (a tela atual continua visível). */
    fun setDedupe(b: Boolean) {
        dedupe.value = b; store.putBool("dedupe", b)
        syncSilently(force = true)
    }

    fun setInsecureSsl(b: Boolean) { insecureSsl.value = b; store.putBool("insecureSsl", b); Net.insecure = b }
    fun setOrientation(o: Int) { orientation.value = o; store.putInt("orientation", o) }
    fun setBufferMode(m: Int) { bufferMode.value = m; store.putInt("buffer", m) }
    fun setTmdbKey(k: String) { tmdbKey.value = k.trim(); store.putStr("tmdb", k.trim()) }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun checkPin(pin: String) = hasPin.value && sha(pin) == store.str("pin")

    fun setPin(pin: String) {
        store.putStr("pin", sha(pin)); hasPin.value = true
        hideAdult.value = true; store.putBool("hideAdult", true); unlocked.value = false
    }

    fun unlock(pin: String): Boolean { val ok = checkPin(pin); if (ok) unlocked.value = true; return ok }
    fun lockAgain() { unlocked.value = false }

    fun removePin(pin: String): Boolean {
        if (!checkPin(pin)) return false
        store.putStr("pin", ""); hasPin.value = false
        hideAdult.value = false; store.putBool("hideAdult", false); unlocked.value = false
        return true
    }

    /** Abre uma lista: mostra o cache NA HORA (lido em segundo plano) e atualiza escondido; sem cache, baixa com progresso. */
    fun openPlaylist(p: Playlist) {
        store.activeId = p.id; activeId.value = p.id
        category.value = null; query.value = ""
        // nunca fica preso na tela de preparação: depois de 20 s mostra a Home mesmo assim
        viewModelScope.launch { delay(20_000); if (booting.value) booting.value = false }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cached = store.loadItems(p.id, dedupe.value)
                if (cached != null) {
                    val ready = if (cached.processed) cached.items else process(cached.items).also { store.saveItems(p.id, it, dedupe.value) }
                    setItems(ready)                                          // 1) Home aparece já
                    if (System.currentTimeMillis() - store.cacheAge(p.id) > SYNC_EVERY_MS) syncSilently(p)   // 2) atualiza nos bastidores
                } else { setItems(emptyList()); refresh(p) }                 // 1ª vez: carregamento com progresso
            } catch (e: Throwable) {
                store.logError("Falha ao abrir a lista", e)
                setItems(emptyList()); refresh(p)
            }
        }
    }

    /** Baixa de novo mostrando o progresso. Tem limite de tempo e sempre termina (com mensagem e "Tentar novamente"). */
    fun refresh(p: Playlist? = active.value) {
        if (p == null || loading.value) return
        loading.value = true; errorMsg.value = null
        val gen = loadGen.incrementAndGet()
        // vigia: se travar de vez, libera a tela depois de 3 minutos
        viewModelScope.launch {
            delay(WATCHDOG_MS)
            if (loadGen.get() == gen && loading.value) {
                loadGen.incrementAndGet()
                errorMsg.value = "O servidor demorou demais. Verifique a internet e toque em Tentar novamente."
                store.logError("Tempo esgotado ao carregar ${p.name}")
                loading.value = false; booting.value = false; status.value = ""
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val f = fetch(p)
                val list = process(f.items)
                if (loadGen.get() != gen) return@launch                      // chegou tarde: o vigia já encerrou
                val lost = f.failed.keys.filter { k -> items.value.any { it.kind == k } && list.none { it.kind == k } }
                if (lost.isNotEmpty()) {
                    // parte da lista falhou agora: mantém o que já estava na tela em vez de apagar
                    store.logError("Seções falharam em ${p.name}: ${f.failed}")
                    errorMsg.value = failText(f.failed); store.expireCache(p.id)
                    return@launch
                }
                store.saveItems(p.id, list, dedupe.value)
                markUpdated(p.id, Kind.values().filter { it !in f.failed.keys })
                if (f.failed.isNotEmpty()) {
                    store.logError("Seções falharam em ${p.name}: ${f.failed}")
                    errorMsg.value = failText(f.failed); store.expireCache(p.id)   // tenta de novo na próxima abertura
                }
                if (f.playlist != p) {
                    val upd = playlists.value.map { if (it.id == p.id) f.playlist else it }
                    store.savePlaylists(upd); playlists.value = upd
                }
                if (activeId.value == p.id) setItems(list)
            } catch (e: Throwable) {
                if (loadGen.get() == gen) { store.logError("Erro ao carregar ${p.name}", e); errorMsg.value = friendly(e) }
            } finally {
                if (loadGen.get() == gen) { loading.value = false; status.value = ""; booting.value = false }
            }
        }
    }

    /** Atualização invisível: sem tela de carregamento nem erro; só troca os dados se algo mudou. */
    fun syncSilently(p: Playlist? = active.value, force: Boolean = false) {
        if (p == null || loading.value || syncing.value) return
        syncing.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val f = fetch(p)
                val list = process(f.items)
                if (f.failed.isNotEmpty()) {
                    store.logError("Sincronização incompleta em ${p.name}: ${f.failed} (mantém o cache)")
                    store.expireCache(p.id)
                    return@launch
                }
                if (force || signature(list) != signature(items.value)) {
                    store.saveItems(p.id, list, dedupe.value)
                    if (activeId.value == p.id) items.value = list
                } else store.touchCache(p.id)
                markUpdated(p.id, Kind.values().toList())
                if (f.playlist != p) {
                    val upd = playlists.value.map { if (it.id == p.id) f.playlist else it }
                    store.savePlaylists(upd); playlists.value = upd
                }
            } catch (e: Throwable) { store.logError("Sincronização em segundo plano falhou (segue com o cache)", e) }
            finally { syncing.value = false; status.value = ""; stage.value = Stage() }
        }
    }

    private fun signature(l: List<Item>): Long {
        var h = l.size.toLong()
        for (i in l) h = h * 31 + i.url.hashCode() + i.name.hashCode() * 7L
        return h
    }

    private fun setKs(k: Kind, ui: SyncUi) { kindSync.value = kindSync.value + (k to ui) }

    private fun kindLabel(k: Kind) = when (k) { Kind.MOVIE -> "Filmes"; Kind.SERIES -> "Séries"; Kind.LIVE -> "Canais ao vivo" }

    private fun shortReason(e: Throwable): String = when (e) {
        is HttpStatusException -> "HTTP ${e.code}"
        is java.net.UnknownHostException -> "sem conexão com o servidor"
        is java.net.SocketTimeoutException -> "tempo esgotado"
        is AuthException -> "usuário ou senha inválidos"
        is OutOfMemoryError -> "memória insuficiente"
        else -> e.message?.take(60) ?: e.javaClass.simpleName
    }

    /**
     * Atualiza SÓ as categorias pedidas, uma de cada vez e com controle de erro individual.
     * Se uma falhar, as outras continuam e a lista antiga daquela categoria é mantida (nada some da tela).
     */
    fun syncKinds(kinds: List<Kind>) {
        val p = active.value ?: return
        if (loading.value || syncing.value) { toasts.tryEmit("Aguarde: já existe uma atualização em andamento."); return }
        syncing.value = true
        kinds.forEach { setKs(it, SyncUi(SyncStatus.LOADING, "Na fila…")) }
        viewModelScope.launch(Dispatchers.IO) {
            val xt: Xtream? = if (p.type == "xtream") Xtream(p) else null
            var full: Fetched? = null
            try {
                for (k in kinds) {
                    setKs(k, SyncUi(SyncStatus.LOADING, "Carregando…"))
                    try {
                        val raw: List<Item> = if (xt != null) xt.loadOne(k) { status.value = it }
                        else {
                            val f = full ?: fetch(p).also { full = it }
                            f.items.filter { it.kind == k }
                        }
                        val cur = items.value
                        if (raw.isEmpty() && cur.any { it.kind == k }) throw java.io.IOException("o servidor devolveu 0 itens")
                        val processed = process(raw)
                        val merged = (cur.filter { it.kind != k } + processed).sortedBy { it.kind.ordinal }
                        store.saveItems(p.id, merged, dedupe.value)
                        if (activeId.value == p.id) setItems(merged)
                        markUpdated(p.id, listOf(k))
                        setKs(k, SyncUi(SyncStatus.OK, "Sucesso (${processed.size} itens)"))
                    } catch (e: Throwable) {
                        store.logError("Atualização isolada de ${kindLabel(k)} falhou", e)
                        setKs(k, SyncUi(SyncStatus.ERROR, "Erro (${shortReason(e)})"))
                        toasts.tryEmit("Não foi possível atualizar ${kindLabel(k)}: ${shortReason(e)}. Os outros conteúdos continuam funcionando.")
                    }
                }
                xt?.let { x ->
                    x.expiry?.let { store.putStr("exp_${p.id}", it) }
                    val res = x.result()
                    if (res != p) {
                        val upd = playlists.value.map { if (it.id == p.id) res else it }
                        store.savePlaylists(upd); playlists.value = upd
                    }
                }
            } finally { syncing.value = false; status.value = "" }
        }
    }

    private fun failText(f: Map<Kind, String>): String {
        val names = f.entries.joinToString(", ") { (k, why) ->
            (when (k) { Kind.MOVIE -> "Filmes"; Kind.SERIES -> "Séries"; else -> "Canais" }) + " ($why)"
        }
        return "Não carregou: $names. O provedor pode estar limitando acessos. Espere 1 minuto e toque em Tentar novamente."
    }

    private val partLock = Any()
    private var partItems: List<Item> = emptyList()

    private fun showPartial(p: Playlist, part: List<Item>) {
        if (activeId.value != p.id) return
        synchronized(partLock) {
            val more = process(part)
            partItems = partItems + more
            setItems(partItems)                       // a Home aparece e as outras seções chegam por trás
        }
    }

    private fun fetch(p: Playlist): Fetched {
        synchronized(partLock) { partItems = emptyList() }
        status.value = "Carregando lista…"
        stage.value = Stage()
        val f = when (p.type) {
            "xtream" -> {
                val x = Xtream(p)
                stage.value = Stage(xtream = true)
                x.onStage = { k, done, n ->
                    val st = if (done) 1 else 0
                    stage.update { cur ->
                        when (k) {
                            Kind.LIVE -> cur.copy(live = st, liveCount = if (done) n else cur.liveCount)
                            Kind.MOVIE -> cur.copy(movies = st, movieCount = if (done) n else cur.movieCount)
                            Kind.SERIES -> cur.copy(series = st, seriesCount = if (done) n else cur.seriesCount)
                        }
                    }
                }
                // Entrada progressiva: se ainda não há nada na tela, mostra cada seção assim que chega
                if (items.value.isEmpty()) x.onPart = { part -> showPartial(p, part) }
                x.loadAll { status.value = it }.let { loaded ->
                    x.expiry?.let { store.putStr("exp_${p.id}", it) }
                    Fetched(loaded, x.result(), x.failed)
                }
            }
            "file" -> Fetched(
                File(p.source).inputStream().use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }, p,
            )
            else -> try {
                val (stream, ua) = Net.openAny(p.source, p.ua)
                Fetched(stream.use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }, p.copy(ua = ua))
            } catch (e: HttpStatusException) {
                // link get.php recusado (ex.: 404): muitos painéis só aceitam o login Xtream (player_api)
                val xp = if (e.code != 429) asXtream(p) else null
                if (xp == null) throw e
                val x = Xtream(xp)
                stage.value = Stage(xtream = true)
                x.loadAll { status.value = it }.let { loaded ->
                    x.expiry?.let { store.putStr("exp_${p.id}", it) }
                    Fetched(loaded, x.result(), x.failed)
                }
            }
        }
        if (f.items.isEmpty()) error("Nenhum item encontrado nessa lista")
        return f
    }

    /** Se o link M3U for do tipo .../get.php?username=U&password=P, devolve a lista equivalente em modo Xtream. */
    private fun asXtream(p: Playlist): Playlist? = runCatching {
        val u = android.net.Uri.parse(p.source)
        val user = u.getQueryParameter("username") ?: return null
        val pass = u.getQueryParameter("password") ?: return null
        if (user.isBlank() || !(u.path ?: "").endsWith("get.php")) return null
        val port = if (u.port > 0) ":${u.port}" else ""
        p.copy(type = "xtream", source = "${u.scheme}://${u.host}$port", user = user, pass = pass, endpoint = "")
    }.getOrNull()

    /** Valida e adiciona uma lista. [done] roda na thread principal com true se deu certo. */
    fun add(p: Playlist, done: (Boolean) -> Unit) {
        if (loading.value) return
        loading.value = true; errorMsg.value = null
        viewModelScope.launch(Dispatchers.IO) {
            var ok = false
            try {
                val f = fetch(p)
                val list = process(f.items)
                store.saveItems(p.id, list, dedupe.value)
                val all = playlists.value + f.playlist
                store.savePlaylists(all)
                playlists.value = all
                store.activeId = p.id; activeId.value = p.id
                category.value = null; query.value = ""
                setItems(list)
                ok = true
            } catch (e: Throwable) {
                store.logError("Erro ao adicionar ${p.name}", e)
                errorMsg.value = friendly(e)
                if (p.type == "file") File(p.source).delete()
            } finally {
                loading.value = false; status.value = ""
            }
            withContext(Dispatchers.Main) { done(ok) }
        }
    }

    fun addFile(uri: Uri, name: String, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val f = File(getApplication<Application>().filesDir, "list_$id.m3u")
            val copied = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }.isSuccess
            }
            if (!copied) { errorMsg.value = "Não foi possível ler o arquivo"; done(false); return@launch }
            add(Playlist(id, name.ifBlank { "Meu arquivo" }, "file", f.absolutePath), done)
        }
    }

    fun remove(p: Playlist) {
        val rest = playlists.value.filter { it.id != p.id }
        store.savePlaylists(rest); playlists.value = rest
        store.deletePlaylistData(p)
        if (activeId.value == p.id) {
            val next = rest.firstOrNull()
            if (next != null) openPlaylist(next) else { store.activeId = ""; activeId.value = ""; setItems(emptyList()) }
        }
    }

    fun clearError() { errorMsg.value = null }

    // ---------- diagnóstico de servidor ----------
    val diag = MutableStateFlow<List<String>>(emptyList())
    val diagRunning = MutableStateFlow(false)
    private fun push(line: String) { diag.value = diag.value + line }
    fun clearDiag() { if (!diagRunning.value) diag.value = emptyList() }

    /** Testa a conexão passo a passo e guarda o relatório (para suporte). */
    fun diagnose(p: Playlist) {
        if (diagRunning.value) return
        diagRunning.value = true; diag.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            val t0 = System.currentTimeMillis()
            try {
                push("Servidor: ${p.source}")
                when (p.type) {
                    "xtream" -> {
                        val x = Xtream(p)
                        x.detect { push(it) }
                        push("✓ Endereço usado: ${x.base}")
                        push("✓ User-Agent aceito: ${x.ua.ifBlank { Net.UA }}")
                        push(when {
                            !x.base.startsWith("https") -> "• Conexão HTTP (sem SSL)"
                            Net.insecure -> "• HTTPS com verificação de certificado desligada"
                            else -> "✓ HTTPS com certificado válido"
                        })
                        push("Contando conteúdo…")
                        val items = x.loadAll { }
                        push("✓ Canais ao vivo: ${items.count { it.kind == Kind.LIVE }}")
                        push("✓ Filmes: ${items.count { it.kind == Kind.MOVIE }}")
                        push("✓ Séries: ${items.count { it.kind == Kind.SERIES }}")
                    }
                    else -> {
                        val (stream, ua) = Net.openAny(p.source, p.ua)
                        push("✓ User-Agent aceito: $ua")
                        val items = stream.use { M3uParser.parse(it) }
                        push("✓ Canais ao vivo: ${items.count { it.kind == Kind.LIVE }}")
                        push("✓ Filmes: ${items.count { it.kind == Kind.MOVIE }}")
                        push("✓ Séries/episódios: ${items.count { it.kind == Kind.SERIES }}")
                    }
                }
                push("✓ Tempo total: ${System.currentTimeMillis() - t0} ms")
            } catch (e: Exception) {
                push("✗ ${friendly(e)}")
            } finally {
                store.putStr("diag_last", diag.value.joinToString("\n"))
                diagRunning.value = false
            }
        }
    }

    private fun friendly(e: Throwable): String = when (e) {
        is OutOfMemoryError -> "Memória insuficiente para esta lista. Feche outros apps e tente de novo."
        is java.net.UnknownHostException -> "Sem conexão com o servidor agora (DNS/internet). Sua lista salva continua disponível; toque em Tentar novamente."
        is java.net.SocketTimeoutException -> "O servidor demorou demais para responder."
        is AuthException -> e.message ?: "Usuário ou senha inválidos"
        is HttpStatusException -> when (e.code) {
            429 -> "O provedor limitou os acessos (HTTP 429: muitas tentativas seguidas). Espere 5 minutos SEM tentar e depois tente uma única vez."
            404 -> "O provedor respondeu 404: a lista pode ter vencido, o usuário/senha estar errado ou o link não existe mais. Confira com o provedor ou tente a aba Xtream."
            401, 403 -> "O provedor recusou o acesso (HTTP ${e.code}). Verifique usuário e senha ou se a assinatura está ativa."
            else -> "O servidor recusou a conexão (HTTP ${e.code}). Use Testar conexão para ver detalhes."
        }
        is javax.net.ssl.SSLException -> "Certificado SSL inválido. Ative \"Aceitar certificado inválido\" em Configurações, ou use http:// no endereço."
        is java.io.FileNotFoundException -> "Endereço não encontrado (404)."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Falha ao carregar a lista."
    }
}
