package br.com.brplay

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.brplay.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.Normalizer
import java.util.UUID

enum class Tab { LIVE, MOVIES, SERIES, FAVORITES }

@OptIn(FlowPreview::class)
class MainVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    val playlists = MutableStateFlow(store.playlists())
    val activeId = MutableStateFlow(store.activeId)
    val items = MutableStateFlow<List<Item>>(emptyList())
    val loading = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val errorMsg = MutableStateFlow<String?>(null)

    val tab = MutableStateFlow(Tab.LIVE)
    val category = MutableStateFlow<String?>(null)
    val query = MutableStateFlow("")
    val favorites = MutableStateFlow(store.favorites())

    val active: StateFlow<Playlist?> = combine(playlists, activeId) { l, id -> l.firstOrNull { it.id == id } ?: l.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private fun Kind.matches(t: Tab) = when (t) {
        Tab.LIVE -> this == Kind.LIVE
        Tab.MOVIES -> this == Kind.MOVIE
        Tab.SERIES -> this == Kind.SERIES
        Tab.FAVORITES -> true
    }

    val categories: StateFlow<List<String>> = combine(items, tab) { all, t ->
        if (t == Tab.FAVORITES) emptyList()
        else all.asSequence().filter { it.kind.matches(t) && !it.isEpisode }.map { it.group }.distinct().toList()
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val visible: StateFlow<List<Item>> = combine(
        items, tab, category, query.debounce(180), favorites,
    ) { all, t, cat, q, favs ->
        val nq = norm(q)
        all.filter { i ->
            when {
                t == Tab.FAVORITES -> i.key in favs
                !i.kind.matches(t) || i.isEpisode -> false
                cat != null && i.group != cat -> false
                else -> true
            } && (nq.isEmpty() || norm(i.name).contains(nq))
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase().trim()

    init {
        val a = playlists.value.firstOrNull { it.id == activeId.value } ?: playlists.value.firstOrNull()
        if (a != null) openPlaylist(a)
    }

    fun setTab(t: Tab) { tab.value = t; category.value = null }

    fun toggleFavorite(i: Item) {
        val n = favorites.value.toMutableSet().apply { if (!add(i.key)) remove(i.key) }
        favorites.value = n
        store.saveFavorites(n)
    }

    /** Abre uma lista: usa o cache se existir; senão baixa. */
    fun openPlaylist(p: Playlist) {
        store.activeId = p.id; activeId.value = p.id
        category.value = null; query.value = ""
        val cached = store.loadItems(p.id)
        if (cached != null) items.value = M3uParser.groupSeries(cached) else { items.value = emptyList(); refresh(p) }
    }

    fun refresh(p: Playlist? = active.value) {
        if (p == null || loading.value) return
        loading.value = true; errorMsg.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = fetch(p)
                store.saveItems(p.id, list)
                if (activeId.value == p.id) items.value = list
            } catch (e: Exception) {
                errorMsg.value = friendly(e)
            } finally {
                loading.value = false; status.value = ""
            }
        }
    }

    private fun fetch(p: Playlist): List<Item> {
        status.value = "Carregando lista…"
        return when (p.type) {
            "xtream" -> Xtream(p).loadAll { status.value = it }
            "file" -> File(p.source).inputStream().use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }
                .let { M3uParser.groupSeries(it) }
            else -> Net.open(p.source, p.ua).use { M3uParser.parse(it) { n -> status.value = "Lendo… $n itens" } }
                .also { if (it.isEmpty()) error("Nenhum item encontrado nessa lista") }
                .let { M3uParser.groupSeries(it) }
        }
    }

    /** Valida e adiciona uma lista. [done] roda na thread principal com true se deu certo. */
    fun add(p: Playlist, done: (Boolean) -> Unit) {
        if (loading.value) return
        loading.value = true; errorMsg.value = null
        viewModelScope.launch(Dispatchers.IO) {
            var ok = false
            try {
                val list = fetch(p)
                store.saveItems(p.id, list)
                val all = playlists.value + p
                store.savePlaylists(all)
                playlists.value = all
                store.activeId = p.id; activeId.value = p.id
                category.value = null; query.value = ""
                items.value = list
                ok = true
            } catch (e: Exception) {
                errorMsg.value = friendly(e)
                if (p.type == "file") File(p.source).delete()
            } finally {
                loading.value = false; status.value = ""
            }
            withContext(Dispatchers.Main) { done(ok) }
        }
    }

    fun addFile(uri: Uri, name: String, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val f = File(getApplication<Application>().filesDir, "list_$id.m3u")
            val copied = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }.isSuccess
            }
            if (!copied) { errorMsg.value = "Não foi possível ler o arquivo"; done(false); return@launch }
            add(Playlist(id, name.ifBlank { "Meu arquivo" }, "file", f.absolutePath), done)
        }
    }

    fun remove(p: Playlist) {
        val rest = playlists.value.filter { it.id != p.id }
        store.savePlaylists(rest); playlists.value = rest
        store.deletePlaylistData(p)
        if (activeId.value == p.id) {
            val next = rest.firstOrNull()
            if (next != null) openPlaylist(next) else { store.activeId = ""; activeId.value = ""; items.value = emptyList() }
        }
    }

    fun clearError() { errorMsg.value = null }

    private fun friendly(e: Exception): String = when (e) {
        is java.net.UnknownHostException -> "Servidor não encontrado. Verifique o endereço e a internet."
        is java.net.SocketTimeoutException -> "O servidor demorou demais para responder."
        is java.io.FileNotFoundException -> "Endereço não encontrado (404)."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Falha ao carregar a lista."
    }
}
