package br.com.brplay.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import br.com.brplay.data.Xtream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

private val epgGate = Semaphore(3)

/** Guia de programação (Xtream): "Agora" e "Depois" de cada canal, carregados só para os canais visíveis. */
@Composable
fun EpgScreen(vm: MainVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val pl by vm.active.collectAsStateWithLifecycle()
    val all by vm.items.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val live = remember(all) { all.filter { it.kind == Kind.LIVE } }
    val groups = remember(live) { live.map { it.group }.filter { it.isNotBlank() }.distinct() }
    var sel by remember(live) { mutableStateOf<String?>(null) }   // null = Todos, "★" = favoritos
    LaunchedEffect(live) { if (live.any { it.key in favs }) sel = "★" }
    val shown = remember(live, sel, favs) {
        when (sel) { null -> live; "★" -> live.filter { it.key in favs }; else -> live.filter { it.group == sel } }
    }
    val cache = remember { mutableStateMapOf<String, List<String>>() }
    val xtream = pl?.type == "xtream"

    SubScaffold("Guia de programação", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when {
                !xtream -> Msg("O guia de programação só está disponível para listas Xtream.")
                live.isEmpty() -> Msg("Nenhum canal ao vivo nesta lista.")
                else -> {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected = sel == null, onClick = { sel = null }, label = { Text("Todos") }) }
                        item { FilterChip(selected = sel == "★", onClick = { sel = "★" }, label = { Text("★ Favoritos") }) }
                        items(groups, key = { it }) { g -> FilterChip(selected = sel == g, onClick = { sel = g }, label = { Text(g, maxLines = 1) }, leadingIcon = { Icon(genreIcon(g), null, Modifier.size(18.dp)) }) }
                    }
                    if (shown.isEmpty()) Msg("Nenhum canal aqui.")
                    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(shown, key = { it.key }) { ch ->
                            EpgRow(ch, cache[ch.streamId], loaded = cache.containsKey(ch.streamId)) {
                                launchPlayer(ctx, shown, ch, vm)
                            }
                            LaunchedEffect(ch.streamId) {
                                val id = ch.streamId
                                if (id.isNotEmpty() && !cache.containsKey(id)) {
                                    val r = epgGate.withPermit {
                                        withContext(Dispatchers.IO) { runCatching { Xtream(pl!!).nowNext(id) }.getOrNull() }
                                    }
                                    cache[id] = r ?: emptyList()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Msg(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EpgRow(ch: Item, epg: List<String>?, loaded: Boolean, onClick: () -> Unit) {
    val shape = MaterialTheme.shapes.medium
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(shape).background(MaterialTheme.colorScheme.surface)
            .tvFocus(shape).clickable(onClick = onClick).padding(12.dp),
    ) {
        Text(ch.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        val now = epg?.getOrNull(0); val next = epg?.getOrNull(1)
        when {
            !loaded -> Text("Carregando…", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            now == null -> Text("Sem informação de programação", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            else -> {
                Text("Agora  $now", fontSize = 13.sp, color = androidx.compose.ui.graphics.Color(0xFFFFDF00), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (next != null) Text("Depois  $next", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
