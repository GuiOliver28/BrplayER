package br.com.brplay.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest

/** Marca do app: losango amarelo + círculo azul + play, sobre verde. */
@Composable
fun LogoMark(dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) {
        val s = this.size.minDimension
        drawRoundRect(Verde, cornerRadius = CornerRadius(s * 0.26f))
        val rombo = Path().apply {
            moveTo(s * 0.5f, s * 0.14f); lineTo(s * 0.88f, s * 0.5f)
            lineTo(s * 0.5f, s * 0.86f); lineTo(s * 0.12f, s * 0.5f); close()
        }
        drawPath(rombo, Amarelo)
        drawCircle(Azul, radius = s * 0.2f, center = Offset(s / 2, s / 2))
        val play = Path().apply {
            moveTo(s * 0.45f, s * 0.4f); lineTo(s * 0.45f, s * 0.6f); lineTo(s * 0.62f, s * 0.5f); close()
        }
        drawPath(play, Color.White)
    }
}

@Composable
fun Poster(url: String, fallback: ImageVector, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(ctx).data(url).crossfade(150)
                    .memoryCachePolicy(CachePolicy.ENABLED).diskCachePolicy(CachePolicy.ENABLED).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
                error = { FallbackIcon(fallback) },
                loading = { FallbackIcon(fallback) },
            )
        } else FallbackIcon(fallback)
    }
}

@Composable
private fun FallbackIcon(icon: ImageVector) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(28.dp))
    }
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.LIVE -> Icons.Rounded.LiveTv
    Kind.MOVIE -> Icons.Rounded.Movie
    Kind.SERIES -> Icons.Rounded.Slideshow
}

/** Linha de canal / episódio. */
@Composable
fun ItemRow(item: Item, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Poster(item.logo, kindIcon(item.kind), Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.group, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFav) {
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar",
                tint = if (fav) Amarelo else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Cartaz de filme / série. */
@Composable
fun PosterCard(item: Item, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Column(Modifier.clip(MaterialTheme.shapes.medium).clickable(onClick = onClick)) {
        Box {
            Poster(item.logo, kindIcon(item.kind), Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(MaterialTheme.shapes.medium))
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape)
                    .background(Color(0x99061230)).clickable(onClick = onFav),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar",
                    tint = if (fav) Amarelo else Color.White, modifier = Modifier.size(17.dp),
                )
            }
        }
        Text(
            item.name, style = MaterialTheme.typography.labelMedium, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        )
    }
}
