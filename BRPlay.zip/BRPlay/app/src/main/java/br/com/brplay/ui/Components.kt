package br.com.brplay.ui

import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import br.com.brplay.data.Tmdb
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest

/** Marca do app: losango amarelo + círculo azul + play, sobre verde. */
@Composable
fun LogoMark(dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) {
        val s = this.size.minDimension
        drawRoundRect(Verde, cornerRadius = CornerRadius(s * 0.26f))
        val rombo = Path().apply {
            moveTo(s * 0.5f, s * 0.14f); lineTo(s * 0.88f, s * 0.5f)
            lineTo(s * 0.5f, s * 0.86f); lineTo(s * 0.12f, s * 0.5f); close()
        }
        drawPath(rombo, Amarelo)
        drawCircle(Azul, radius = s * 0.2f, center = Offset(s / 2, s / 2))
        val play = Path().apply {
            moveTo(s * 0.45f, s * 0.4f); lineTo(s * 0.45f, s * 0.6f); lineTo(s * 0.62f, s * 0.5f); close()
        }
        drawPath(play, Color.White)
    }
}

/** Brilho animado usado como esqueleto de carregamento. */
fun Modifier.shimmer(): Modifier = composed {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-300f, 900f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "x")
    background(
        Brush.linearGradient(
            listOf(Color(0xFF14295A), Color(0xFF1F3A7A), Color(0xFF14295A)),
            start = Offset(x, 0f), end = Offset(x + 300f, 300f),
        )
    )
}

/** Destaque visível ao navegar com D-Pad / controle remoto (Fire TV). Aplicar antes de .clickable. */
fun Modifier.tvFocus(shape: Shape): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.05f else 1f, label = "focusScale")
    this.onFocusChanged { focused = it.hasFocus }
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .then(if (focused) Modifier.border(3.dp, Amarelo, shape) else Modifier)
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.LIVE -> Icons.Rounded.LiveTv
    Kind.MOVIE -> Icons.Rounded.Movie
    Kind.SERIES -> Icons.Rounded.Slideshow
}

/** http -> https apenas para domínios (IPs e portas explícitas costumam não ter https). */
private fun secure(url: String): String {
    if (!url.startsWith("http://")) return url
    val u = runCatching { Uri.parse(url) }.getOrNull() ?: return url
    val host = u.host.orEmpty()
    val isIp = host.all { it.isDigit() || it == '.' }
    return if (host.isEmpty() || isIp || u.port != -1) url else "https://" + url.removePrefix("http://")
}

/**
 * Imagem inteligente: tenta https, depois a URL original, depois o TMDB (se configurado)
 * e por fim um placeholder com gradiente e o título.
 */
@Composable
fun Poster(item: Item, modifier: Modifier = Modifier, showTitle: Boolean = true) {
    val ctx = LocalContext.current
    var url by remember(item.key) { mutableStateOf(secure(item.logo)) }
    var triedOriginal by remember(item.key) { mutableStateOf(false) }
    var failed by remember(item.key) { mutableStateOf(item.logo.isBlank()) }
    var tmdbTried by remember(item.key) { mutableStateOf(false) }

    LaunchedEffect(failed) {
        if (failed && !tmdbTried && item.kind != Kind.LIVE) {
            tmdbTried = true
            Tmdb.poster(item)?.let { url = it; failed = false }
        }
    }

    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (!failed && url.isNotBlank()) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(ctx).data(url).crossfade(150)
                    .memoryCachePolicy(CachePolicy.ENABLED).diskCachePolicy(CachePolicy.ENABLED).build(),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
                loading = { Box(Modifier.fillMaxSize().shimmer()) },
                onError = {
                    if (!triedOriginal && url != item.logo && item.logo.isNotBlank()) { triedOriginal = true; url = item.logo }
                    else failed = true
                },
            )
        } else Placeholder(item, showTitle)
    }
}

@Composable
private fun Placeholder(item: Item, showTitle: Boolean) {
    Box(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Azul, Color(0xFF0B4A2A)))),
        contentAlignment = Alignment.Center,
    ) {
        if (showTitle) Text(
            item.name, color = Color.White.copy(alpha = .85f), style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(8.dp),
        ) else Icon(kindIcon(item.kind), null, tint = Color.White.copy(alpha = .6f), modifier = Modifier.size(26.dp))
    }
}

/** Linha de canal / episódio. */
@Composable
fun ItemRow(item: Item, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit, watched: Boolean = false) {
    val shape = MaterialTheme.shapes.medium
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .tvFocus(shape)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Poster(item, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), showTitle = false)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.group, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (watched) Icon(Icons.Rounded.CheckCircle, "Assistido", tint = VerdeVivo, modifier = Modifier.size(20.dp))
        IconButton(onClick = onFav) {
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar",
                tint = if (fav) Amarelo else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Cartaz de filme / série. [progress] mostra a barra de "continuar assistindo". */
@Composable
fun PosterCard(
    item: Item, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit,
    modifier: Modifier = Modifier, progress: Float? = null, watched: Boolean = false,
) {
    val shape = MaterialTheme.shapes.medium
    Column(modifier.clip(shape).tvFocus(shape).clickable(onClick = onClick)) {
        Box {
            Poster(item, Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(shape))
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape)
                    .background(Color(0x99061230)).clickable(onClick = onFav),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar",
                    tint = if (fav) Amarelo else Color.White, modifier = Modifier.size(17.dp),
                )
            }
            if (watched) Icon(
                Icons.Rounded.CheckCircle, "Assistido", tint = VerdeVivo,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(20.dp),
            )
            if (item.quality.isNotEmpty()) Text(
                item.quality, style = MaterialTheme.typography.labelSmall, color = AzulNoite,
                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                    .background(Amarelo, RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp),
            )
            if (progress != null) LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                color = Amarelo, trackColor = Color(0x66000000),
            )
        }
        Text(
            item.name, style = MaterialTheme.typography.labelMedium, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        )
    }
}
