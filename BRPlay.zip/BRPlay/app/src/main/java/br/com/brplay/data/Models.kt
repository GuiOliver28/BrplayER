package br.com.brplay.data

enum class Kind { LIVE, MOVIE, SERIES }

/** Um item reproduzível (canal, filme, série ou episódio). */
data class Item(
    val kind: Kind,
    val name: String,
    val url: String,            // vazio para séries Xtream (precisam carregar episódios)
    val logo: String = "",
    val group: String = "",
    val epgId: String = "",
    val streamId: String = "",
    val seriesId: String = "",
) {
    val key: String get() = "${kind.name}|${url.ifEmpty { "s$seriesId" }}|$name"

    /** Episódio agrupado de uma série vinda de lista M3U (aparece só dentro da série). */
    val isEpisode: Boolean get() = url.isNotEmpty() && seriesId.startsWith("m3u:")

    // Metadados extraídos do nome (calculados uma vez por item)
    val year: Int = Meta.year(name)
    val quality: String = Meta.quality(name, group)
    val adult: Boolean = Meta.isAdult(name, group)
}

/** type: "m3u" (link), "file" (arquivo local) ou "xtream". */
data class Playlist(
    val id: String,
    val name: String,
    val type: String,
    val source: String,
    val user: String = "",
    val pass: String = "",
    val ua: String = "",
)

/** Fila de reprodução compartilhada entre a lista e o player (evita estourar o Intent). */
object PlayQueue {
    var items: List<Item> = emptyList()
    var index: Int = 0
    var playlist: Playlist? = null
}
