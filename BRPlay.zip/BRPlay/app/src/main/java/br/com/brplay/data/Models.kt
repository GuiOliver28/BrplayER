package br.com.brplay.data

enum class Kind { LIVE, MOVIE, SERIES }

/** Um item reproduzível (canal, filme, série ou episódio). */
data class Item(
    val kind: Kind,
    val name: String,
    val url: String,            // vazio para séries Xtream (precisam carregar episódios)
    val logo: String = "",
    val group: String = "",
    val epgId: String = "",
    val streamId: String = "",
    val seriesId: String = "",
) {
    val key: String get() = "${kind.name}|${url.ifEmpty { "s$seriesId" }}|$name"

    /** Episódio agrupado de uma série vinda de lista M3U (aparece só dentro da série). */
    val isEpisode: Boolean get() = url.isNotEmpty() && seriesId.startsWith("m3u:")

    // Metadados extraídos do nome: calculados UMA vez, só quando alguém precisa (não pesa ao ler a lista).
    private var meta: Int = -1
    private fun m(): Int {
        var v = meta
        if (v < 0) {
            val q = when (Meta.quality(name, group)) { "SD" -> 1; "HD" -> 2; "FHD" -> 3; "4K" -> 4; else -> 0 }
            v = Meta.year(name) or (q shl 12) or ((if (Meta.isAdult(name, group)) 1 else 0) shl 15)
            meta = v
        }
        return v
    }
    val year: Int get() = m() and 0xFFF
    val quality: String get() = QUALITIES[(m() shr 12) and 7]
    val adult: Boolean get() = ((m() shr 15) and 1) == 1

    private companion object { val QUALITIES = arrayOf("", "SD", "HD", "FHD", "4K", "", "", "") }
}

/** type: "m3u" (link), "file" (arquivo local) ou "xtream". */
data class Playlist(
    val id: String,
    val name: String,
    val type: String,
    val source: String,
    val user: String = "",
    val pass: String = "",
    val ua: String = "",
    /** Endpoint Xtream que funcionou neste servidor: player_api, get ou panel (vazio = ainda não detectado). */
    val endpoint: String = "",
)

/** Fila de reprodução compartilhada entre a lista e o player (evita estourar o Intent). */
object PlayQueue {
    var items: List<Item> = emptyList()
    var index: Int = 0
    var playlist: Playlist? = null
}
