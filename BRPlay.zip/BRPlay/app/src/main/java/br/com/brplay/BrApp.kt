package br.com.brplay

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/** Leitor de imagens único do app: cache em memória e em disco maiores para a rolagem ficar lisa. */
class BrApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.22).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(200L * 1024 * 1024).build() }
        .respectCacheHeaders(false)          // listas IPTV costumam mandar cabeçalhos ruins; guarda a capa de qualquer jeito
        .crossfade(false)
        .build()
}
