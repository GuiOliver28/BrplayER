package br.com.brplay.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import coil.imageLoader

private enum class PinAction { SET, UNLOCK, REMOVE }

@Composable
fun SettingsScreen(vm: MainVm, onBack: () -> Unit, onAbout: () -> Unit, onSync: () -> Unit = {}) {
    val ctx = LocalContext.current
    val dedupe by vm.dedupe.collectAsStateWithLifecycle()
    val buffer by vm.bufferMode.collectAsStateWithLifecycle()
    val tmdb by vm.tmdbKey.collectAsStateWithLifecycle()
    val insecure by vm.insecureSsl.collectAsStateWithLifecycle()
    val orientation by vm.orientation.collectAsStateWithLifecycle()
    val hasPin by vm.hasPin.collectAsStateWithLifecycle()
    val unlocked by vm.unlocked.collectAsStateWithLifecycle()
    var tmdbText by remember(tmdb) { mutableStateOf(tmdb) }
    var pinAction by remember { mutableStateOf<PinAction?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) message = runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(vm.store.exportBackup().toByteArray(Charsets.UTF_8)) }
            "Backup salvo. Guarde o arquivo: ele contém seus logins."
        }.getOrElse { "Não foi possível salvar o backup." }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val ok = runCatching {
                vm.store.importBackup(ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) })
            }.isSuccess
            if (ok) {
                // reinicia o app para carregar as listas restauradas
                val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                if (i != null) { ctx.startActivity(i); Runtime.getRuntime().exit(0) }
                message = "Backup restaurado. Feche e abra o app."
            } else message = "Esse arquivo não é um backup válido do BR Play."
        }
    }

    SubScaffold("Configurações", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            message?.let {
                Text(it, color = Amarelo, style = MaterialTheme.typography.labelMedium)
            }

            Group("Organização") {
                SwitchRow("Remover filmes e séries repetidos", "Junta títulos iguais (mesmo nome e ano).", dedupe) { vm.setDedupe(it) }
            }

            Group("Tela") {
                Text("Girar tela", style = MaterialTheme.typography.bodyLarge)
                Text("Use Paisagem se o celular não girar sozinho (por exemplo, com o giro automático desligado).",
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Automático", "Retrato", "Paisagem").forEachIndexed { i, l ->
                        FilterChip(selected = orientation == i, onClick = { vm.setOrientation(i) }, label = { Text(l) },
                            shape = MaterialTheme.shapes.large,
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                selectedContainerColor = Verde, selectedLabelColor = Color.White),
                        )
                    }
                }
            }

            Group("Conexão") {
                SwitchRow(
                    "Aceitar certificado SSL inválido",
                    "Só ative se o servidor usar HTTPS com certificado vencido ou autoassinado. Reduz a segurança da conexão com esse servidor.",
                    insecure,
                ) { vm.setInsecureSsl(it) }
            }

            Group("Reprodução") {
                Text("Buffer do player", style = MaterialTheme.typography.bodyLarge)
                Text("Maior = menos travadas, mas demora mais para abrir.", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Pequeno", "Normal", "Grande").forEachIndexed { i, l ->
                        FilterChip(selected = buffer == i, onClick = { vm.setBufferMode(i) }, label = { Text(l) },
                            shape = MaterialTheme.shapes.large,
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                selectedContainerColor = Verde, selectedLabelColor = Color.White),
                        )
                    }
                }
            }

            Group("Capas (TMDB)") {
                Text("Opcional. Com uma chave gratuita da API v3 do TMDB, o app busca a capa certa quando a da lista falha.",
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = tmdbText, onValueChange = { tmdbText = it }, label = { Text("Chave da API v3") }, singleLine = true,
                    shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                )
                Button(onClick = { vm.setTmdbKey(tmdbText); message = "Chave salva." },
                    colors = ButtonDefaults.buttonColors(containerColor = Verde)) { Text("Salvar chave") }
            }

            Group("Controle parental") {
                if (!hasPin) {
                    Text("Crie um PIN para ocultar conteúdo adulto (categorias e títulos com 18+, xxx, adulto…).",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { pinAction = PinAction.SET }, colors = ButtonDefaults.buttonColors(containerColor = Verde)) {
                        Icon(Icons.Rounded.Lock, null); Spacer(Modifier.width(8.dp)); Text("Criar PIN")
                    }
                } else {
                    Text(if (unlocked) "Conteúdo adulto liberado nesta sessão." else "Conteúdo adulto oculto.",
                        style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (unlocked) OutlinedButton(onClick = { vm.lockAgain(); message = "Conteúdo adulto oculto." }) { Text("Ocultar de novo") }
                        else OutlinedButton(onClick = { pinAction = PinAction.UNLOCK }) { Text("Liberar com PIN") }
                        TextButton(onClick = { pinAction = PinAction.REMOVE }) { Text("Remover PIN", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }

            Group("Dados") {
                ActionRow(Icons.Rounded.Sync, "Gerenciar sincronização (canais, filmes, séries)", onSync)
                ActionRow(Icons.Rounded.History, "Limpar histórico e assistidos") { vm.clearHistory(); message = "Histórico limpo." }
                ActionRow(Icons.Rounded.Image, "Limpar cache de imagens e capas") {
                    ctx.imageLoader.memoryCache?.clear(); ctx.imageLoader.diskCache?.clear(); vm.store.tmdbClear()
                    message = "Cache limpo."
                }
            }

            Group("Backup e suporte") {
                ActionRow(Icons.Rounded.Save, "Salvar backup (listas, favoritos, histórico)") { exporter.launch("brplay-backup.json") }
                ActionRow(Icons.Rounded.Restore, "Restaurar backup") { importer.launch(arrayOf("*/*")) }
                ActionRow(Icons.Rounded.BugReport, "Enviar log para suporte") {
                    val text = "BR Play 3.5\n" + vm.store.str("diag_last") + "\n---\n" + vm.store.readLog()
                    val masked = Regex("(?i)(username|password|user|pass)=[^&\\s]+").replace(text, "$1=***")
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Log do BR Play"); putExtra(Intent.EXTRA_TEXT, masked)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Enviar log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }

            Group("Sobre") {
                ActionRow(Icons.Rounded.Info, "Sobre o BR Play", onAbout)
            }
        }
    }

    pinAction?.let { action ->
        PinDialog(
            title = when (action) { PinAction.SET -> "Criar PIN (4 dígitos)"; PinAction.UNLOCK -> "Digite o PIN"; PinAction.REMOVE -> "Digite o PIN para remover" },
            onDismiss = { pinAction = null },
            onConfirm = { pin ->
                val ok = when (action) {
                    PinAction.SET -> if (pin.length >= 4) { vm.setPin(pin); true } else false
                    PinAction.UNLOCK -> vm.unlock(pin)
                    PinAction.REMOVE -> vm.removePin(pin)
                }
                message = if (ok) "Pronto." else "PIN inválido."
                pinAction = null
            },
        )
    }
}

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large).background(MaterialTheme.colorScheme.surface).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Amarelo)
        content()
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Verde, checkedThumbColor = Color.White))
    }
}

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).tvFocus(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun PinDialog(title: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = pin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pin = it },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(pin) }) { Text("Confirmar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
