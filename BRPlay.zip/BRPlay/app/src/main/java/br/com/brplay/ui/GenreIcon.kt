package br.com.brplay.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import java.text.Normalizer

private fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

private val GENRES: List<Pair<List<String>, ImageVector>> = listOf(
    listOf("acao", "action") to Icons.Rounded.SportsMartialArts,
    listOf("comedia", "comedy", "humor") to Icons.Rounded.EmojiEmotions,
    listOf("terror", "horror") to Icons.Rounded.BugReport,
    listOf("aventura", "adventure") to Icons.Rounded.Explore,
    listOf("anime") to Icons.Rounded.Face,
    listOf("animacao", "animation", "desenho", "infantil", "kids") to Icons.Rounded.Animation,
    listOf("document") to Icons.Rounded.VideoCameraBack,
    listOf("drama") to Icons.Rounded.Theaters,
    listOf("fantasia", "fantasy") to Icons.Rounded.AutoAwesome,
    listOf("ficcao", "sci-fi", "scifi", "sci fi") to Icons.Rounded.RocketLaunch,
    listOf("guerra", "war") to Icons.Rounded.MilitaryTech,
    listOf("faroeste", "western") to Icons.Rounded.Landscape,
    listOf("suspense", "thriller", "crime", "policial") to Icons.Rounded.Visibility,
    listOf("romance") to Icons.Rounded.Favorite,
    listOf("familia", "family") to Icons.Rounded.FamilyRestroom,
    listOf("musica", "music", "musical") to Icons.Rounded.MusicNote,
    listOf("esporte", "sport", "futebol") to Icons.Rounded.SportsSoccer,
    listOf("noticia", "news", "jornal") to Icons.Rounded.Description,
    listOf("lancamento", "novidade", "new") to Icons.Rounded.NewReleases,
    listOf("adulto", "adult", "xxx", "18+") to Icons.Rounded.Lock,
)

/** Ícone para o nome de uma categoria/gênero (ignora maiúsculas e acentos). */
fun genreIcon(name: String): ImageVector {
    val n = norm(name)
    return GENRES.firstOrNull { (keys, _) -> keys.any { n.contains(it) } }?.second ?: Icons.Rounded.Folder
}
