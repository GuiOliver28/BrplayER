package br.com.brplay.data

import android.util.Base64
import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.InputStreamReader
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cliente da API Xtream Codes (player_api.php). */
class Xtream(private val p: Playlist) {

    val base: String = p.source.trim().let {
        var s = if (it.startsWith("http", true)) it else "http://$it"
        s = s.substringBefore("/player_api.php").substringBefore("/get.php").substringBefore("/c/")
        s.trimEnd('/')
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun api(action: String = "", extra: String = ""): String =
        "$base/player_api.php?username=${enc(p.user)}&password=${enc(p.pass)}" +
            (if (action.isNotEmpty()) "&action=$action" else "") + extra

    /** Valida usuário/senha. Lança exceção com mensagem amigável se falhar. */
    fun authenticate() {
        val json = JSONObject(Net.text(api(), p.ua))
        val info = json.optJSONObject("user_info") ?: error("Resposta inesperada do servidor")
        val auth = info.opt("auth")?.toString()
        if (auth != "1" && auth != "true") error("Usuário ou senha inválidos")
        val status = info.optString("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) error("Conta $status")
    }

    private fun categories(action: String): Map<String, String> {
        val map = HashMap<String, String>()
        runCatching {
            readObjects(Net.open(api(action), p.ua)) { map[it["category_id"] ?: ""] = it["category_name"] ?: "" }
        }
        return map
    }

    fun loadAll(onProgress: (String) -> Unit): List<Item> {
        authenticate()
        val out = ArrayList<Item>(8192)

        onProgress("Carregando canais ao vivo…")
        val liveCats = categories("get_live_categories")
        runCatching {
            readObjects(Net.open(api("get_live_streams"), p.ua)) { o ->
                val id = o["stream_id"] ?: return@readObjects
                out += Item(
                    Kind.LIVE, o["name"].orEmpty(), "$base/live/${p.user}/${p.pass}/$id.m3u8",
                    logo = o["stream_icon"].orEmpty(),
                    group = liveCats[o["category_id"]] ?: "Canais",
                    epgId = o["epg_channel_id"].orEmpty(), streamId = id,
                )
            }
        }

        onProgress("Carregando filmes… (${out.size} itens)")
        val vodCats = categories("get_vod_categories")
        runCatching {
            readObjects(Net.open(api("get_vod_streams"), p.ua)) { o ->
                val id = o["stream_id"] ?: return@readObjects
                val ext = o["container_extension"].orEmpty().ifBlank { "mp4" }
                out += Item(
                    Kind.MOVIE, o["name"].orEmpty(), "$base/movie/${p.user}/${p.pass}/$id.$ext",
                    logo = o["stream_icon"].orEmpty(),
                    group = vodCats[o["category_id"]] ?: "Filmes", streamId = id,
                )
            }
        }

        onProgress("Carregando séries… (${out.size} itens)")
        val serCats = categories("get_series_categories")
        runCatching {
            readObjects(Net.open(api("get_series"), p.ua)) { o ->
                val id = o["series_id"] ?: return@readObjects
                out += Item(
                    Kind.SERIES, o["name"].orEmpty(), "",
                    logo = o["cover"].orEmpty(),
                    group = serCats[o["category_id"]] ?: "Séries", seriesId = id,
                )
            }
        }
        if (out.isEmpty()) error("A conta não retornou nenhum conteúdo")
        return out
    }

    /** Episódios de uma série, já com URL final. */
    fun episodes(seriesId: String, cover: String): List<Item> {
        val root = JSONObject(Net.text(api("get_series_info", "&series_id=$seriesId"), p.ua))
        val eps = root.opt("episodes")
        val out = ArrayList<Item>()
        fun add(season: String, e: JSONObject) {
            val id = e.optString("id")
            if (id.isEmpty()) return
            val ext = e.optString("container_extension").ifBlank { "mp4" }
            val num = e.optString("episode_num")
            val title = e.optString("title")
            val img = e.optJSONObject("info")?.optString("movie_image").orEmpty().ifBlank { cover }
            out += Item(
                Kind.SERIES, "T$season · E$num  ${title.ifBlank { "Episódio $num" }}",
                "$base/series/${p.user}/${p.pass}/$id.$ext", logo = img, group = "Temporada $season", streamId = id,
            )
        }
        when (eps) {
            is JSONObject -> eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 999 }.forEach { s ->
                val arr = eps.optJSONArray(s) ?: return@forEach
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { add(s, it) }
            }
            is JSONArray -> for (s in 0 until eps.length()) {
                val arr = eps.optJSONArray(s) ?: continue
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { add((s + 1).toString(), it) }
            }
        }
        return out
    }

    /** "Agora / Em seguida" de um canal ao vivo. */
    fun nowNext(streamId: String): List<String> {
        val root = JSONObject(Net.text(api("get_short_epg", "&stream_id=$streamId&limit=2"), p.ua))
        val arr = root.optJSONArray("epg_listings") ?: return emptyList()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = runCatching { String(Base64.decode(o.optString("title"), Base64.DEFAULT), Charsets.UTF_8) }
                .getOrDefault(o.optString("title"))
            val start = o.optLong("start_timestamp") * 1000
            "${fmt.format(Date(start))}  $title"
        }
    }

    companion object {
        /** Lê um array JSON de objetos em streaming (baixo uso de memória em listas enormes). */
        fun readObjects(input: InputStream, each: (Map<String, String>) -> Unit) {
            JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
                r.isLenient = true
                if (r.peek() != JsonToken.BEGIN_ARRAY) return
                r.beginArray()
                while (r.hasNext()) {
                    if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    r.beginObject()
                    val m = HashMap<String, String>(16)
                    while (r.hasNext()) {
                        val n = r.nextName()
                        when (r.peek()) {
                            JsonToken.STRING, JsonToken.NUMBER -> m[n] = r.nextString()
                            JsonToken.BOOLEAN -> m[n] = r.nextBoolean().toString()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    each(m)
                }
                r.endArray()
            }
        }
    }
}
