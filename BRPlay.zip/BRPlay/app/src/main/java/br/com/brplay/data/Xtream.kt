package br.com.brplay.data

import android.util.Base64
import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Usuário ou senha recusados pelo servidor (não adianta tentar outras combinações). */
class AuthException(msg: String) : Exception(msg)

/**
 * Cliente Xtream Codes adaptativo: descobre sozinho qual endpoint, endereço (http/https)
 * e User-Agent funcionam em cada servidor e guarda a combinação vencedora na lista.
 */
class Xtream(private val p: Playlist) {

    var base: String = normalize(p.source)
        private set
    var ua: String = p.ua
        private set
    var endpoint: String = p.endpoint
        private set

    /** Lista com a combinação que funcionou (para salvar). */
    fun result(): Playlist = p.copy(source = base, ua = ua, endpoint = endpoint)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun cred(b: String) = "username=${enc(p.user)}&password=${enc(p.pass)}"
    private fun api(action: String = "", extra: String = ""): String =
        "$base/player_api.php?${cred(base)}" + (if (action.isNotEmpty()) "&action=$action" else "") + extra
    private fun getPhp() = "$base/get.php?${cred(base)}&type=m3u_plus&output=ts"
    private fun panel() = "$base/panel_api.php?${cred(base)}"

    private fun authenticateAt(b: String, u: String) {
        val json = JSONObject(Net.text("$b/player_api.php?${cred(b)}", u, readMs = 20_000))
        val info = json.optJSONObject("user_info") ?: throw IllegalStateException("Resposta inesperada do servidor")
        val auth = info.opt("auth")?.toString()
        if (auth == "0" || auth == "false") throw AuthException("Usuário ou senha inválidos")
        val status = info.optString("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) throw AuthException("Conta $status")
    }

    /** Lê só o começo para confirmar que é uma lista M3U. */
    private fun looksLikeM3u(url: String, u: String): Boolean =
        Net.open(url, u).use { s ->
            val buf = ByteArray(1024); val n = s.read(buf).coerceAtLeast(0)
            val head = String(buf, 0, n, Charsets.ISO_8859_1)
            head.contains("#EXTM3U") || head.contains("#EXTINF")
        }

    /**
     * Testa endpoints, esquemas e User-Agents. Lança exceção se nada funcionar.
     * [log] recebe o andamento (usado na tela de diagnóstico).
     */
    fun detect(log: (String) -> Unit = {}) {
        val uas = (listOf(p.ua) + Net.UAS).filter { it.isNotBlank() }.distinct()
        val bases = listOf(base, Net.swapScheme(base)).distinct()
        var last: Exception? = null

        // 1) player_api.php
        for (b in bases) {
            var networkProblem = false
            for (u in uas) {
                if (networkProblem) break
                try {
                    val t0 = System.currentTimeMillis()
                    log("Testando player_api.php em ${hostOf(b)} (${shortUa(u)})…")
                    authenticateAt(b, u)
                    base = b; ua = u; endpoint = "player_api"
                    log("✓ player_api.php respondeu em ${System.currentTimeMillis() - t0} ms")
                    return
                } catch (e: AuthException) {
                    throw e
                } catch (e: HttpStatusException) {
                    last = e; log("✗ HTTP ${e.code} com ${shortUa(u)}")
                } catch (e: IOException) {
                    last = e; networkProblem = true; log("✗ Sem conexão (${e.javaClass.simpleName})")
                } catch (e: Exception) {
                    last = e; log("✗ Resposta inválida com ${shortUa(u)}")
                }
            }
        }

        // 2) get.php (lista M3U gerada pelo painel)
        for (b in bases) {
            var networkProblem = false
            for (u in uas) {
                if (networkProblem) break
                try {
                    log("Testando get.php em ${hostOf(b)} (${shortUa(u)})…")
                    val url = "$b/get.php?${cred(b)}&type=m3u_plus&output=ts"
                    if (looksLikeM3u(url, u)) {
                        base = b; ua = u; endpoint = "get"
                        log("✓ get.php respondeu")
                        return
                    }
                } catch (e: HttpStatusException) { last = e }
                catch (e: IOException) { last = e; networkProblem = true }
                catch (e: Exception) { last = e }
            }
        }

        // 3) panel_api.php
        for (b in bases) {
            for (u in uas) {
                try {
                    log("Testando panel_api.php em ${hostOf(b)} (${shortUa(u)})…")
                    val json = JSONObject(Net.text("$b/panel_api.php?${cred(b)}", u, readMs = 40_000))
                    if (json.has("available_channels")) {
                        base = b; ua = u; endpoint = "panel"
                        log("✓ panel_api.php respondeu")
                        return
                    }
                } catch (e: IOException) { last = e; if (e !is HttpStatusException) break }
                catch (e: Exception) { last = e }
            }
        }
        throw last ?: IOException("Não foi possível conectar ao servidor")
    }

    /** [onStage] avisa o andamento de cada etapa: (tipo, concluída?, quantidade). */
    var onStage: (Kind, Boolean, Int) -> Unit = { _, _, _ -> }

    fun loadAll(onProgress: (String) -> Unit): List<Item> {
        if (endpoint.isEmpty()) detect { onProgress(it) }
        val items = try {
            loadWith(endpoint, onProgress)
        } catch (e: AuthException) {
            throw e
        } catch (e: Exception) {
            // a combinação salva pode ter deixado de funcionar: detecta de novo uma vez
            onProgress("Procurando outra forma de conectar…")
            endpoint = ""; detect { onProgress(it) }
            loadWith(endpoint, onProgress)
        }
        if (items.isEmpty()) throw IllegalStateException("A conta não retornou nenhum conteúdo")
        return items
    }

    private fun loadWith(ep: String, onProgress: (String) -> Unit): List<Item> = when (ep) {
        "get" -> {
            onProgress("Baixando lista M3U do painel…")
            Net.open(getPhp(), ua).use { M3uParser.parse(it) { n -> onProgress("Lendo… $n itens") } }
        }
        "panel" -> loadPanel(onProgress)
        else -> loadPlayerApi(onProgress)
    }

    private fun categories(action: String): Map<String, String> {
        val map = HashMap<String, String>()
        runCatching {
            readObjects(Net.open(api(action), ua)) { map[it["category_id"] ?: ""] = it["category_name"] ?: "" }
        }
        return map
    }

    /** Baixa filmes, séries e canais ao mesmo tempo (3x mais rápido na primeira abertura). */
    private fun loadPlayerApi(onProgress: (String) -> Unit): List<Item> {
        authenticateAt(base, ua)
        onProgress("Carregando conteúdo…")
        val live = ArrayList<Item>(4096); val movies = ArrayList<Item>(4096); val series = ArrayList<Item>(2048)
        val errors = java.util.concurrent.atomic.AtomicInteger(0)

        fun section(kind: Kind, out: ArrayList<Item>, catsAction: String, listAction: String, fallback: String, map: (Map<String, String>, Map<String, String>) -> Item?) = Thread {
            onStage(kind, false, 0)
            try {
                val cats = categories(catsAction)
                readObjects(Net.open(api(listAction), ua, readMs = 90_000)) { o ->
                    map(o, cats)?.let { out += it }
                }
            } catch (e: Exception) { errors.incrementAndGet() }
            onStage(kind, true, out.size)
        }

        val tl = section(Kind.LIVE, live, "get_live_categories", "get_live_streams", "Canais") { o, cats ->
            val id = o["stream_id"] ?: return@section null
            Item(Kind.LIVE, o["name"].orEmpty(), "$base/live/${p.user}/${p.pass}/$id.m3u8",
                logo = o["stream_icon"].orEmpty(), group = cats[o["category_id"]] ?: "Canais",
                epgId = o["epg_channel_id"].orEmpty(), streamId = id)
        }
        val tm = section(Kind.MOVIE, movies, "get_vod_categories", "get_vod_streams", "Filmes") { o, cats ->
            val id = o["stream_id"] ?: return@section null
            val ext = o["container_extension"].orEmpty().ifBlank { "mp4" }
            Item(Kind.MOVIE, o["name"].orEmpty(), "$base/movie/${p.user}/${p.pass}/$id.$ext",
                logo = o["stream_icon"].orEmpty(), group = cats[o["category_id"]] ?: "Filmes", streamId = id)
        }
        val ts = section(Kind.SERIES, series, "get_series_categories", "get_series", "Séries") { o, cats ->
            val id = o["series_id"] ?: return@section null
            Item(Kind.SERIES, o["name"].orEmpty(), "", logo = o["cover"].orEmpty(),
                group = cats[o["category_id"]] ?: "Séries", seriesId = id)
        }
        val all = listOf(tl, tm, ts)
        all.forEach { it.start() }
        all.forEach { it.join() }
        val out = ArrayList<Item>(live.size + movies.size + series.size)
        out += live; out += movies; out += series
        return out
    }

    private fun loadPanel(onProgress: (String) -> Unit): List<Item> {
        onProgress("Carregando conteúdo (panel_api)…")
        val root = JSONObject(Net.text(panel(), ua, readMs = 90_000))
        val ch = root.optJSONObject("available_channels") ?: return emptyList()
        val out = ArrayList<Item>(ch.length())
        for (key in ch.keys()) {
            val o = ch.optJSONObject(key) ?: continue
            val sid = o.optString("stream_id").ifEmpty { key }
            val name = o.optString("name")
            val logo = o.optString("stream_icon")
            val group = o.optString("category_name").ifEmpty { "Sem categoria" }
            if (o.optString("stream_type").equals("movie", true)) {
                val ext = o.optString("container_extension").ifBlank { "mp4" }
                out += Item(Kind.MOVIE, name, "$base/movie/${p.user}/${p.pass}/$sid.$ext", logo, group, streamId = sid)
            } else if (!o.optString("stream_type").equals("series", true)) {
                out += Item(Kind.LIVE, name, "$base/live/${p.user}/${p.pass}/$sid.m3u8", logo, group,
                    epgId = o.optString("epg_channel_id"), streamId = sid)
            }
        }
        return out
    }

    /** Episódios de uma série, já com URL final. */
    fun episodes(seriesId: String, cover: String): List<Item> {
        val root = JSONObject(Net.text(api("get_series_info", "&series_id=$seriesId"), ua))
        val eps = root.opt("episodes")
        val out = ArrayList<Item>()
        fun add(season: String, e: JSONObject) {
            val id = e.optString("id")
            if (id.isEmpty()) return
            val ext = e.optString("container_extension").ifBlank { "mp4" }
            val num = e.optString("episode_num")
            val title = e.optString("title")
            val img = e.optJSONObject("info")?.optString("movie_image").orEmpty().ifBlank { cover }
            out += Item(
                Kind.SERIES, "T$season · E$num  ${title.ifBlank { "Episódio $num" }}",
                "$base/series/${p.user}/${p.pass}/$id.$ext", logo = img, group = "Temporada $season", streamId = id,
            )
        }
        when (eps) {
            is JSONObject -> eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 999 }.forEach { s ->
                val arr = eps.optJSONArray(s) ?: return@forEach
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { add(s, it) }
            }
            is JSONArray -> for (s in 0 until eps.length()) {
                val arr = eps.optJSONArray(s) ?: continue
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { add((s + 1).toString(), it) }
            }
        }
        return out
    }

    /** "Agora / Em seguida" de um canal ao vivo. */
    fun nowNext(streamId: String): List<String> {
        val root = JSONObject(Net.text(api("get_short_epg", "&stream_id=$streamId&limit=2"), ua))
        val arr = root.optJSONArray("epg_listings") ?: return emptyList()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = runCatching { String(Base64.decode(o.optString("title"), Base64.DEFAULT), Charsets.UTF_8) }
                .getOrDefault(o.optString("title"))
            val start = o.optLong("start_timestamp") * 1000
            "${fmt.format(Date(start))}  $title"
        }
    }

    private fun hostOf(u: String) = u.substringAfter("://").substringBefore('/')
    private fun shortUa(u: String) = u.substringBefore('/').substringBefore(' ').take(18)

    companion object {
        /** Aceita "host:porta", "http://host" ou o link completo do get.php/c/. */
        fun normalize(source: String): String {
            var s = source.trim()
            if (!s.startsWith("http", true)) s = "http://$s"
            s = s.substringBefore("/player_api.php").substringBefore("/get.php").substringBefore("/panel_api.php").substringBefore("/c/")
            return s.trimEnd('/')
        }

        /** Lê um array JSON de objetos em streaming (baixo uso de memória em listas enormes). */
        fun readObjects(input: InputStream, each: (Map<String, String>) -> Unit) {
            JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
                r.isLenient = true
                if (r.peek() != JsonToken.BEGIN_ARRAY) return
                r.beginArray()
                while (r.hasNext()) {
                    if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    r.beginObject()
                    val m = HashMap<String, String>(16)
                    while (r.hasNext()) {
                        val n = r.nextName()
                        when (r.peek()) {
                            JsonToken.STRING, JsonToken.NUMBER -> m[n] = r.nextString()
                            JsonToken.BOOLEAN -> m[n] = r.nextBoolean().toString()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    each(m)
                }
                r.endArray()
            }
        }
    }
}
