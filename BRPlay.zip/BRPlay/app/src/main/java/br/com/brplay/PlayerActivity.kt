package br.com.brplay

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import br.com.brplay.data.Kind
import br.com.brplay.data.Net
import br.com.brplay.data.PlayQueue
import br.com.brplay.data.Store
import br.com.brplay.data.Xtream

@UnstableApi
class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var titleView: TextView
    private lateinit var epgView: TextView
    private lateinit var msgView: TextView
    private lateinit var topBar: View
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var retries = 0
    private var triedTs = false
    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL,
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayQueue.items.isEmpty()) { finish(); return }
        store = Store(this)
        index = savedInstanceState?.getInt("idx") ?: PlayQueue.index
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        view = PlayerView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            controllerShowTimeoutMs = 4000
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setShowSubtitleButton(true)
        }
        root.addView(view)

        // Barra superior: voltar, título, agora no ar, ajuste de tela
        val back = ImageButton(this).apply {
            setImageResource(R.drawable.ic_back); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; setTypeface(typeface, Typeface.BOLD); maxLines = 1
        }
        epgView = TextView(this).apply { setTextColor(0xFFFFDF00.toInt()); textSize = 13f; maxLines = 1 }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView); addView(epgView)
        }
        val aspect = ImageButton(this).apply {
            setImageResource(R.drawable.ic_aspect); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                resizeIdx = (resizeIdx + 1) % resizeModes.size
                view.resizeMode = resizeModes[resizeIdx]
                Toast.makeText(this@PlayerActivity, listOf("Ajustar", "Ampliar", "Esticar")[resizeIdx], Toast.LENGTH_SHORT).show()
            }
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
            addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(aspect, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> topBar.visibility = v })

        msgView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xDD002776.toInt()) }
        }
        root.addView(msgView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        if (PlayQueue.items.isEmpty()) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(PlayQueue.playlist?.ua?.takeIf { it.isNotBlank() } ?: Net.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000).setReadTimeoutMs(20_000)
        val sources = DefaultMediaSourceFactory(
            DefaultDataSource.Factory(this, http),
            DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true),
        )
        val load = DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_500, 3_000).build()
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(sources).setLoadControl(load).setHandleAudioBecomingNoisy(true).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = handleError(error)
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { msgView.visibility = View.GONE; retries = 0 }
            }
        })
        player = p
        view.player = object : ForwardingPlayer(p) {
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon().addAll(Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS).build()
            override fun isCommandAvailable(command: Int) =
                command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_PREVIOUS || super.isCommandAvailable(command)
            override fun seekToNext() { zap(1) }
            override fun seekToPrevious() { zap(-1) }
            override fun seekToNextMediaItem() { zap(1) }
            override fun seekToPreviousMediaItem() { zap(-1) }
            override fun hasNextMediaItem() = true
            override fun hasPreviousMediaItem() = true
        }
        play(index)
    }

    override fun onStop() {
        super.onStop()
        if (!::view.isInitialized) return
        saveProgress()
        handler.removeCallbacksAndMessages(null)
        view.player = null
        player?.release(); player = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState); outState.putInt("idx", index)
    }

    private fun zap(delta: Int) {
        saveProgress()
        val n = PlayQueue.items.size
        play((index + delta + n) % n)
    }

    private fun saveProgress() {
        val p = player ?: return
        val it = PlayQueue.items.getOrNull(index) ?: return
        if (it.kind == Kind.LIVE) return
        val dur = p.duration
        val pos = p.currentPosition
        store.savePosition(it.url, if (dur > 0 && pos > dur * 0.95) 0 else pos)
    }

    private fun play(i: Int) {
        index = i; retries = 0; triedTs = false
        val item = PlayQueue.items[i]
        titleView.text = item.name; epgView.text = ""; msgView.visibility = View.GONE
        start(item.url, if (item.kind == Kind.LIVE) 0 else store.position(item.url))

        val pl = PlayQueue.playlist
        if (pl != null && pl.type == "xtream" && item.kind == Kind.LIVE && item.streamId.isNotEmpty()) {
            Thread {
                val txt = runCatching { Xtream(pl).nowNext(item.streamId) }.getOrNull()
                if (!txt.isNullOrEmpty()) runOnUiThread { if (index == i) epgView.text = "Agora  " + txt.first() }
            }.start()
        }
    }

    private fun start(url: String, pos: Long) {
        val p = player ?: return
        val mi = MediaItem.Builder().setUri(url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(PlayQueue.items[index].name).build())
            .apply { if (url.substringBefore('?').endsWith(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        p.setMediaItem(mi, pos)
        p.prepare()
        p.playWhenReady = true
    }

    private fun handleError(e: PlaybackException) {
        val p = player ?: return
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition(); p.prepare(); return
        }
        val item = PlayQueue.items[index]
        val xt = PlayQueue.playlist?.type == "xtream"
        if (!triedTs && xt && item.kind == Kind.LIVE && item.url.endsWith(".m3u8")) {
            triedTs = true
            start(item.url.removeSuffix(".m3u8") + ".ts", 0)
        } else if (retries < 2) {
            retries++
            handler.postDelayed({ player?.prepare() }, 1500)
        } else {
            msgView.text = "Não foi possível reproduzir.\nUse ◀ ▶ para trocar de item."
            msgView.visibility = View.VISIBLE
        }
    }
}
