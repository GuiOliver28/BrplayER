package br.com.brplay

import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.util.Rational
import android.app.AlertDialog
import android.view.KeyEvent
import android.text.TextUtils
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ListView
import androidx.activity.OnBackPressedCallback
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import br.com.brplay.data.Kind
import br.com.brplay.data.Net
import br.com.brplay.data.PlayQueue
import br.com.brplay.data.Store
import br.com.brplay.data.Xtream

private const val PIP_ACTION = "br.com.brplay.PIP_ACTION"

@UnstableApi
class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var titleView: TextView
    private lateinit var epgView: TextView
    private lateinit var msgView: TextView
    private lateinit var topBar: View
    private lateinit var nextBox: LinearLayout
    private lateinit var nextText: TextView
    private var countdown = 0
    private var inPip = false
    private var prevIndex = -1
    private val digits = StringBuilder()
    private lateinit var numView: TextView
    private lateinit var listPanel: ListView
    private lateinit var listBtn: TextView
    private lateinit var lastBtn: TextView
    private val commitNum = Runnable {
        val n = digits.toString().toIntOrNull(); digits.setLength(0); numView.visibility = View.GONE
        if (n != null && n in 1..PlayQueue.items.size) zapTo(n - 1)
        else Toast.makeText(this, "Canal inexistente", Toast.LENGTH_SHORT).show()
    }
    private var tv = false
    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.getIntExtra("c", 0)) {
                1 -> { player?.let { it.playWhenReady = !it.playWhenReady } }
                2 -> finishAndRemoveTask()
            }
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            if (nextBox.visibility != View.VISIBLE) return
            countdown--
            if (countdown <= 0) { hideNext(); zap(1) } else { updateNextText(); handler.postDelayed(this, 1000) }
        }
    }
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var index = 0
    private var retries = 0
    private var cands: List<String> = emptyList()
    private var candIdx = 0
    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FILL,
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayQueue.items.isEmpty()) { finish(); return }
        store = Store(this)
        tv = isTvDevice(this)
        index = savedInstanceState?.getInt("idx") ?: PlayQueue.index
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        view = PlayerView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            controllerShowTimeoutMs = 4000
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setShowSubtitleButton(true)
        }
        root.addView(view)

        // Barra superior: voltar, título, agora no ar, ajuste de tela
        val back = ImageButton(this).apply {
            setImageResource(R.drawable.ic_back); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; setTypeface(typeface, Typeface.BOLD); maxLines = 1
        }
        epgView = TextView(this).apply { setTextColor(0xFFFFDF00.toInt()); textSize = 13f; maxLines = 1 }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView); addView(epgView)
        }
        val aspect = ImageButton(this).apply {
            setImageResource(R.drawable.ic_aspect); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                resizeIdx = (resizeIdx + 1) % resizeModes.size
                view.resizeMode = resizeModes[resizeIdx]
                Toast.makeText(this@PlayerActivity, listOf("Ajustar", "Ampliar", "Esticar")[resizeIdx], Toast.LENGTH_SHORT).show()
            }
        }
        listBtn = tbtn("☰", "Lista de canais") { showList() }
        lastBtn = tbtn("⇄", "Último canal") { lastChannel() }
        val audioBtn = tbtn("♪", "Áudio") { pickAudio() }
        val pipBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_pip); setBackgroundColor(Color.TRANSPARENT); contentDescription = "Minimizar (janela flutuante)"
            setOnClickListener { enterPip() }
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
            addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(listBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(lastBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(audioBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
            if (pipSupported()) addView(pipBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(aspect, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> topBar.visibility = v })

        msgView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xDD002776.toInt()) }
        }
        root.addView(msgView, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        numView = TextView(this).apply {
            setTextColor(0xFFFFDF00.toInt()); textSize = 34f; setTypeface(typeface, Typeface.BOLD); visibility = View.GONE
            setPadding(dp(22), dp(10), dp(22), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xCC000000.toInt()) }
        }
        root.addView(numView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(70), dp(24), 0) })

        listPanel = ListView(this).apply {
            visibility = View.GONE; divider = null; isFocusable = true; isFocusableInTouchMode = true
            setBackgroundColor(0xF2061230.toInt())
            adapter = object : BaseAdapter() {
                override fun getCount() = PlayQueue.items.size
                override fun getItem(position: Int) = PlayQueue.items[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val t = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                        textSize = 17f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                        setPadding(dp(16), dp(12), dp(12), dp(12))
                    }
                    t.text = "${position + 1}   ${PlayQueue.items[position].name}"
                    t.setTextColor(if (position == index) 0xFFFFDF00.toInt() else Color.WHITE)
                    return t
                }
            }
            setOnItemClickListener { _, _, pos, _ -> hideList(); zapTo(pos) }
        }
        root.addView(listPanel, FrameLayout.LayoutParams(dp(340), -1, Gravity.START))
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (listPanel.visibility == View.VISIBLE) hideList()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        // Overlay "Próximo episódio" com contagem regressiva
        nextText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setTypeface(typeface, Typeface.BOLD) }
        fun btn(label: String, bg: Int, fg: Int, click: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(fg); textSize = 14f; setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(16), dp(10), dp(16), dp(10)); isFocusable = true; isClickable = true
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(bg) }
            setOnClickListener { click() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0)
            addView(btn("Assistir agora", 0xFF009C3B.toInt(), Color.WHITE) { hideNext(); zap(1) })
            addView(btn("Cancelar", 0x33FFFFFF, Color.WHITE) { hideNext() }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }
        nextBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xE606122B.toInt()); setStroke(dp(1), 0xFFFFDF00.toInt()) }
            addView(nextText); addView(row)
        }
        root.addView(nextBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(dp(16), dp(16), dp(16), dp(72)) })
        setContentView(root)
        ContextCompat.registerReceiver(this, pipReceiver, IntentFilter(PIP_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun pipSupported() = !tv && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
        packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun pipParams(): PictureInPictureParams {
        fun act(icon: Int, title: String, code: Int) = RemoteAction(
            Icon.createWithResource(this, icon), title, title,
            PendingIntent.getBroadcast(this, code, Intent(PIP_ACTION).setPackage(packageName).putExtra("c", code),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT),
        )
        val playing = player?.playWhenReady == true
        return PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).setActions(listOf(
            act(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, if (playing) "Pausar" else "Reproduzir", 1),
            act(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", 2),
        )).build()
    }

    private fun enterPip() {
        if (!pipSupported()) return
        runCatching { enterPictureInPictureMode(pipParams()) }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    private fun tbtn(label: String, desc: String, click: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER; contentDescription = desc
        isFocusable = true; isClickable = true; setOnClickListener { click() }
        setOnFocusChangeListener { v, f -> v.setBackgroundColor(if (f) 0x66FFDF00 else Color.TRANSPARENT) }
    }

    private fun showList() {
        (listPanel.adapter as BaseAdapter).notifyDataSetChanged()
        listPanel.visibility = View.VISIBLE
        listPanel.setSelection((index - 3).coerceAtLeast(0))
        listPanel.requestFocus()
        view.hideController()
    }

    private fun hideList() { listPanel.visibility = View.GONE; view.requestFocus() }

    private fun zapTo(i: Int) {
        if (i == index || i !in PlayQueue.items.indices) return
        hideNext(); saveProgress(); play(i)
    }

    private fun lastChannel() {
        if (prevIndex in PlayQueue.items.indices) zapTo(prevIndex)
        else Toast.makeText(this, "Ainda não há canal anterior", Toast.LENGTH_SHORT).show()
    }

    private fun typeDigit(d: Int) {
        if (digits.length >= 4) digits.setLength(0)
        digits.append(d)
        numView.text = "Canal  $digits"; numView.visibility = View.VISIBLE
        handler.removeCallbacks(commitNum); handler.postDelayed(commitNum, 1800)
    }

    private fun pickAudio() {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
        if (groups.size < 2) {
            Toast.makeText(this, if (groups.isEmpty()) "Sem faixas de áudio disponíveis" else "Só há uma faixa de áudio", Toast.LENGTH_SHORT).show()
            return
        }
        val names = groups.mapIndexed { i, g ->
            val f = g.getTrackFormat(0)
            (f.label ?: f.language?.uppercase() ?: "Faixa ${i + 1}") + (if (g.isSelected) "  ✓" else "")
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Áudio").setItems(names) { _, w ->
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setOverrideForType(TrackSelectionOverride(groups[w].mediaTrackGroup, 0)).build()
        }.show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && ::listPanel.isInitialized && listPanel.visibility != View.VISIBLE &&
            PlayQueue.items.getOrNull(index)?.kind == Kind.LIVE) {
            val k = e.keyCode
            val d = when (k) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> k - KeyEvent.KEYCODE_0
                in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> k - KeyEvent.KEYCODE_NUMPAD_0
                else -> -1
            }
            if (d >= 0) { typeDigit(d); return true }
            when (k) {
                KeyEvent.KEYCODE_CHANNEL_UP -> { zap(1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
                KeyEvent.KEYCODE_LAST_CHANNEL -> { lastChannel(); return true }
                KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_MENU -> { showList(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> if (!view.isControllerFullyVisible) { showList(); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun updateNextText() {
        val n = PlayQueue.items.getOrNull(index + 1)
        val label = n?.name?.substringBefore("  ") ?: ""
        nextText.text = "Próximo: $label  ·  em ${countdown}s"
    }

    private fun showNext() {
        countdown = 10; updateNextText(); nextBox.visibility = View.VISIBLE
        handler.removeCallbacks(tick); handler.postDelayed(tick, 1000)
    }

    private fun hideNext() {
        if (::nextBox.isInitialized) nextBox.visibility = View.GONE
        handler.removeCallbacks(tick)
    }

    override fun onStart() {
        super.onStart()
        if (PlayQueue.items.isEmpty()) return
        Net.insecure = store.bool("insecureSsl", false)
        Net.applyGlobalSsl()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(PlayQueue.playlist?.ua?.takeIf { it.isNotBlank() } ?: Net.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000).setReadTimeoutMs(20_000)
        val sources = DefaultMediaSourceFactory(
            DefaultDataSource.Factory(this, http),
            DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true),
        )
        val load = when (store.int("buffer", 1)) {
            0 -> DefaultLoadControl.Builder().setBufferDurationsMs(8_000, 30_000, 1_000, 2_000)
            2 -> DefaultLoadControl.Builder().setBufferDurationsMs(30_000, 120_000, 2_500, 5_000)
            else -> DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
        }.build()
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(sources).setLoadControl(load).setHandleAudioBecomingNoisy(true).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = handleError(error)
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (inPip) runCatching { setPictureInPictureParams(pipParams()) }
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { msgView.visibility = View.GONE; retries = 0 }
                if (state == Player.STATE_ENDED) {
                    val cur = PlayQueue.items.getOrNull(index)
                    if (cur != null && cur.kind == Kind.SERIES && index + 1 < PlayQueue.items.size) showNext()
                }
            }
        })
        player = p
        view.player = object : ForwardingPlayer(p) {
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon().addAll(Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS).build()
            override fun isCommandAvailable(command: Int) =
                command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_PREVIOUS || super.isCommandAvailable(command)
            override fun seekToNext() { zap(1) }
            override fun seekToPrevious() { zap(-1) }
            override fun seekToNextMediaItem() { zap(1) }
            override fun seekToPreviousMediaItem() { zap(-1) }
            override fun hasNextMediaItem() = true
            override fun hasPreviousMediaItem() = true
        }
        play(index)
    }

    override fun onStop() {
        super.onStop()
        if (!::view.isInitialized) return
        saveProgress()
        handler.removeCallbacksAndMessages(null)
        view.player = null
        player?.release(); player = null
        // janelinha fechada pelo X (ou tela apagou em PiP): encerra de vez, sem deixar tela preta para trás
        if (inPip || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode)) finishAndRemoveTask()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Só em celular/tablet. Na TV o Home simplesmente para o vídeo (sem janelinha impossível de fechar).
        if (!tv && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        view.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) { topBar.visibility = View.GONE; hideNext() }
        else if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) finishAndRemoveTask()   // fechou pelo X
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState); outState.putInt("idx", index)
    }

    private fun zap(delta: Int) {
        hideNext()
        saveProgress()
        val n = PlayQueue.items.size
        play((index + delta + n) % n)
    }

    private fun saveProgress() {
        val p = player ?: return
        val it = PlayQueue.items.getOrNull(index) ?: return
        if (it.kind == Kind.LIVE) return
        val dur = p.duration
        val pos = p.currentPosition
        store.savePosition(it.url, if (dur > 0 && pos > dur * 0.9) 0 else pos)
        store.recordProgress(it, pos, dur)
    }

    private fun play(i: Int) {
        if (index != i && PlayQueue.items.getOrNull(index)?.kind == Kind.LIVE) prevIndex = index
        index = i; retries = 0
        hideNext()
        val item = PlayQueue.items[i]
        val isLive = item.kind == Kind.LIVE
        listBtn.visibility = if (isLive) View.VISIBLE else View.GONE
        lastBtn.visibility = if (isLive) View.VISIBLE else View.GONE
        if (item.kind == Kind.LIVE) store.addRecent(item.url)
        titleView.text = item.name; epgView.text = ""; msgView.visibility = View.GONE
        // Alternativas tentadas em ordem se o stream falhar: .ts, sem extensão e http<->https
        val xt = PlayQueue.playlist?.type == "xtream"
        val list = ArrayList<String>()
        list += item.url
        if (xt && item.kind == Kind.LIVE && item.url.endsWith(".m3u8")) {
            list += item.url.removeSuffix(".m3u8") + ".ts"
            list += item.url.removeSuffix(".m3u8")
        }
        list += Net.swapScheme(item.url)
        cands = list.distinct(); candIdx = 0
        start(cands[0], if (item.kind == Kind.LIVE) 0 else store.position(item.url))

        val pl = PlayQueue.playlist
        if (pl != null && pl.type == "xtream" && item.kind == Kind.LIVE && item.streamId.isNotEmpty()) {
            Thread {
                val txt = runCatching { Xtream(pl).nowNext(item.streamId) }.getOrNull()
                if (!txt.isNullOrEmpty()) runOnUiThread { if (index == i) epgView.text = "Agora  " + txt.first() }
            }.start()
        }
    }

    private fun start(url: String, pos: Long) {
        val p = player ?: return
        val mi = MediaItem.Builder().setUri(url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(PlayQueue.items[index].name).build())
            .apply { if (url.substringBefore('?').endsWith(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        p.setMediaItem(mi, pos)
        p.prepare()
        p.playWhenReady = true
    }

    private fun handleError(e: PlaybackException) {
        val p = player ?: return
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition(); p.prepare(); return
        }
        android.util.Log.w("BRPlay", "Erro de reprodução (${e.errorCodeName}) em ${cands.getOrNull(candIdx)}")
        val maxTries = if (PlayQueue.items.getOrNull(index)?.kind == Kind.LIVE && candIdx == 0) 3 else 1
        if (retries < maxTries) {
            val wait = 1500L shl retries
            retries++
            msgView.text = "Reconectando… ($retries/$maxTries)"; msgView.visibility = View.VISIBLE
            handler.postDelayed({ player?.prepare() }, wait)
        } else if (candIdx + 1 < cands.size) {
            candIdx++; retries = 0
            start(cands[candIdx], 0)
        } else {
            msgView.text = "Não foi possível reproduzir.\nUse ◀ ▶ para trocar de item."
            msgView.visibility = View.VISIBLE
        }
    }
}
