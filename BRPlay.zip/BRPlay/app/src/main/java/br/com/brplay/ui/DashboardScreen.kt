package br.com.brplay.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.SyncStatus
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Cores do painel
private val DashBg = Color(0xFF07130F)
private val DashGreen = Color(0xFF1FA45A)
private val DashBlue = Color(0xFF1E6FD0)
private val DashDeepBlue = Color(0xFF0B3C8C)
private val DashYellow = Color(0xFFFFD21F)
private val DashOrange = Color(0xFFFF9500)
private val DashTime = Color(0xFF7BC96F)
private val DashCream = Color(0xFFF3EAC0)
private val DashSmall = Color(0xFF2B5C50)
private val AvatarColors = listOf(Color(0xFF1FA45A), Color(0xFF1E6FD0), Color(0xFFE8A900), Color(0xFFB5379A))

/**
 * Bloco reutilizável do painel. Na TV (D-pad) o foco aparece como borda branca grossa.
 * [small] = botão baixo (ícone ao lado do texto).
 */
@Composable
fun DashboardBlock(
    title: String,
    icon: ImageVector,
    background: Brush,
    contentColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    busy: Boolean = false,
    subtitle: String? = null,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    BoxWithConstraints(
        modifier.clip(shape).background(background)
            .border(if (focused) 4.dp else 0.dp, Color.White, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (small) {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text(title, color = contentColor, fontWeight = FontWeight.Medium, fontSize = 13.sp, textAlign = TextAlign.Start, maxLines = 3, lineHeight = 15.sp)
            }
        } else {
            val side = minOf(maxWidth, maxHeight)
            val iconSize = (side * 0.30f).coerceIn(30.dp, 76.dp)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (busy) CircularProgressIndicator(color = iconTint, strokeWidth = 4.dp, modifier = Modifier.size(iconSize))
                else Icon(icon, null, tint = iconTint, modifier = Modifier.size(iconSize))
                Text(title, color = contentColor, fontWeight = FontWeight.Medium, fontSize = (side.value * 0.085f).coerceIn(14f, 22f).sp, textAlign = TextAlign.Center)
                subtitle?.let { Text(it, color = contentColor.copy(alpha = .8f), fontSize = 12.sp, textAlign = TextAlign.Center) }
            }
        }
    }
}

/** Cartão grande (TV ao vivo / Filmes / Séries) com "Última atualização" e botão para atualizar só aquela categoria. */
@Composable
private fun DashCard(
    title: String,
    icon: ImageVector,
    background: Brush,
    ink: Color,
    iconTint: Color,
    updated: String,
    refreshing: Boolean,
    modifier: Modifier,
    onRefresh: () -> Unit,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.clip(shape).background(background)
            .border(if (focused) 4.dp else 1.dp, if (focused) Color.White else DashYellow.copy(alpha = .45f), shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val side = minOf(maxWidth, maxHeight)
            val iconSize = (side * 0.40f).coerceIn(34.dp, 84.dp)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.size(iconSize))
                Text(title, color = ink, fontWeight = FontWeight.Bold, fontSize = (side.value * 0.13f).coerceIn(16f, 26f).sp, textAlign = TextAlign.Center)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(updated, color = ink, fontSize = 12.sp, maxLines = 2, lineHeight = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(6.dp))
            var rf by remember { mutableStateOf(false) }
            Box(
                Modifier.size(36.dp).clip(CircleShape).border(if (rf) 3.dp else 0.dp, Color.White, CircleShape)
                    .onFocusChanged { rf = it.isFocused }.clickable(onClick = onRefresh),
                contentAlignment = Alignment.Center,
            ) {
                if (refreshing) CircularProgressIndicator(color = ink, strokeWidth = 3.dp, modifier = Modifier.size(22.dp))
                else Icon(Icons.Rounded.Autorenew, "Atualizar $title", tint = ink, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun HeaderIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = .07f))
            .border(if (focused) 3.dp else 0.dp, Color.White, CircleShape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = DashYellow, modifier = Modifier.size(22.dp)) }
}

/** "Perfil" = uma das suas listas: toque para trocar de lista. O "+" adiciona uma nova. */
@Composable
private fun ProfileTile(size: androidx.compose.ui.unit.Dp, label: String, color: Color, selected: Boolean, add: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.size(size).clip(shape).background(Color.White)
            .border(if (focused) 4.dp else if (selected) 3.dp else 0.dp, if (focused) Color.White else DashYellow, shape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (add) Icon(Icons.Rounded.Add, "Adicionar lista", tint = Color(0xFF444444), modifier = Modifier.size(size * 0.6f))
        else Text(label.trim().take(1).uppercase().ifEmpty { "?" }, color = color, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp)
    }
}

private fun dateText(now: Long): String =
    SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date(now))
        .split(" ").joinToString(" ") { if (it == "de") it else it.replaceFirstChar { c -> c.uppercase() } }

private fun agoText(ts: Long, now: Long): String {
    if (ts <= 1L) return "Ainda não atualizado"
    val s = ((now - ts) / 1000).coerceAtLeast(0)
    return "Última atualização: " + when {
        s < 60 -> "$s seg atrás"
        s < 3600 -> "${s / 60} min atrás"
        s < 86400 -> "${s / 3600} h atrás"
        else -> "${s / 86400} d atrás"
    }
}

private fun expiryText(raw: String?): String = when {
    raw == null -> "—"
    raw.isBlank() || raw == "null" || raw == "0" -> "Ilimitado"
    raw.all { it.isDigit() } -> runCatching { SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(raw.toLong() * 1000)) }.getOrDefault("—")
    else -> raw
}

/**
 * Tela inicial. Paisagem/TV: cabeçalho, 3 cartões lado a lado, botões menores, perfis e engrenagem.
 * Retrato: tudo empilhado (TV ao vivo na largura toda, Filmes e Séries lado a lado).
 * Funciona também sem nenhuma lista: os blocos levam a "adicionar lista".
 */
@Composable
fun DashboardScreen(
    vm: MainVm,
    tv: Boolean,
    onLive: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onSearch: () -> Unit,
    onFavorites: () -> Unit,
    onSettings: () -> Unit,
    onAdd: () -> Unit,
    onEpg: () -> Unit,
    onSeriesItem: (Item) -> Unit,
) {
    val ctx = LocalContext.current
    val active by vm.active.collectAsStateWithLifecycle()
    val lists by vm.playlists.collectAsStateWithLifecycle()
    val syncing by vm.syncing.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val ks by vm.kindSync.collectAsStateWithLifecycle()
    val stamps by vm.lastUpdate.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val hasList = lists.isNotEmpty()
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(10_000) } }
    val minute = now / 60_000
    val date = remember(minute) { dateText(now) }
    val time = remember(minute) { SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(now)) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }
    val expiry = remember(active?.id, syncing) { expiryText(active?.let { vm.store.str("exp_" + it.id, "?") }?.takeIf { it != "?" }) }
    LaunchedEffect(active?.id, syncing, loading) { vm.loadLastUpdate() }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(tv) { if (tv) runCatching { firstFocus.requestFocus() } }

    val liveBrush = Brush.verticalGradient(listOf(DashGreen, DashBlue))
    val movieBrush = Brush.linearGradient(listOf(DashYellow, DashOrange))
    val seriesBrush = Brush.verticalGradient(listOf(DashBlue, DashDeepBlue))
    val small = SolidColor(DashSmall)
    val soon = { what: String -> Toast.makeText(ctx, "$what ainda não está disponível nesta versão.", Toast.LENGTH_SHORT).show() }
    val replay = {
        val last = history.firstOrNull()
        if (last != null) launchPlayer(ctx, listOf(last.item), last.item, vm)
        else Toast.makeText(ctx, "Você ainda não assistiu nada para repetir.", Toast.LENGTH_SHORT).show()
    }
    fun go(action: () -> Unit) = if (hasList) action() else {
        Toast.makeText(ctx, "Nenhuma lista configurada. Adicione uma lista primeiro.", Toast.LENGTH_LONG).show()
        onAdd()
    }

    @Composable fun card(kind: Kind, title: String, icon: ImageVector, brush: Brush, ink: Color, tint: Color, m: Modifier, open: () -> Unit) =
        DashCard(
            title, icon, brush, ink, tint,
            if (hasList) agoText(stamps[kind] ?: 0L, now) else "Toque para adicionar uma lista",
            refreshing = ks[kind]?.status == SyncStatus.LOADING, modifier = m,
            onRefresh = { go { vm.syncKinds(listOf(kind)) } }, onClick = { go(open) },
        )
    @Composable fun liveCard(m: Modifier) = card(Kind.LIVE, "TV AO VIVO", Icons.Rounded.Tv, liveBrush, Color.White, DashYellow, m.focusRequester(firstFocus), onLive)
    @Composable fun movieCard(m: Modifier) = card(Kind.MOVIE, "FILMES", Icons.Rounded.Videocam, movieBrush, Color(0xFF14284B), DashDeepBlue, m, onMovies)
    @Composable fun seriesCard(m: Modifier) = card(Kind.SERIES, "SÉRIES", Icons.Rounded.Movie, seriesBrush, Color.White, DashYellow, m, onSeries)

    @Composable fun epgBlock(m: Modifier) = DashboardBlock("GUIA DE PROGRAMAÇÃO EPG", Icons.Rounded.MenuBook, small, DashCream, DashYellow, m, small = true) { go(onEpg) }
    @Composable fun multiBlock(m: Modifier) = DashboardBlock("MULTI-SCREEN", Icons.Rounded.GridView, small, DashCream, DashYellow, m, small = true) { soon("O multi-screen") }
    @Composable fun replayBlock(m: Modifier) = DashboardBlock("REPLAY ANTERIOR", Icons.Rounded.Replay, small, DashCream, DashYellow, m, small = true, onClick = replay)

    @Composable fun profiles(size: androidx.compose.ui.unit.Dp) = Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        lists.take(4).forEachIndexed { i, l ->
            ProfileTile(size, l.name, AvatarColors[i % AvatarColors.size], selected = l.id == active?.id, add = false) { vm.openPlaylist(l) }
        }
        if (lists.size < 4) ProfileTile(size, "+", Color.Gray, selected = false, add = true, onClick = onAdd)
    }

    @Composable fun gear() = Column(
        Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onSettings).padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Rounded.Settings, "Configurações", tint = DashOrange, modifier = Modifier.size(34.dp))
        Text("Configurações", color = DashOrange, fontSize = 12.sp, maxLines = 1)
    }

    @Composable fun brand() = Row(verticalAlignment = Alignment.CenterVertically) {
        LogoMark(44.dp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = DashBlue)) { append("BR ") }
                withStyle(SpanStyle(color = DashYellow)) { append("PLAY") }
            }, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("TV & Streaming", color = DashCream.copy(alpha = .8f), fontSize = 11.sp)
        }
    }

    @Composable fun clock() = Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(date, color = DashCream, fontSize = 14.sp)
        Text(time, color = DashTime, fontSize = 38.sp, fontWeight = FontWeight.Medium)
    }

    @Composable fun topIcons() = Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        HeaderIcon(Icons.Rounded.Search, "Buscar", onSearch)
        HeaderIcon(Icons.Rounded.FavoriteBorder, "Favoritos", onFavorites)
    }

    @Composable fun footer() = Text(
        if (hasList) buildAnnotatedString {
            withStyle(SpanStyle(color = DashYellow)) { append("Playlist Atual: ") }
            withStyle(SpanStyle(color = DashTime)) { append(active?.name ?: "—") }
            withStyle(SpanStyle(color = Color.White.copy(alpha = .5f))) { append("  |  ") }
            withStyle(SpanStyle(color = DashYellow)) { append("Vencimento: ") }
            withStyle(SpanStyle(color = DashTime)) { append(expiry) }
            withStyle(SpanStyle(color = Color.White.copy(alpha = .5f))) { append("  |  ") }
            withStyle(SpanStyle(color = DashTime)) { append("V $version") }
        } else buildAnnotatedString {
            withStyle(SpanStyle(color = DashYellow)) { append("Nenhuma lista adicionada. Toque em um bloco para começar.  |  V $version") }
        },
        fontSize = 12.sp, maxLines = 1,
    )

    BoxWithConstraints(Modifier.fillMaxSize().background(DashBg)) {
        val landscape = tv || maxWidth > maxHeight
        val wPx = with(LocalDensity.current) { maxWidth.toPx() }
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(DashGreen.copy(alpha = .30f), DashDeepBlue.copy(alpha = .10f), Color.Transparent),
                    center = Offset(wPx / 2f, 0f), radius = wPx * 0.8f,
                ),
            ),
        )
        if (landscape) {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 8.dp)) {
                Box(Modifier.fillMaxWidth().height(74.dp)) {
                    Box(Modifier.align(Alignment.CenterStart)) { brand() }
                    Box(Modifier.align(Alignment.Center)) { clock() }
                    Box(Modifier.align(Alignment.CenterEnd)) { topIcons() }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    liveCard(Modifier.weight(1f).fillMaxHeight())
                    movieCard(Modifier.weight(1f).fillMaxHeight())
                    seriesCard(Modifier.weight(1f).fillMaxHeight())
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().height(66.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    epgBlock(Modifier.weight(1f).fillMaxHeight())
                    multiBlock(Modifier.weight(1f).fillMaxHeight())
                    replayBlock(Modifier.weight(1f).fillMaxHeight())
                    Column(Modifier.weight(1.4f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SELECIONE PERFIL", color = DashTime, fontSize = 11.sp)
                        Spacer(Modifier.height(3.dp))
                        profiles(46.dp)
                    }
                    gear()
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { footer() }
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    brand()
                    Spacer(Modifier.weight(1f))
                    topIcons()
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { clock() }
                liveCard(Modifier.fillMaxWidth().height(180.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    movieCard(Modifier.weight(1f).height(170.dp))
                    seriesCard(Modifier.weight(1f).height(170.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    epgBlock(Modifier.weight(1f).height(60.dp))
                    multiBlock(Modifier.weight(1f).height(60.dp))
                }
                replayBlock(Modifier.fillMaxWidth().height(60.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SELECIONE PERFIL", color = DashTime, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        profiles(52.dp)
                    }
                    gear()
                }
                if (history.isNotEmpty()) ContinueRow(history, vm, favs, 0.dp)
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { footer() }
            }
        }
    }
}
