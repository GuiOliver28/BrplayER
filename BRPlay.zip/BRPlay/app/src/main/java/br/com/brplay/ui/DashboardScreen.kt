package br.com.brplay.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Cores do painel (estilo Smart TV)
private val DashBg = Color(0xFF0A0E17)
private val DashGreen = Color(0xFF00A83A)
private val DashBlue = Color(0xFF002060)
private val DashYellow = Color(0xFFFFD700)
private val DashCyanA = Color(0xFF8DE4D3)
private val DashCyanB = Color(0xFF6EC6FF)
private val DashInk = Color(0xFF0A2540)

/**
 * Bloco reutilizável do painel. Na TV (D-pad) o foco aparece como borda branca grossa.
 * [small] = botão baixo da linha de baixo (ícone ao lado do texto).
 */
@Composable
fun DashboardBlock(
    title: String,
    icon: ImageVector,
    background: Brush,
    contentColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    busy: Boolean = false,
    subtitle: String? = null,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(6.dp)
    BoxWithConstraints(
        modifier.clip(shape).background(background)
            .border(if (focused) 4.dp else 0.dp, Color.White, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (small) {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = contentColor, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Text(title, color = contentColor, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Start, maxLines = 2, lineHeight = 17.sp)
            }
        } else {
            val side = minOf(maxWidth, maxHeight)
            val iconSize = (side * 0.30f).coerceIn(30.dp, 76.dp)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (busy) CircularProgressIndicator(color = iconTint, strokeWidth = 4.dp, modifier = Modifier.size(iconSize))
                else Icon(icon, null, tint = iconTint, modifier = Modifier.size(iconSize))
                Text(title, color = contentColor, fontWeight = FontWeight.Medium, fontSize = (side.value * 0.085f).coerceIn(14f, 22f).sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
                subtitle?.let { Text(it, color = contentColor.copy(alpha = .8f), fontSize = 12.sp, textAlign = TextAlign.Center) }
            }
        }
    }
}

@Composable
private fun HeaderIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = .07f))
            .border(if (focused) 3.dp else 0.dp, Color.White, CircleShape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = DashYellow, modifier = Modifier.size(24.dp)) }
}

private fun dateText(now: Long): String {
    val loc = Locale("pt", "BR")
    val wd = SimpleDateFormat("EEEE", loc).format(Date(now)).replace("-feira", "").replaceFirstChar { it.uppercase() }
    val rest = SimpleDateFormat("MMM d, yyyy", loc).format(Date(now)).replace(".", "")
    return "$wd, $rest"
}

private fun expiryText(raw: String?): String = when {
    raw == null -> "—"
    raw.isBlank() || raw == "null" || raw == "0" -> "Ilimitado"
    raw.all { it.isDigit() } -> runCatching { SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(raw.toLong() * 1000)) }.getOrDefault("—")
    else -> raw
}

/**
 * Tela inicial em blocos (estilo Smart TV). Paisagem/TV: blocos lado a lado. Retrato: blocos empilhados em 2 colunas,
 * com "TV AO VIVO" na largura toda.
 */
@Composable
fun DashboardScreen(
    vm: MainVm,
    tv: Boolean,
    onLive: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onSearch: () -> Unit,
    onFavorites: () -> Unit,
    onProfile: () -> Unit,
    onSettings: () -> Unit,
    onSync: () -> Unit,
    onSeriesItem: (Item) -> Unit,
) {
    val ctx = LocalContext.current
    val active by vm.active.collectAsStateWithLifecycle()
    val syncing by vm.syncing.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(15_000) } }
    val minute = now / 60_000
    val date = remember(minute) { dateText(now) }
    val time = remember(minute) { SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(now)) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "" }
    val expiry = remember(active?.id, syncing) { expiryText(active?.let { vm.store.str("exp_" + it.id, "?") }?.takeIf { it != "?" }) }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(tv) { if (tv) runCatching { firstFocus.requestFocus() } }

    val green = SolidColor(DashGreen); val blue = SolidColor(DashBlue); val yellow = SolidColor(DashYellow)
    val cyan = Brush.linearGradient(listOf(DashCyanA, DashCyanB))
    val catchUp = { Toast.makeText(ctx, "Catch-up ainda não está disponível nesta versão.", Toast.LENGTH_SHORT).show() }

    @Composable fun liveBlock(m: Modifier) = DashboardBlock("TV AO VIVO", Icons.Rounded.PlayCircleOutline, green, Color.White, DashYellow, m.focusRequester(firstFocus), onClick = onLive)
    @Composable fun movieBlock(m: Modifier) = DashboardBlock("FILMES", Icons.Rounded.Theaters, blue, Color.White, DashYellow, m, onClick = onMovies)
    @Composable fun seriesBlock(m: Modifier) = DashboardBlock("SÉRIES", Icons.Rounded.VideoLibrary, yellow, Color.Black, DashBlue, m, onClick = onSeries)
    @Composable fun reloadBlock(m: Modifier) = DashboardBlock(
        if (syncing) "ATUALIZANDO…" else "RECARREGAR\nTUDO", Icons.Rounded.Autorenew, yellow, Color.Black, DashBlue, m, busy = syncing,
        onClick = { vm.syncKinds(listOf(Kind.LIVE, Kind.MOVIE, Kind.SERIES)) },
    )
    @Composable fun catchBlock(m: Modifier) = DashboardBlock("CATCH-UP", Icons.Rounded.History, cyan, DashInk, DashInk, m, small = true, onClick = catchUp)
    @Composable fun settingsBlock(m: Modifier) = DashboardBlock("CONFIGURAÇÕES", Icons.Rounded.Settings, cyan, DashInk, DashInk, m, small = true, onClick = onSettings)
    @Composable fun syncBlock(m: Modifier) = DashboardBlock("ATUALIZAR\nLISTAS", Icons.Rounded.Sync, cyan, DashInk, DashInk, m, small = true, onClick = onSync)

    @Composable fun footer() = Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = DashYellow)) { append("Playlist Atual: ") }
            withStyle(SpanStyle(color = DashCyanB)) { append(active?.name ?: "—") }
            withStyle(SpanStyle(color = Color.White.copy(alpha = .6f))) { append("  |  ") }
            withStyle(SpanStyle(color = DashYellow)) { append("Vencimento: ") }
            withStyle(SpanStyle(color = DashCyanB)) { append(expiry) }
            withStyle(SpanStyle(color = Color.White.copy(alpha = .6f))) { append("  |  ") }
            withStyle(SpanStyle(color = DashCyanB)) { append("V $version") }
        },
        fontSize = 13.sp, maxLines = 1,
    )

    @Composable fun icons() = Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        HeaderIcon(Icons.Rounded.Search, "Buscar", onSearch)
        HeaderIcon(Icons.Rounded.FavoriteBorder, "Favoritos", onFavorites)
        HeaderIcon(Icons.Rounded.AccountCircle, "Minhas listas", onProfile)
        HeaderIcon(Icons.Rounded.Settings, "Configurações", onSettings)
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(DashBg).statusBarsPadding()) {
        val landscape = tv || maxWidth > maxHeight
        val wPx = with(LocalDensity.current) { maxWidth.toPx() }
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(DashGreen.copy(alpha = .40f), DashYellow.copy(alpha = .12f), Color.Transparent),
                    center = Offset(wPx / 2f, 0f), radius = wPx * 0.75f,
                ),
            ),
        )
        if (landscape) {
            Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    LogoMark(52.dp)
                    Spacer(Modifier.width(18.dp))
                    Column {
                        Text(date, color = DashYellow, fontSize = 14.sp)
                        Text(time, color = DashYellow, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.weight(1f))
                    icons()
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    liveBlock(Modifier.weight(1f).fillMaxHeight())
                    Column(Modifier.weight(2f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.weight(3f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            movieBlock(Modifier.weight(1f).fillMaxHeight())
                            seriesBlock(Modifier.weight(1f).fillMaxHeight())
                            reloadBlock(Modifier.weight(1f).fillMaxHeight())
                        }
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            catchBlock(Modifier.weight(1f).fillMaxHeight())
                            settingsBlock(Modifier.weight(1f).fillMaxHeight())
                            syncBlock(Modifier.weight(1f).fillMaxHeight())
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                footer()
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    LogoMark(44.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("BR Play", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    icons()
                }
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(date, color = DashYellow, fontSize = 14.sp)
                    Text(time, color = DashYellow, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                }
                liveBlock(Modifier.fillMaxWidth().height(170.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    movieBlock(Modifier.weight(1f).height(138.dp))
                    seriesBlock(Modifier.weight(1f).height(138.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    reloadBlock(Modifier.weight(1f).height(110.dp))
                    syncBlock(Modifier.weight(1f).height(110.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    catchBlock(Modifier.weight(1f).height(62.dp))
                    settingsBlock(Modifier.weight(1f).height(62.dp))
                }
                if (history.isNotEmpty()) ContinueRow(history, vm, favs, 0.dp)
                Spacer(Modifier.height(4.dp))
                footer()
            }
        }
    }
}
