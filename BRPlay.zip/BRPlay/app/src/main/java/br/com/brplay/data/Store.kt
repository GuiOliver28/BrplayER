package br.com.brplay.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persistência leve: SharedPreferences (listas, favoritos, posição) + cache em arquivo dos itens. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("brplay", Context.MODE_PRIVATE)
    private val dir = ctx.filesDir

    fun playlists(): List<Playlist> = runCatching {
        val a = JSONArray(sp.getString("playlists", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Playlist(
                o.getString("id"), o.getString("name"), o.getString("type"), o.getString("source"),
                o.optString("user"), o.optString("pass"), o.optString("ua"),
            )
        }
    }.getOrDefault(emptyList())

    fun savePlaylists(list: List<Playlist>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                .put("source", it.source).put("user", it.user).put("pass", it.pass).put("ua", it.ua))
        }
        sp.edit().putString("playlists", a.toString()).apply()
    }

    var activeId: String
        get() = sp.getString("active", "") ?: ""
        set(v) { sp.edit().putString("active", v).apply() }

    fun favorites(): Set<String> = sp.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
    fun saveFavorites(s: Set<String>) { sp.edit().putStringSet("fav", HashSet(s)).apply() }

    fun position(url: String): Long = sp.getLong("pos_" + url.hashCode(), 0L)
    fun savePosition(url: String, ms: Long) {
        sp.edit().apply { if (ms <= 0) remove("pos_" + url.hashCode()) else putLong("pos_" + url.hashCode(), ms) }.apply()
    }

    // ---- cache de itens (TSV) para abrir instantaneamente ----
    private fun cacheFile(id: String) = File(dir, "cache_$id.tsv")

    fun saveItems(id: String, items: List<Item>) {
        cacheFile(id).bufferedWriter().use { w ->
            for (i in items) {
                w.append(i.kind.name).append('\t').append(c(i.name)).append('\t').append(c(i.url)).append('\t')
                    .append(c(i.logo)).append('\t').append(c(i.group)).append('\t').append(c(i.epgId)).append('\t')
                    .append(c(i.streamId)).append('\t').append(c(i.seriesId)).append('\n')
            }
        }
    }

    fun loadItems(id: String): List<Item>? {
        val f = cacheFile(id)
        if (!f.exists()) return null
        return runCatching {
            val out = ArrayList<Item>(8192)
            f.bufferedReader().useLines { lines ->
                for (l in lines) {
                    val p = l.split('\t')
                    if (p.size < 8) continue
                    out += Item(Kind.valueOf(p[0]), p[1], p[2], p[3], p[4], p[5], p[6], p[7])
                }
            }
            out
        }.getOrNull()
    }

    fun deletePlaylistData(p: Playlist) {
        cacheFile(p.id).delete()
        if (p.type == "file") File(p.source).delete()
    }

    private fun c(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')
}
