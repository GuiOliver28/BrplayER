package br.com.brplay.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persistência leve: SharedPreferences (listas, favoritos, posição) + cache em arquivo dos itens. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("brplay", Context.MODE_PRIVATE)
    private val dir = ctx.filesDir

    fun playlists(): List<Playlist> = runCatching {
        val a = JSONArray(sp.getString("playlists", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Playlist(
                o.getString("id"), o.getString("name"), o.getString("type"), o.getString("source"),
                o.optString("user"), o.optString("pass"), o.optString("ua"), o.optString("endpoint"),
            )
        }
    }.getOrDefault(emptyList())

    fun savePlaylists(list: List<Playlist>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                .put("source", it.source).put("user", it.user).put("pass", it.pass).put("ua", it.ua)
                .put("endpoint", it.endpoint))
        }
        sp.edit().putString("playlists", a.toString()).apply()
    }

    var activeId: String
        get() = sp.getString("active", "") ?: ""
        set(v) { sp.edit().putString("active", v).apply() }

    fun favorites(): Set<String> = sp.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
    fun saveFavorites(s: Set<String>) { sp.edit().putStringSet("fav", HashSet(s)).apply() }

    fun position(url: String): Long = sp.getLong("pos_" + url.hashCode(), 0L)
    fun savePosition(url: String, ms: Long) {
        sp.edit().apply { if (ms <= 0) remove("pos_" + url.hashCode()) else putLong("pos_" + url.hashCode(), ms) }.apply()
    }

    // ---- cache de itens (TSV) para abrir instantaneamente ----
    private val CACHE_HEADER = "#brplay-cache-v3 dedupe="
    private fun cacheFile(id: String) = File(dir, "cache_$id.tsv")

    fun cacheAge(id: String): Long = cacheFile(id).lastModified()
    fun touchCache(id: String) { cacheFile(id).setLastModified(System.currentTimeMillis()) }

    /** Cache lido do disco. [processed] = já passou por agrupamento/duplicadas (abre sem reprocessar). */
    class Cached(val items: List<Item>, val processed: Boolean)

    /** Grava o cache em arquivo temporário e só então troca o antigo (nunca fica pela metade). */
    fun saveItems(id: String, items: List<Item>, dedupe: Boolean) {
        val tmp = File(dir, "cache_$id.tmp")
        tmp.bufferedWriter(Charsets.UTF_8, 64 * 1024).use { w ->
            w.append(CACHE_HEADER).append(if (dedupe) "1" else "0").append('\n')
            for (i in items) {
                w.append(i.kind.name).append('\t').append(c(i.name)).append('\t').append(c(i.url)).append('\t')
                    .append(c(i.logo)).append('\t').append(c(i.group)).append('\t').append(c(i.epgId)).append('\t')
                    .append(c(i.streamId)).append('\t').append(c(i.seriesId)).append('\n')
            }
        }
        val dst = cacheFile(id)
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) }
    }

    /** Lê o cache linha por linha. Se estiver corrompido, apaga o arquivo e devolve null (o app baixa de novo). */
    fun loadItems(id: String, dedupe: Boolean): Cached? {
        val f = cacheFile(id)
        if (!f.exists()) return null
        val result = runCatching {
            val out = ArrayList<Item>(16384)
            val groups = HashMap<String, String>()          // reaproveita textos repetidos (economiza memória)
            var processed = false
            var first = true
            f.bufferedReader(Charsets.UTF_8, 64 * 1024).useLines { lines ->
                for (l in lines) {
                    if (first) {
                        first = false
                        if (l.startsWith(CACHE_HEADER)) { processed = l.endsWith(if (dedupe) "1" else "0"); continue }
                    }
                    val p = l.split('\t')
                    if (p.size < 8) continue
                    val g = groups.getOrPut(p[4]) { p[4] }
                    out += Item(Kind.valueOf(p[0]), p[1], p[2], p[3], g, p[5], p[6], p[7])
                }
            }
            if (out.isEmpty()) error("cache vazio")
            Cached(out, processed)
        }
        if (result.isFailure) {
            logError("Cache inválido, apagado", result.exceptionOrNull())
            f.delete()
        }
        return result.getOrNull()
    }

    /** Registro de erros (arquivo brplay.log, limitado a ~200 KB) para suporte. */
    fun logError(msg: String, t: Throwable? = null) {
        android.util.Log.e("BRPlay", msg, t)
        runCatching {
            val f = File(dir, "brplay.log")
            if (f.length() > 200_000) f.delete()
            f.appendText("${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())} $msg" +
                (if (t != null) " | ${t.javaClass.simpleName}: ${t.message}" else "") + "\n")
        }
    }

    fun deletePlaylistData(p: Playlist) {
        cacheFile(p.id).delete()
        if (p.type == "file") File(p.source).delete()
    }

    // ---- configurações simples ----
    fun str(k: String, d: String = ""): String = sp.getString("cfg_$k", d) ?: d
    fun putStr(k: String, v: String) { sp.edit().putString("cfg_$k", v).apply() }
    fun bool(k: String, d: Boolean = false): Boolean = sp.getBoolean("cfg_$k", d)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean("cfg_$k", v).apply() }
    fun int(k: String, d: Int = 0): Int = sp.getInt("cfg_$k", d)
    fun putInt(k: String, v: Int) { sp.edit().putInt("cfg_$k", v).apply() }

    // ---- cache de capas do TMDB (arquivo de preferências separado) ----
    private val tmdb = ctx.getSharedPreferences("brplay_tmdb", Context.MODE_PRIVATE)
    fun tmdbGet(k: String): String? = tmdb.getString(k, null)
    fun tmdbPut(k: String, v: String) { tmdb.edit().putString(k, v).apply() }
    fun tmdbClear() { tmdb.edit().clear().apply() }

    // ---- histórico ("Continuar assistindo") e assistidos ----
    data class Hist(val item: Item, val pos: Long, val dur: Long, val ts: Long)

    fun history(): List<Hist> = runCatching {
        val a = JSONArray(sp.getString("hist", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Hist(
                Item(
                    Kind.valueOf(o.getString("k")), o.getString("n"), o.getString("u"), o.optString("l"),
                    o.optString("g"), o.optString("e"), o.optString("s"), o.optString("sid"),
                ),
                o.optLong("p"), o.optLong("d"), o.optLong("t"),
            )
        }
    }.getOrDefault(emptyList())

    fun seen(): Set<String> = sp.getStringSet("seen", emptySet())?.toSet() ?: emptySet()

    /** Registra o progresso: >90% vira "assistido"; abaixo disso entra em "Continuar assistindo". */
    fun recordProgress(item: Item, pos: Long, dur: Long) {
        if (dur <= 0 || item.url.isEmpty()) return
        val list = history().filter { it.item.url != item.url }.toMutableList()
        if (pos > dur * 0.9) {
            sp.edit().putStringSet("seen", HashSet(seen() + item.url)).apply()
        } else if (pos > 10_000) {
            list.add(0, Hist(item, pos, dur, System.currentTimeMillis()))
        }
        saveHistory(list.take(30))
    }

    fun clearHistory() { saveHistory(emptyList()); sp.edit().remove("seen").apply() }

    private fun saveHistory(list: List<Hist>) {
        val a = JSONArray()
        list.forEach {
            val i = it.item
            a.put(JSONObject().put("k", i.kind.name).put("n", i.name).put("u", i.url).put("l", i.logo)
                .put("g", i.group).put("e", i.epgId).put("s", i.streamId).put("sid", i.seriesId)
                .put("p", it.pos).put("d", it.dur).put("t", it.ts))
        }
        sp.edit().putString("hist", a.toString()).apply()
    }

    // ---- canais recentes e buscas recentes ----
    fun recents(): List<String> = (sp.getString("recents", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addRecent(url: String) {
        val l = (listOf(url) + recents().filter { it != url }).take(40)
        sp.edit().putString("recents", l.joinToString("\n")).apply()
    }

    fun searches(): List<String> = (sp.getString("searches", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addSearch(q: String) {
        val t = q.trim().replace('\n', ' ')
        if (t.length < 2) return
        val l = (listOf(t) + searches().filter { !it.equals(t, true) }).take(8)
        sp.edit().putString("searches", l.joinToString("\n")).apply()
    }

    fun clearSearches() { sp.edit().remove("searches").apply() }

    private fun c(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')
}
