package br.com.brplay.ui

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.data.Item
import br.com.brplay.data.Playlist
import br.com.brplay.data.Xtream
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SubScaffold(title: String, onBack: () -> Unit, fab: @Composable () -> Unit = {}, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Azul, titleContentColor = androidx.compose.ui.graphics.Color.White,
                    navigationIconContentColor = androidx.compose.ui.graphics.Color.White),
            )
        },
        floatingActionButton = fab,
        content = content,
    )
}

@Composable
fun PlaylistsScreen(vm: MainVm, onBack: () -> Unit, onAdd: () -> Unit) {
    val lists by vm.playlists.collectAsStateWithLifecycle()
    val activeId by vm.activeId.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<Playlist?>(null) }

    SubScaffold("Minhas listas", onBack, fab = {
        ExtendedFloatingActionButton(onClick = onAdd, containerColor = Verde, contentColor = androidx.compose.ui.graphics.Color.White,
            icon = { Icon(Icons.Rounded.Add, null) }, text = { Text("Adicionar") })
    }) { pad ->
        if (lists.isEmpty()) {
            Box(Modifier.padding(pad)) { EmptyState(Icons.Rounded.PlaylistAdd, "Você ainda não adicionou nenhuma lista.") }
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(lists, key = { it.id }) { p ->
                val selected = p.id == activeId
                Row(
                    Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium)
                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                        .clickable { vm.openPlaylist(p); onBack() }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        when (p.type) { "xtream" -> Icons.Rounded.Dns; "file" -> Icons.Rounded.FolderOpen; else -> Icons.Rounded.Link },
                        null, tint = if (selected) VerdeVivo else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                        Text(
                            when (p.type) { "xtream" -> "Xtream · ${p.user}"; "file" -> "Arquivo local"; else -> "Link M3U" },
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (selected) Icon(Icons.Rounded.CheckCircle, "Ativa", tint = Amarelo)
                    IconButton(onClick = { toDelete = p }) { Icon(Icons.Rounded.DeleteOutline, "Remover", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Remover lista?") },
            text = { Text("“${p.name}” será removida deste aparelho.") },
            confirmButton = { TextButton(onClick = { vm.remove(p); toDelete = null }) { Text("Remover", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
fun AddPlaylistScreen(vm: MainVm, onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val loading by vm.loading.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val err by vm.errorMsg.collectAsStateWithLifecycle()
    var mode by remember { mutableIntStateOf(0) } // 0 link, 1 arquivo, 2 xtream
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var ua by remember { mutableStateOf("") }
    var advanced by remember { mutableStateOf(false) }
    val diag by vm.diag.collectAsStateWithLifecycle()
    val diagRunning by vm.diagRunning.collectAsStateWithLifecycle()

    fun buildPlaylist(): Playlist =
        if (mode == 2) Playlist(UUID.randomUUID().toString(), name.ifBlank { hostOf(url) }, "xtream", Xtream.normalize(url), user.trim(), pass.trim(), ua.trim())
        else Playlist(UUID.randomUUID().toString(), name.ifBlank { hostOf(url) }, "m3u", url.trim(), ua = ua.trim())

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val shown = runCatching {
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) c.getString(i) else null
                }
            }.getOrNull().orEmpty().substringBeforeLast('.')
            vm.addFile(uri, name.ifBlank { shown }) { ok -> if (ok) onDone() }
        }
    }

    DisposableEffect(Unit) { onDispose { vm.clearError(); vm.clearDiag() } }

    SubScaffold("Adicionar lista", onBack) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Link M3U" to Icons.Rounded.Link, "Arquivo" to Icons.Rounded.FolderOpen, "Xtream" to Icons.Rounded.Dns)
                    .forEachIndexed { i, (label, icon) -> ModeChip(label, icon, mode == i) { mode = i; vm.clearError(); vm.clearDiag() } }
            }

            Field(name, { name = it }, "Nome da lista (opcional)", Icons.Rounded.Edit)
            when (mode) {
                0 -> Field(url, { url = it }, "Endereço da lista (http://…)", Icons.Rounded.Link, KeyboardType.Uri)
                1 -> Text("Escolha um arquivo .m3u ou .m3u8 do seu aparelho.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else -> {
                    Field(url, { url = it }, "Servidor (http://servidor:porta)", Icons.Rounded.Dns, KeyboardType.Uri)
                    Field(user, { user = it }, "Usuário", Icons.Rounded.Person)
                    Field(pass, { pass = it }, "Senha", Icons.Rounded.Lock, secret = true)
                }
            }

            if (mode != 1) {
                TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "Ocultar avançado" else "Opções avançadas") }
                if (advanced) Field(ua, { ua = it }, "User-Agent personalizado", Icons.Rounded.Language)
            }

            err?.let {
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.error.copy(alpha = .14f), MaterialTheme.shapes.medium).padding(12.dp)) {
                    Icon(Icons.Rounded.ErrorOutline, null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(10.dp)); Text(it)
                }
            }

            if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Amarelo, trackColor = Azul)
                Text(status.ifBlank { "Carregando…" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            val canSubmit = !loading && when (mode) {
                0 -> url.isNotBlank()
                1 -> true
                else -> url.isNotBlank() && user.isNotBlank() && pass.isNotBlank()
            }
            if (mode != 1) {
                OutlinedButton(
                    onClick = { vm.diagnose(buildPlaylist()) },
                    enabled = canSubmit && !diagRunning, shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) {
                    Icon(Icons.Rounded.NetworkCheck, null); Spacer(Modifier.width(8.dp))
                    Text(if (diagRunning) "Testando…" else "Testar conexão")
                }
            }
            if (diag.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("Diagnóstico", style = MaterialTheme.typography.titleMedium, color = Amarelo)
                    diag.forEach { Text(it, style = MaterialTheme.typography.labelMedium) }
                    if (diagRunning) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = Amarelo, trackColor = Azul)
                }
            }
            Button(
                onClick = {
                    if (mode == 1) picker.launch(arrayOf("*/*"))
                    else vm.add(buildPlaylist()) { if (it) onDone() }
                },
                enabled = canSubmit, shape = MaterialTheme.shapes.large,
                colors = ButtonDefaults.buttonColors(containerColor = Verde, disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Icon(if (mode == 1) Icons.Rounded.FolderOpen else Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text(if (mode == 1) "Escolher arquivo" else "Adicionar e carregar")
            }
        }
    }
}

private fun hostOf(u: String): String =
    runCatching { Uri.parse(if (u.contains("://")) u.trim() else "http://${u.trim()}").host }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Minha lista"

@Composable
private fun ModeChip(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = { Text(label) },
        leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) },
        shape = MaterialTheme.shapes.large,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surface,
            selectedContainerColor = Verde, selectedLabelColor = androidx.compose.ui.graphics.Color.White,
            selectedLeadingIconColor = Amarelo,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true, selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant, selectedBorderColor = VerdeVivo,
        ),
    )
}

@Composable
private fun Field(
    value: String, onChange: (String) -> Unit, label: String, icon: ImageVector,
    type: KeyboardType = KeyboardType.Text, secret: Boolean = false,
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        leadingIcon = { Icon(icon, null) },
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else type),
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        shape = MaterialTheme.shapes.medium,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = VerdeVivo, focusedLabelColor = VerdeVivo, cursorColor = Amarelo,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface, focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
        ),
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Detalhes da série: capa, botão Assistir/Continuar, seletor de temporada e episódios com progresso. */
@Composable
fun SeriesScreen(item: Item, vm: MainVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val seen by vm.seen.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var episodes by remember { mutableStateOf<List<Item>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var season by remember(item.key) { mutableStateOf<String?>(null) }

    LaunchedEffect(item.key) {
        val p = vm.active.value
        episodes = null; failed = false
        if (item.seriesId.startsWith("m3u:")) {
            val num = Regex("T(\\d+) · E(\\d+)")
            fun ord(e: Item): Long = num.find(e.name)?.let { it.groupValues[1].toLong() * 10000 + it.groupValues[2].toLong() } ?: Long.MAX_VALUE
            val list = vm.items.value.filter { it.seriesId == item.seriesId && it.url.isNotEmpty() }.sortedBy { ord(it) }
            episodes = list
            if (list.isEmpty()) failed = true
            return@LaunchedEffect
        }
        if (p == null) { failed = true; return@LaunchedEffect }
        episodes = withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { Xtream(p).episodes(item.seriesId, item.logo) }.getOrNull()
        }
        if (episodes.isNullOrEmpty()) failed = true
    }

    SubScaffold(item.name, onBack) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val eps = episodes
            when {
                failed -> EmptyState(Icons.Rounded.ErrorOutline, "Não foi possível carregar os episódios.")
                eps == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Amarelo)
                else -> {
                    val seasons = eps.map { it.group }.distinct()
                    val current = season ?: seasons.firstOrNull()
                    val progress = history.associate { it.item.url to (if (it.dur > 0) it.pos.toFloat() / it.dur else 0f) }
                    // último episódio em andamento; senão o primeiro ainda não assistido
                    val resume = history.firstNotNullOfOrNull { h -> eps.firstOrNull { it.url == h.item.url } }
                    val target = resume ?: eps.firstOrNull { it.url !in seen } ?: eps.first()
                    val label = target.name.substringBefore("  ")

                    LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)) {
                        item {
                            Poster(item, Modifier.fillMaxWidth().height(200.dp).padding(horizontal = 16.dp).clip(MaterialTheme.shapes.large), showTitle = true)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { launchPlayer(ctx, eps, target, vm) },
                                shape = MaterialTheme.shapes.large,
                                colors = ButtonDefaults.buttonColors(containerColor = Verde),
                                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(50.dp),
                            ) {
                                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(8.dp))
                                Text(if (resume != null) "Continuar $label" else "Assistir $label")
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        if (seasons.size > 1) item {
                            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(seasons) { sn ->
                                    FilterChip(
                                        selected = sn == current, onClick = { season = sn }, label = { Text(sn) },
                                        shape = MaterialTheme.shapes.large,
                                        colors = FilterChipDefaults.filterChipColors(
                                            containerColor = MaterialTheme.colorScheme.surface,
                                            selectedContainerColor = Verde, selectedLabelColor = androidx.compose.ui.graphics.Color.White),
                                    )
                                }
                            }
                        }
                        items(eps.filter { it.group == current }) { e ->
                            ItemRow(e, e.key in favs, onClick = { launchPlayer(ctx, eps, e, vm) }, onFav = { vm.toggleFavorite(e) },
                                watched = e.url in seen, progress = progress[e.url])
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    SubScaffold("Sobre", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(16.dp))
            LogoMark(88.dp)
            Spacer(Modifier.height(16.dp))
            Text("BR Play", style = MaterialTheme.typography.titleLarge)
            Text("Versão 2.3", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large).background(MaterialTheme.colorScheme.surface).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    "O BR Play é apenas um reprodutor de mídia. Não hospedamos, não distribuímos e não fornecemos nenhum conteúdo. " +
                        "O uso das listas e qualquer consequência legal de conteúdo ilegal são de inteira responsabilidade de quem utiliza o aplicativo.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Spacer(Modifier.height(28.dp))
            Text("Criado por", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text("@MonstroGuilher", style = MaterialTheme.typography.titleMedium, color = Amarelo)
        }
    }
}
