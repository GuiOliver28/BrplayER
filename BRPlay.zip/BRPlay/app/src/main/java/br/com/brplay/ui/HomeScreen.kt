package br.com.brplay.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.MainVm
import br.com.brplay.PlayerActivity
import br.com.brplay.Tab
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import br.com.brplay.data.PlayQueue

fun launchPlayer(ctx: Context, list: List<Item>, start: Item, vm: MainVm) {
    val playable = list.filter { it.url.isNotEmpty() }
    val idx = playable.indexOfFirst { it.key == start.key }.coerceAtLeast(0)
    PlayQueue.items = playable
    PlayQueue.index = idx
    PlayQueue.playlist = vm.active.value
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainVm, onPlaylists: () -> Unit, onAdd: () -> Unit, onSeries: (Item) -> Unit) {
    val ctx = LocalContext.current
    val tab by vm.tab.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val category by vm.category.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val err by vm.errorMsg.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val active by vm.active.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var searching by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(
                Modifier.background(Brush.verticalGradient(listOf(Azul, MaterialTheme.colorScheme.background)))
                    .statusBarsPadding()
            ) {
                Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (searching) {
                        val focus = remember { FocusRequester() }
                        LaunchedEffect(Unit) { focus.requestFocus() }
                        TextField(
                            value = query, onValueChange = { vm.query.value = it },
                            placeholder = { Text("Buscar…") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                            ),
                            shape = MaterialTheme.shapes.large,
                            modifier = Modifier.weight(1f).focusRequester(focus),
                        )
                        IconButton(onClick = { searching = false; vm.query.value = "" }) { Icon(Icons.Rounded.Close, "Fechar busca") }
                    } else {
                        LogoMark(34.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("BR Play", style = MaterialTheme.typography.titleLarge)
                            Text(active?.name ?: "Nenhuma lista", style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                        IconButton(onClick = { searching = true }) { Icon(Icons.Rounded.Search, "Buscar") }
                        IconButton(onClick = { vm.refresh() }, enabled = active != null && !loading) { Icon(Icons.Rounded.Refresh, "Atualizar lista") }
                        IconButton(onClick = onPlaylists) { Icon(Icons.Rounded.PlaylistPlay, "Minhas listas") }
                    }
                }
                AnimatedVisibility(loading) {
                    Column {
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Amarelo, trackColor = Azul)
                        Text(status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val navColors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AzulNoite, selectedTextColor = Amarelo,
                    indicatorColor = Amarelo,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                listOf(
                    Triple(Tab.LIVE, "Ao vivo", Icons.Rounded.LiveTv),
                    Triple(Tab.MOVIES, "Filmes", Icons.Rounded.Movie),
                    Triple(Tab.SERIES, "Séries", Icons.Rounded.Slideshow),
                    Triple(Tab.FAVORITES, "Favoritos", Icons.Rounded.Favorite),
                ).forEach { (t, label, icon) ->
                    NavigationBarItem(selected = tab == t, onClick = { vm.setTab(t) }, icon = { Icon(icon, label) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }, colors = navColors)
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            err?.let {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp, 8.dp).background(MaterialTheme.colorScheme.error.copy(alpha = .14f), MaterialTheme.shapes.medium)
                        .padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ErrorOutline, null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(10.dp))
                    Text(it, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = vm::clearError) { Icon(Icons.Rounded.Close, "Dispensar") }
                }
            }

            if (playlists.isEmpty()) {
                Welcome(onAdd)
                return@Column
            }

            if (tab != Tab.FAVORITES && categories.isNotEmpty()) {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item(key = "all") {
                        CatChip("Todos", category == null) { vm.category.value = null }
                    }
                    items(categories, key = { it }) { c -> CatChip(c, category == c) { vm.category.value = c } }
                }
            }

            if (visible.isEmpty() && !loading) {
                EmptyState(
                    if (tab == Tab.FAVORITES) Icons.Rounded.FavoriteBorder else Icons.Rounded.SearchOff,
                    if (tab == Tab.FAVORITES) "Nenhum favorito ainda.\nToque no coração para salvar." else "Nada encontrado aqui.",
                )
            } else if (tab == Tab.MOVIES || tab == Tab.SERIES) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(112.dp),
                    contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(visible, contentType = { "poster" }) { i ->
                        PosterCard(i, i.key in favs, onClick = { open(ctx, vm, visible, i, onSeries) }, onFav = { vm.toggleFavorite(i) })
                    }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
                    items(visible, contentType = { "row" }) { i ->
                        ItemRow(i, i.key in favs, onClick = { open(ctx, vm, visible, i, onSeries) }, onFav = { vm.toggleFavorite(i) })
                    }
                }
            }
        }
    }
}

private fun open(ctx: Context, vm: MainVm, list: List<Item>, i: Item, onSeries: (Item) -> Unit) {
    if (i.kind == Kind.SERIES && i.url.isEmpty()) onSeries(i) else launchPlayer(ctx, list, i, vm)
}

@Composable
private fun CatChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(label, maxLines = 1) },
        shape = MaterialTheme.shapes.large,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surface,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            selectedContainerColor = Verde, selectedLabelColor = androidx.compose.ui.graphics.Color.White,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true, selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant, selectedBorderColor = VerdeVivo,
        ),
    )
}

@Composable
fun EmptyState(icon: ImageVector, text: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(12.dp))
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Welcome(onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        LogoMark(96.dp)
        Spacer(Modifier.height(24.dp))
        Text("Bem-vindo ao BR Play", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "Adicione sua lista M3U, um arquivo ou o login Xtream e assista a canais, filmes e séries.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onAdd, shape = MaterialTheme.shapes.large,
            colors = ButtonDefaults.buttonColors(containerColor = Verde),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp),
        ) {
            Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("Adicionar lista")
        }
    }
}
