package br.com.brplay.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.brplay.CAT_FAV
import br.com.brplay.CAT_RECENT
import br.com.brplay.MainVm
import br.com.brplay.SortMode
import br.com.brplay.PlayerActivity
import br.com.brplay.Tab
import br.com.brplay.data.Item
import br.com.brplay.data.Kind
import br.com.brplay.data.PlayQueue

fun launchPlayer(ctx: Context, list: List<Item>, start: Item, vm: MainVm) {
    val playable = list.filter { it.url.isNotEmpty() }
    val idx = playable.indexOfFirst { it.key == start.key }.coerceAtLeast(0)
    PlayQueue.items = playable
    PlayQueue.index = idx
    PlayQueue.playlist = vm.active.value
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java))
}

internal fun open(ctx: Context, vm: MainVm, list: List<Item>, i: Item, onSeries: (Item) -> Unit) {
    if (i.kind == Kind.SERIES && i.url.isEmpty()) onSeries(i) else launchPlayer(ctx, list, i, vm)
}

@Composable
fun HomeScreen(vm: MainVm, onPlaylists: () -> Unit, onAdd: () -> Unit, onSeries: (Item) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val tab by vm.tab.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val category by vm.category.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val seen by vm.seen.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val syncing by vm.syncing.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val err by vm.errorMsg.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val active by vm.active.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val movieRows by vm.movieRows.collectAsStateWithLifecycle()
    val seriesRows by vm.seriesRows.collectAsStateWithLifecycle()
    val sortMode by vm.sort.collectAsStateWithLifecycle()
    val quality by vm.quality.collectAsStateWithLifecycle()
    val decade by vm.decade.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(
                Modifier.background(Brush.verticalGradient(listOf(Azul, MaterialTheme.colorScheme.background)))
                    .statusBarsPadding()
            ) {
                Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (searching) {
                        val focus = remember { FocusRequester() }
                        LaunchedEffect(Unit) { focus.requestFocus() }
                        TextField(
                            value = query, onValueChange = { vm.query.value = it },
                            placeholder = { Text("Buscar filmes, séries e canais…") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            ),
                            shape = MaterialTheme.shapes.large,
                            modifier = Modifier.weight(1f).focusRequester(focus),
                        )
                        IconButton(onClick = { vm.setSearching(false) }) { Icon(Icons.Rounded.Close, "Fechar busca") }
                    } else {
                        LogoMark(34.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("BR Play", style = MaterialTheme.typography.titleLarge)
                            Text(active?.name ?: "Nenhuma lista", style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                        IconButton(onClick = { vm.setSearching(true) }) { Icon(Icons.Rounded.Search, "Buscar") }
                        IconButton(onClick = { vm.refresh() }, enabled = active != null && !loading) { Icon(Icons.Rounded.Refresh, "Atualizar lista") }
                        IconButton(onClick = onPlaylists) { Icon(Icons.Rounded.PlaylistPlay, "Minhas listas") }
                    }
                }
                AnimatedVisibility(syncing && !loading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Verde, trackColor = androidx.compose.ui.graphics.Color.Transparent)
                }
                AnimatedVisibility(loading) {
                    Column {
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Amarelo, trackColor = Azul)
                        Text(status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val navColors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AzulNoite, selectedTextColor = Amarelo, indicatorColor = Amarelo,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                listOf(
                    Triple(Tab.HOME, "Início", Icons.Rounded.Home),
                    Triple(Tab.MOVIES, "Filmes", Icons.Rounded.Movie),
                    Triple(Tab.SERIES, "Séries", Icons.Rounded.Slideshow),
                    Triple(Tab.LIVE, "Ao vivo", Icons.Rounded.LiveTv),
                ).forEach { (t, label, icon) ->
                    NavigationBarItem(selected = tab == t && !searching, onClick = { vm.setSearching(false); vm.setTab(t) },
                        icon = { Icon(icon, label) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1) }, colors = navColors)
                }
                NavigationBarItem(selected = false, onClick = onSettings, icon = { Icon(Icons.Rounded.Settings, "Ajustes") },
                    label = { Text("Ajustes", style = MaterialTheme.typography.labelSmall, maxLines = 1) }, colors = navColors)
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            err?.let {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp, 8.dp).background(MaterialTheme.colorScheme.error.copy(alpha = .14f), MaterialTheme.shapes.medium)
                        .padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ErrorOutline, null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(10.dp))
                    Text(it, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { vm.clearError(); vm.refresh() }) { Text("Tentar novamente", color = Amarelo) }
                    IconButton(onClick = vm::clearError) { Icon(Icons.Rounded.Close, "Dispensar") }
                }
            }

            if (playlists.isEmpty()) { Welcome(onAdd); return@Column }

            if (searching) { SearchPanel(vm, onSeries); return@Column }
            if (tab == Tab.HOME) { Dashboard(vm, onSeries); return@Column }

            val filtersActive = category != null || sortMode != SortMode.DEFAULT || quality != null || decade != null
            if (tab != Tab.FAVORITES) {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item(key = "all") { CatChip("Todos", category == null) { vm.category.value = null } }
                    item(key = "fav") { CatChip(CAT_FAV, category == CAT_FAV) { vm.category.value = CAT_FAV } }
                    if (tab == Tab.LIVE) item(key = "recent") { CatChip(CAT_RECENT, category == CAT_RECENT) { vm.category.value = CAT_RECENT } }
                    items(categories, key = { it }) { c -> CatChip(c, category == c) { vm.category.value = c } }
                }
                FilterBar(vm, tab)
                Spacer(Modifier.height(8.dp))
            }

            val showGrid = tab == Tab.MOVIES || tab == Tab.SERIES
            val showRows = showGrid && !filtersActive
            val myKind = if (tab == Tab.MOVIES) Kind.MOVIE else Kind.SERIES
            val rows = if (tab == Tab.MOVIES) movieRows else seriesRows
            val cont = history.filter { it.item.kind == myKind }
            when {
                visible.isEmpty() && loading -> if (showGrid) SkeletonGrid() else SkeletonRows()
                visible.isEmpty() -> EmptyState(
                    when {
                        category == CAT_FAV || tab == Tab.FAVORITES -> Icons.Rounded.FavoriteBorder
                        category == CAT_RECENT -> Icons.Rounded.History
                        else -> Icons.Rounded.SearchOff
                    },
                    when {
                        category == CAT_FAV || tab == Tab.FAVORITES -> "Nenhum favorito aqui ainda.\nToque no coração para salvar."
                        category == CAT_RECENT -> "Você ainda não assistiu nenhum canal."
                        else -> "Nada encontrado aqui."
                    },
                )
                showGrid -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(112.dp),
                    contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (showRows) {
                        if (cont.isNotEmpty()) item(key = "cont", span = { GridItemSpan(maxLineSpan) }) { ContinueRow(cont, vm, favs, 0.dp) }
                        rows.forEach { sec ->
                            item(key = "r_" + sec.title, span = { GridItemSpan(maxLineSpan) }) { Carousel(sec, vm, onSeries, favs, seen, 0.dp) }
                        }
                        item(key = "all_title", span = { GridItemSpan(maxLineSpan) }) {
                            SectionHeader(if (tab == Tab.MOVIES) "Todos os filmes" else "Todas as séries", 0.dp)
                        }
                    }
                    items(visible, contentType = { "poster" }) { i ->
                        PosterCard(i, i.key in favs, onClick = { open(ctx, vm, visible, i, onSeries) },
                            onFav = { vm.toggleFavorite(i) }, watched = i.url in seen)
                    }
                }
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
                    items(visible, contentType = { "row" }) { i ->
                        ItemRow(i, i.key in favs, onClick = { open(ctx, vm, visible, i, onSeries) },
                            onFav = { vm.toggleFavorite(i) }, watched = i.url in seen)
                    }
                }
            }
        }
    }
}

@Composable
private fun CatChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick,
        label = { Text(label, maxLines = 1) },
        shape = MaterialTheme.shapes.large,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surface,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            selectedContainerColor = Verde, selectedLabelColor = Color.White,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true, selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant, selectedBorderColor = VerdeVivo,
        ),
    )
}

@Composable
fun EmptyState(icon: ImageVector, text: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(12.dp))
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Welcome(onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        LogoMark(96.dp)
        Spacer(Modifier.height(24.dp))
        Text("Bem-vindo ao BR Play", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "Adicione sua lista M3U, um arquivo ou o login Xtream e assista a canais, filmes e séries.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        Text("Saudações de @MonstroGuilher! Aproveite o app.", style = MaterialTheme.typography.titleMedium,
            color = Amarelo, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(
            "O BR Play é apenas um reprodutor e não distribui conteúdo. O uso das listas e qualquer consequência legal são de inteira responsabilidade de quem utiliza o app.",
            style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onAdd, shape = MaterialTheme.shapes.large,
            colors = ButtonDefaults.buttonColors(containerColor = Verde),
            contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp),
        ) {
            Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("Adicionar lista")
        }
    }
}
