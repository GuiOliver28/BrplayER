package br.com.brplay.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

// Paleta da bandeira do Brasil
val Verde = Color(0xFF009C3B)
val VerdeVivo = Color(0xFF00B84A)
val Amarelo = Color(0xFFFFDF00)
val Azul = Color(0xFF002776)
val AzulNoite = Color(0xFF06122B)
val Superficie = Color(0xFF0C1B3F)
val SuperficieAlta = Color(0xFF14295A)
val TextoSuave = Color(0xFFA9B8DA)

private val scheme = darkColorScheme(
    primary = VerdeVivo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF0B4A2A),
    onPrimaryContainer = Color(0xFFB7F5CF),
    secondary = Amarelo,
    onSecondary = AzulNoite,
    secondaryContainer = Color(0xFF3B3500),
    onSecondaryContainer = Amarelo,
    tertiary = Azul,
    background = AzulNoite,
    onBackground = Color(0xFFF2F6FF),
    surface = Superficie,
    onSurface = Color(0xFFF2F6FF),
    surfaceVariant = SuperficieAlta,
    onSurfaceVariant = TextoSuave,
    outline = Color(0xFF2B4380),
    outlineVariant = Color(0xFF1B2F63),
    error = Color(0xFFFF7A7A),
)

private val type = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp),
)

private val shapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun BrTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, shapes = shapes, content = content)
}
