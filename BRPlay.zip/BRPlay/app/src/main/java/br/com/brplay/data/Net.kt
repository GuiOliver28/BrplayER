package br.com.brplay.data

import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.zip.GZIPInputStream
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** O servidor respondeu, mas com um código HTTP de erro (403, 404, 456…). */
class HttpStatusException(val code: Int) : IOException("Servidor respondeu HTTP $code")

object Net {
    const val UA = "VLC/3.0.20 LibVLC/3.0.20"

    /** User-Agents testados em ordem até algum servidor aceitar. */
    val UAS = listOf(
        UA,
        "TiviMate/4.7.0",
        "IPTVSmartersPro/2.0",
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "okhttp/4.12.0",
    )

    /** Só nestes códigos HTTP vale tentar outro User-Agent; nos demais (404, 429, 5xx…) repetir só piora. */
    val ROTATE_UA = setOf(401, 403, 406, 444, 456)

    /** Aceita certificados SSL inválidos (opcional, ligado só pelo usuário nas Configurações). */
    @Volatile var insecure = false

    private val trustAll = arrayOf<TrustManager>(object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    })
    private val insecureFactory by lazy {
        SSLContext.getInstance("TLS").apply { init(null, trustAll, SecureRandom()) }.socketFactory
    }
    private val anyHost = HostnameVerifier { _, _ -> true }

    /** Para o player (ExoPlayer usa HttpURLConnection): vale para todo o app enquanto estiver ligado. */
    fun applyGlobalSsl() {
        if (insecure) {
            HttpsURLConnection.setDefaultSSLSocketFactory(insecureFactory)
            HttpsURLConnection.setDefaultHostnameVerifier(anyHost)
        }
    }

    fun swapScheme(u: String): String = when {
        u.startsWith("http://") -> "https://" + u.removePrefix("http://")
        u.startsWith("https://") -> "http://" + u.removePrefix("https://")
        else -> u
    }

    /** Abre a URL com até 3 tentativas (espera crescente) e segue redirecionamentos, inclusive http -> https. */
    // Espaça as requisições ao mesmo servidor (evita o bloqueio HTTP 429 dos provedores)
    private const val MIN_GAP_MS = 300L
    private val gateLock = Any()
    private val nextSlot = HashMap<String, Long>()
    private fun gate(url: String) {
        val h = runCatching { URL(url).host }.getOrNull() ?: return
        val wait = synchronized(gateLock) {
            val now = System.currentTimeMillis()
            val slot = maxOf(now, nextSlot[h] ?: 0L)
            nextSlot[h] = slot + MIN_GAP_MS
            slot - now
        }
        if (wait > 0) Thread.sleep(wait)
    }

    fun open(url: String, ua: String = "", connectMs: Int = 15_000, readMs: Int = 20_000): InputStream {
        var last: IOException? = null
        for (attempt in 0..2) {
            gate(url)
            try {
                return openOnce(url, ua, connectMs, readMs)
            } catch (e: HttpStatusException) {
                throw e                      // o servidor respondeu: repetir não ajuda
            } catch (e: UnknownHostException) {
                // DNS do aparelho falhou: tenta o plano B (DNS por HTTPS) antes de desistir
                try { return openViaDoh(url, ua, connectMs, readMs) }
                catch (h: HttpStatusException) { throw h }
                catch (h: IOException) { last = e }
                if (attempt < 2) Thread.sleep(700L shl attempt)
            } catch (e: IOException) {
                last = e
                if (attempt < 2) Thread.sleep(500L shl attempt)
            }
        }
        throw last ?: IOException("Falha de conexão")
    }

    // ---------- Plano B: DNS por HTTPS (Cloudflare / Google), usado só quando o DNS do aparelho falha ----------
    private class Hit(val ips: List<InetAddress>, val until: Long)
    private val dohCache = ConcurrentHashMap<String, Hit>()

    private fun dohLookup(host: String): List<InetAddress> {
        dohCache[host]?.let { if (it.until > System.currentTimeMillis()) return it.ips }
        val endpoints = listOf(
            "https://1.1.1.1/dns-query?name=$host&type=A",
            "https://8.8.8.8/resolve?name=$host&type=A",
            "https://1.0.0.1/dns-query?name=$host&type=A",
        )
        for (ep in endpoints) {
            try {
                val c = URL(ep).openConnection() as HttpURLConnection
                c.connectTimeout = 6_000; c.readTimeout = 6_000
                c.setRequestProperty("Accept", "application/dns-json")
                if (c.responseCode != 200) { c.disconnect(); continue }
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val ans = JSONObject(body).optJSONArray("Answer") ?: continue
                val ips = ArrayList<InetAddress>()
                for (i in 0 until ans.length()) {
                    val o = ans.getJSONObject(i)
                    if (o.optInt("type") == 1) ips += InetAddress.getByName(o.getString("data"))
                }
                if (ips.isNotEmpty()) {
                    dohCache[host] = Hit(ips, System.currentTimeMillis() + 5 * 60_000)
                    return ips
                }
            } catch (_: Exception) { }
        }
        throw UnknownHostException(host)
    }

    private val dohDns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> =
            try { Dns.SYSTEM.lookup(hostname) } catch (e: UnknownHostException) { dohLookup(hostname) }
    }

    private fun openViaDoh(url: String, ua: String, connectMs: Int, readMs: Int): InputStream {
        val b = OkHttpClient.Builder()
            .dns(dohDns)
            .connectTimeout(connectMs.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(readMs.toLong(), TimeUnit.MILLISECONDS)
            .followRedirects(true).followSslRedirects(true)
        if (insecure) b.sslSocketFactory(insecureFactory, trustAll[0] as X509TrustManager).hostnameVerifier(anyHost)
        val req = Request.Builder().url(url).header("User-Agent", ua.ifBlank { UA }).build()
        val resp = b.build().newCall(req).execute()
        if (!resp.isSuccessful) { val code = resp.code; resp.close(); throw HttpStatusException(code) }
        return resp.body?.byteStream() ?: throw IOException("Resposta vazia")
    }

    private fun openOnce(url: String, ua: String, connectMs: Int, readMs: Int): InputStream {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.setRequestProperty("User-Agent", ua.ifBlank { UA })
            c.setRequestProperty("Accept-Encoding", "gzip")
            if (insecure && c is HttpsURLConnection) { c.sslSocketFactory = insecureFactory; c.hostnameVerifier = anyHost }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("Redirecionamento inválido")
                current = URL(URL(current), loc).toString()
                c.disconnect()
                return@repeat
            }
            if (code !in 200..299) throw HttpStatusException(code)
            val raw = c.inputStream
            return if (c.contentEncoding.equals("gzip", true)) GZIPInputStream(raw) else raw
        }
        throw IOException("Redirecionamentos demais")
    }

    fun text(url: String, ua: String = "", readMs: Int = 30_000): String =
        open(url, ua, readMs = readMs).bufferedReader(Charsets.UTF_8).use { it.readText() }

    /** Tenta cada User-Agent; só avança quando o servidor responde com erro HTTP (ex.: 403). Devolve (fluxo, UA que funcionou). */
    fun openAny(url: String, preferredUa: String = ""): Pair<InputStream, String> {
        val uas = (listOf(preferredUa) + UAS).filter { it.isNotBlank() }.distinct()
        var last: HttpStatusException? = null
        for (u in uas) {
            try { return open(url, u) to u } catch (e: HttpStatusException) {
                if (e.code !in ROTATE_UA) throw e          // 404/429/5xx: trocar de User-Agent não resolve
                last = e
            }
        }
        throw last ?: IOException("Falha de conexão")
    }
}
