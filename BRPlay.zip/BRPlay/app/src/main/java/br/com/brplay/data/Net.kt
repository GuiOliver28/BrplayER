package br.com.brplay.data

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14; BRPlay) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Abre a URL seguindo redirecionamentos (inclusive http -> https). */
    fun open(url: String, ua: String = ""): InputStream {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 40_000
            c.setRequestProperty("User-Agent", ua.ifBlank { UA })
            c.setRequestProperty("Accept-Encoding", "gzip")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("Redirecionamento inválido")
                current = URL(URL(current), loc).toString()
                c.disconnect()
                return@repeat
            }
            if (code !in 200..299) error("Servidor respondeu HTTP $code")
            val raw = c.inputStream
            return if (c.contentEncoding.equals("gzip", true)) GZIPInputStream(raw) else raw
        }
        error("Redirecionamentos demais")
    }

    fun text(url: String, ua: String = ""): String =
        open(url, ua).bufferedReader(Charsets.UTF_8).use { it.readText() }
}
