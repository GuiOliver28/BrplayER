package br.com.brplay.data

import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.zip.GZIPInputStream
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** O servidor respondeu, mas com um código HTTP de erro (403, 404, 456…). */
class HttpStatusException(val code: Int) : IOException("Servidor respondeu HTTP $code")

object Net {
    const val UA = "VLC/3.0.20 LibVLC/3.0.20"

    /** User-Agents testados em ordem até algum servidor aceitar. */
    val UAS = listOf(
        UA,
        "TiviMate/4.7.0",
        "IPTVSmartersPro/2.0",
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "okhttp/4.12.0",
    )

    /** Aceita certificados SSL inválidos (opcional, ligado só pelo usuário nas Configurações). */
    @Volatile var insecure = false

    private val trustAll = arrayOf<TrustManager>(object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    })
    private val insecureFactory by lazy {
        SSLContext.getInstance("TLS").apply { init(null, trustAll, SecureRandom()) }.socketFactory
    }
    private val anyHost = HostnameVerifier { _, _ -> true }

    /** Para o player (ExoPlayer usa HttpURLConnection): vale para todo o app enquanto estiver ligado. */
    fun applyGlobalSsl() {
        if (insecure) {
            HttpsURLConnection.setDefaultSSLSocketFactory(insecureFactory)
            HttpsURLConnection.setDefaultHostnameVerifier(anyHost)
        }
    }

    fun swapScheme(u: String): String = when {
        u.startsWith("http://") -> "https://" + u.removePrefix("http://")
        u.startsWith("https://") -> "http://" + u.removePrefix("https://")
        else -> u
    }

    /** Abre a URL com até 3 tentativas (espera crescente) e segue redirecionamentos, inclusive http -> https. */
    fun open(url: String, ua: String = "", connectMs: Int = 10_000, readMs: Int = 30_000): InputStream {
        var last: IOException? = null
        for (attempt in 0..2) {
            try {
                return openOnce(url, ua, connectMs, readMs)
            } catch (e: HttpStatusException) {
                throw e                      // o servidor respondeu: repetir não ajuda
            } catch (e: UnknownHostException) {
                throw e
            } catch (e: IOException) {
                last = e
                if (attempt < 2) Thread.sleep(500L shl attempt)
            }
        }
        throw last ?: IOException("Falha de conexão")
    }

    private fun openOnce(url: String, ua: String, connectMs: Int, readMs: Int): InputStream {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.setRequestProperty("User-Agent", ua.ifBlank { UA })
            c.setRequestProperty("Accept-Encoding", "gzip")
            if (insecure && c is HttpsURLConnection) { c.sslSocketFactory = insecureFactory; c.hostnameVerifier = anyHost }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("Redirecionamento inválido")
                current = URL(URL(current), loc).toString()
                c.disconnect()
                return@repeat
            }
            if (code !in 200..299) throw HttpStatusException(code)
            val raw = c.inputStream
            return if (c.contentEncoding.equals("gzip", true)) GZIPInputStream(raw) else raw
        }
        throw IOException("Redirecionamentos demais")
    }

    fun text(url: String, ua: String = "", readMs: Int = 30_000): String =
        open(url, ua, readMs = readMs).bufferedReader(Charsets.UTF_8).use { it.readText() }

    /** Tenta cada User-Agent; só avança quando o servidor responde com erro HTTP (ex.: 403). Devolve (fluxo, UA que funcionou). */
    fun openAny(url: String, preferredUa: String = ""): Pair<InputStream, String> {
        val uas = (listOf(preferredUa) + UAS).filter { it.isNotBlank() }.distinct()
        var last: HttpStatusException? = null
        for (u in uas) {
            try { return open(url, u) to u } catch (e: HttpStatusException) { last = e }
        }
        throw last ?: IOException("Falha de conexão")
    }
}
