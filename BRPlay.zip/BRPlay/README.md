# BR Play 2.1

Reprodutor de listas IPTV (M3U/M3U8, arquivo local e Xtream Codes) para Android e Fire TV.

- Início com seções: Continuar assistindo, Adicionados recentemente, Lançamentos, Favoritos e categorias
- Abas separadas: Ao vivo, Filmes, Séries, Favoritos
- Filtros (qualidade 4K/FHD/HD/SD, década), ordenação (A-Z, Z-A, recentes, ano) e remoção de duplicadas
- Capas inteligentes: https quando possível, fallback TMDB (opcional) e placeholder com gradiente
- Player Media3: HLS, DASH, TS, MP4, MKV, áudio/legenda, PiP, próximo episódio, retomar de onde parou
- Controle parental com PIN, favoritos, assistidos, navegação por D-Pad (Fire TV)

## Gerar o APK
Envie o BRPlay.zip ao GitHub e use o workflow "Gerar APK" (Actions), ou abra a pasta no Android Studio.
