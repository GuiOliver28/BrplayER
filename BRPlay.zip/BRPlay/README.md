# BR Play

Reprodutor de listas IPTV com visual verde, amarelo e azul.

Aceita: link M3U/M3U8, arquivo M3U do aparelho e login Xtream Codes (canais, filmes, séries, "agora no ar").
Player Media3/ExoPlayer (HLS, DASH, TS, MP4, MKV), troca de canal com ◀ ▶, retoma filmes de onde parou, favoritos e busca.

## Gerar o APK (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta inteira.
2. Aba **Actions** > **Gerar APK** > **Run workflow**.
3. Ao terminar, baixe o artefato **BRPlay-apk** (contém app-release.apk) e instale.

## Gerar com Android Studio
Abra a pasta, aguarde o sync e rode **Build > Build APK(s)**.
